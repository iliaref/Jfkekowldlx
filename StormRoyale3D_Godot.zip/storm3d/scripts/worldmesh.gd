class_name WorldMesh
extends Node3D
## Строит 3D-сцену острова: рельеф, море, дома, деревья, камни, трава.

const FLOORC := ["#d8b27a", "#c9a46b", "#d2b98f", "#c19a64"]
const WALLC := ["#f3e4cc", "#e8cfa8", "#cfe0ee", "#efc9c9"]
const WALLB := [
	["#f3e4cc", "#e8cfa8", "#cfe0ee", "#efc9c9"], ["#e6c9a0", "#d8b384", "#efd9b0", "#cfa66e"],
	["#8b6b4a", "#7a5b3e", "#9a7a58", "#6e5238"], ["#7a5a3a", "#6b4f33", "#8a6a46", "#5c432c"], ["#6e7d6a", "#5f6e5b", "#7d8a72", "#566450"]]
const ROOFB := [
	["#c4553b", "#4d6a8f", "#7b4a32", "#4f8a5b", "#8a5a8f"], ["#b5683a", "#a35a30", "#c4784a", "#8f4d28", "#bd7040"],
	["#f2f6fa", "#e1ecf5", "#ffffff", "#d4e2ee", "#eef4fa"], ["#2f5f3a", "#3d6b45", "#4d7a52", "#244f2f", "#35603b"], ["#5a4a32", "#6b573c", "#4d3f2a", "#74603f", "#5a4a32"]]
const PLAZAC := ["#b9aa8c", "#d8c08e", "#dfe8ef", "#8a8a6a", "#7a7a5a"]
const ROCKB := [
	["#ffffff", "#f0ece6", "#e4eaf0", "#f4ebe0"], ["#e3b98a", "#d8a972", "#ecc79c", "#cf9d66"], ["#e8eef4", "#d8e2ec", "#f4f8fb", "#c9d6e2"],
	["#ffffff", "#f0ece6", "#e4eaf0", "#f4ebe0"], ["#b8b6a0", "#a8a690", "#c4c2ac", "#9c9a84"]]
const TINT := ["#ffffff", "#e8ffe8", "#fff5d6", "#dcf5ff"]
const FTINT := ["#d8efe0", "#c8e6d0", "#e4f3e8", "#bfe0cb"]
const STINT := ["#eaf2f8", "#f8fbff", "#dbe7f1", "#f1f7fb"]
const FLOWC := ["#ffffff", "#ffe14d", "#ff7fb0", "#b58cff", "#ff6b4a"]

var world: World
var roofs: Array = []
var sea_mat: ShaderMaterial = null
var clouds: Array = []
var quality := "high"
var progress := 0.0
var _env_busy := false

# ---------- генератор мешей ----------
class MB:
	var v := PackedVector3Array()
	var n := PackedVector3Array()
	var c := PackedColorArray()
	var idx := PackedInt32Array()

	func add(mesh: Mesh, xf: Transform3D, c0: Color, c1: Color, y0: float, y1: float, jitter := 0.0, tex_flat := false) -> void:
		var arr := mesh.surface_get_arrays(0)
		var vs: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
		var ns: PackedVector3Array = arr[Mesh.ARRAY_NORMAL]
		var ix: PackedInt32Array = arr[Mesh.ARRAY_INDEX]
		var base := v.size()
		var nb := xf.basis.inverse().transposed()
		for i in vs.size():
			var p := vs[i]
			if jitter > 0.0:
				var h := fposmod(sin(roundf(p.x * 50.0) * 127.1 + roundf(p.y * 50.0) * 311.7 + roundf(p.z * 50.0) * 74.7) * 43758.5453, 1.0)
				p = p * (1.0 + (h - .5) * jitter)
			v.append(xf * p)
			n.append((nb * ns[i]).normalized())
			var t := clampf((p.y - y0) / maxf(.0001, y1 - y0), 0.0, 1.0)
			c.append(c0.lerp(c1, t).srgb_to_linear())
		for k in ix:
			idx.append(base + k)

	func smooth() -> void:
		var acc := {}
		for t in range(0, idx.size(), 3):
			var a := idx[t]
			var b := idx[t + 1]
			var d := idx[t + 2]
			var fn := (v[b] - v[a]).cross(v[d] - v[a])
			for q in [a, b, d]:
				var key := Vector3i(roundi(v[q].x * 100.0), roundi(v[q].y * 100.0), roundi(v[q].z * 100.0))
				acc[key] = acc.get(key, Vector3.ZERO) + fn
		for i in v.size():
			var key := Vector3i(roundi(v[i].x * 100.0), roundi(v[i].y * 100.0), roundi(v[i].z * 100.0))
			n[i] = acc[key].normalized()

	func build() -> ArrayMesh:
		var m := ArrayMesh.new()
		var a := []
		a.resize(Mesh.ARRAY_MAX)
		a[Mesh.ARRAY_VERTEX] = v
		a[Mesh.ARRAY_NORMAL] = n
		a[Mesh.ARRAY_COLOR] = c
		a[Mesh.ARRAY_INDEX] = idx
		m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
		return m

static func _sph_mesh(seg: int, rings: int) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = 1.0
	s.height = 2.0
	s.radial_segments = seg
	s.rings = rings
	return s

static func _cyl_mesh(rt: float, rb: float, seg: int) -> CylinderMesh:
	var s := CylinderMesh.new()
	s.top_radius = rt
	s.bottom_radius = rb
	s.height = 1.0
	s.radial_segments = seg
	s.rings = 1
	return s

static func xf(sx: float, sy: float, sz: float, x: float, y: float, z: float, ry := 0.0, rx := 0.0, rz := 0.0) -> Transform3D:
	var b := Basis.from_euler(Vector3(rx, ry, rz)).scaled(Vector3(sx, sy, sz))
	return Transform3D(b, Vector3(x, y, z))

func _pine_mesh() -> ArrayMesh:
	var mb := MB.new()
	mb.add(_cyl_mesh(.62, 1.0, 16), xf(3.6, 24, 3.6, 0, 12, 0), Color("#5a3a1e"), Color("#7a4a26"), -.5, .5)
	var r := 25.0
	for lv in [[.55, 1.5, 1.05], [1.25, 1.3, .8], [1.9, 1.1, .55], [2.45, .8, .38]]:
		mb.add(_cyl_mesh(.0001, 1.0, 34), xf(r * lv[2], r * lv[1], r * lv[2], 0, 14 + r * lv[0], 0), Color("#27743a"), Color("#58bd5c"), -.5, .5, .12)
	mb.smooth()
	return mb.build()

func _oak_mesh() -> ArrayMesh:
	var mb := MB.new()
	mb.add(_cyl_mesh(.62, 1.0, 16), xf(4.8, 20, 4.8, 0, 10, 0), Color("#5a3a1e"), Color("#7a4a26"), -.5, .5)
	var r := 25.0
	var sp := _sph_mesh(28, 14)
	for b in [[0, .75, 0, 1], [.55, .55, .25, .72], [-.5, .6, .35, .7], [.1, .55, -.55, .68], [-.3, 1.1, -.1, .6]]:
		var s: float = r * b[3] * 1.05
		mb.add(sp, xf(s, s * .85, s, b[0] * r, 22 + b[1] * r, b[2] * r), Color("#2f8f3e"), Color("#6fd06a"), -1.0, 1.0, .3)
	mb.smooth()
	return mb.build()

func _rock_mesh() -> ArrayMesh:
	var mb := MB.new()
	mb.add(_sph_mesh(36, 18), Transform3D.IDENTITY, Color("#6e747e"), Color("#aeb4bd"), -.6, 1.0, .5)
	mb.smooth()
	return mb.build()

func _bush_mesh() -> ArrayMesh:
	var mb := MB.new()
	mb.add(_sph_mesh(20, 10), Transform3D.IDENTITY, Color("#2b8a3a"), Color("#5fc15a"), -1.0, 1.0, .3)
	mb.smooth()
	return mb.build()

func _cactus_mesh() -> ArrayMesh:
	var mb := MB.new()
	var cc0 := Color("#2f7a3c")
	var cc1 := Color("#4aa355")
	mb.add(_cyl_mesh(1, 1, 16), xf(5, 28, 5, 0, 14, 0), cc0, cc1, -.5, .5)
	mb.add(_sph_mesh(16, 8), xf(5, 5, 5, 0, 28.5, 0), cc1, cc1, -1, 1)
	mb.add(_cyl_mesh(1, 1, 12), xf(3.2, 11, 3.2, 8, 17, 0, 0, 0, PI / 2), cc0, cc1, -.5, .5)
	mb.add(_cyl_mesh(1, 1, 12), xf(3.2, 11, 3.2, 13, 22, 0), cc0, cc1, -.5, .5)
	mb.add(_sph_mesh(12, 6), xf(3.2, 3.2, 3.2, 13, 27.5, 0), cc1, cc1, -1, 1)
	mb.smooth()
	return mb.build()

func _tuft_mesh() -> ArrayMesh:
	var m := ArrayMesh.new()
	var v := PackedVector3Array()
	var n := PackedVector3Array()
	var c := PackedColorArray()
	for k in 7:
		var a := k * .449
		var ca := cos(a) * 1.3
		var sa := sin(a) * 1.3
		var tip := Vector3(cos(a * 3.0) * 1.2, 6.0 + (k % 3) * 1.6, sin(a * 3.0) * 1.2)
		v.append(Vector3(-ca, 0, -sa)); v.append(Vector3(ca, 0, sa)); v.append(tip)
		for q in 3:
			n.append(Vector3(0, 1, 0))
		var cb := Color("#3f8f3a").srgb_to_linear()
		var ct := Color("#8fd45a").srgb_to_linear()
		c.append(cb); c.append(cb); c.append(ct)
	var a2 := []
	a2.resize(Mesh.ARRAY_MAX)
	a2[Mesh.ARRAY_VERTEX] = v
	a2[Mesh.ARRAY_NORMAL] = n
	a2[Mesh.ARRAY_COLOR] = c
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a2)
	return m

# ---------- multimesh по чанкам ----------
func _mm_chunks(mesh: Mesh, mat: Material, items: Array, cell: float, vis_end: float, shadow: bool) -> void:
	var groups := {}
	for it in items:
		var key := Vector2i(int(it["p"].x / cell), int(it["p"].z / cell))
		if not groups.has(key):
			groups[key] = []
		groups[key].append(it)
	for key in groups:
		var arr: Array = groups[key]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.use_colors = true
		mm.mesh = mesh
		mm.instance_count = arr.size()
		for i in arr.size():
			var it: Dictionary = arr[i]
			var b := Basis.from_euler(Vector3(0, it.get("ry", 0.0), 0)).scaled(it["s"])
			mm.set_instance_transform(i, Transform3D(b, it["p"]))
			mm.set_instance_color(i, (it["c"] as Color))
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.material_override = mat
		mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		if vis_end > 0.0:
			mmi.visibility_range_end = vis_end
		add_child(mmi)

func _mm_all(mesh: Mesh, mat: Material, items: Array, shadow: bool) -> void:
	if items.is_empty():
		return
	_mm_chunks(mesh, mat, items, 100000.0, 0.0, shadow)

func _it(p: Vector3, s: Vector3, c: Color, ry := 0.0) -> Dictionary:
	return {"p": p, "s": s, "c": c, "ry": ry}

# ---------- главный метод ----------
func build(w: World, q: String, tree: SceneTree) -> void:
	world = w
	quality = q
	for ch in get_children():
		ch.queue_free()
	roofs.clear()
	progress = 0.0
	await _terrain(tree)
	progress = .45
	_sea()
	_mountains()
	_clouds()
	await tree.process_frame
	_buildings()
	progress = .6
	await tree.process_frame
	_nature(tree)
	progress = 1.0

func _terrain(tree: SceneTree) -> void:
	var mat := ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = """
shader_type spatial;
uniform sampler2D detail : filter_linear_mipmap, repeat_enable;
varying vec3 wp;
void vertex() { wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	float a = texture(detail, wp.xz / 110.0).r;
	float b = texture(detail, wp.xz / 13.0).r;
	float c = texture(detail, wp.xz / 2.6).r;
	float dd = -VERTEX.z;
	float fb = 1.0 - smoothstep(500.0, 1800.0, dd);
	float fc = 1.0 - smoothstep(60.0, 380.0, dd);
	float k = (0.72 + 0.56 * a) * (1.0 + (b - 0.5) * 0.56 * fb) * (1.0 + (c - 0.5) * 0.32 * fc);
	ALBEDO = COLOR.rgb * k;
	ROUGHNESS = 0.96;
	SPECULAR = 0.15;
}
"""
	mat.shader = sh
	mat.set_shader_parameter("detail", Mat.tex_set("sand")["a"])
	var CH := 24
	var nch := World.TN / CH
	var count := 0
	for cj in nch:
		for ci in nch:
			var any := false
			for j in range(cj * CH, (cj + 1) * CH + 1, 6):
				for i in range(ci * CH, (ci + 1) * CH + 1, 6):
					if world.h_vertex(i, j) > -12.0:
						any = true
						break
				if any:
					break
			if not any:
				continue
			var vs := PackedVector3Array()
			var ns := PackedVector3Array()
			var cs := PackedColorArray()
			var ix := PackedInt32Array()
			var vn := CH + 1
			vs.resize(vn * vn)
			ns.resize(vn * vn)
			cs.resize(vn * vn)
			for lj in vn:
				var j := cj * CH + lj
				var crow: PackedColorArray = world.crows[j]
				for li in vn:
					var i := ci * CH + li
					var h := world.h_vertex(i, j)
					var o := lj * vn + li
					vs[o] = Vector3(-World.TMARGIN + i * World.TCELL, h, -World.TMARGIN + j * World.TCELL)
					var nx := world.h_vertex(i - 1, j) - world.h_vertex(i + 1, j)
					var nz := world.h_vertex(i, j - 1) - world.h_vertex(i, j + 1)
					ns[o] = Vector3(nx, 2.0 * World.TCELL, nz).normalized()
					cs[o] = crow[i]
			for lj in CH:
				for li in CH:
					var a := lj * vn + li
					ix.append(a); ix.append(a + vn); ix.append(a + 1)
					ix.append(a + 1); ix.append(a + vn); ix.append(a + vn + 1)
			var arr := []
			arr.resize(Mesh.ARRAY_MAX)
			arr[Mesh.ARRAY_VERTEX] = vs
			arr[Mesh.ARRAY_NORMAL] = ns
			arr[Mesh.ARRAY_COLOR] = cs
			arr[Mesh.ARRAY_INDEX] = ix
			var am := ArrayMesh.new()
			am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
			var mi := MeshInstance3D.new()
			mi.mesh = am
			mi.material_override = mat
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(mi)
			count += 1
			if count % 12 == 0:
				progress = .45 * float(cj * nch + ci) / float(nch * nch)
				await tree.process_frame
	world.crows = []

func _sea() -> void:
	var img := world.land_image(320)
	var tx := ImageTexture.create_from_image(img)
	var sh := Shader.new()
	sh.code = """
shader_type spatial;
render_mode cull_disabled;
uniform sampler2D landtex : filter_linear, repeat_disable;
uniform float t = 0.0;
varying vec3 vw;
float ss(float a, float b, float x) { float k = clamp((x - a) / (b - a), 0.0, 1.0); return k * k * (3.0 - 2.0 * k); }
void vertex() { vw = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	vec2 p = vw.xz;
	float L = texture(landtex, (p + 1000.0) / 9600.0).r * 1000.0;
	float d = -L - 75.0;
	vec3 deep = vec3(0.05, 0.27, 0.62);
	vec3 mid = vec3(0.1, 0.58, 0.85);
	vec3 sh = vec3(0.42, 0.9, 0.86);
	vec3 c = mix(deep, mid, ss(800.0, 100.0, d));
	c = mix(c, sh, ss(220.0, 0.0, d) * 0.92);
	float w = sin(p.x * 0.09 + t * 1.3) * sin(p.y * 0.07 - t * 1.1) + sin((p.x + p.y) * 0.05 + t * 0.8);
	c += 0.045 * w;
	float sp = pow(max(0.0, sin(p.x * 0.31 + t * 2.1) * sin(p.y * 0.27 - t * 1.7)), 14.0);
	c += vec3(sp * 0.25);
	float line = smoothstep(0.84, 1.0, sin(d * 0.075 - t * 1.25 + w * 0.5)) * ss(130.0, 0.0, d) * step(0.0, d);
	c = mix(c, vec3(1.0), line * 0.75);
	c = mix(c, vec3(1.0), ss(16.0, 0.0, d) * 0.8);
	ALBEDO = pow(c, vec3(2.2));
	float dx = cos(p.x * 0.09 + t * 1.3) * 0.09 * sin(p.y * 0.07 - t * 1.1) + cos((p.x + p.y) * 0.05 + t * 0.8) * 0.05;
	float dz = sin(p.x * 0.09 + t * 1.3) * cos(p.y * 0.07 - t * 1.1) * -0.07 + cos((p.x + p.y) * 0.05 + t * 0.8) * 0.05;
	vec3 nw = normalize(vec3(-dx * 2.2, 1.0, -dz * 2.2));
	NORMAL = normalize((VIEW_MATRIX * vec4(nw, 0.0)).xyz);
	ROUGHNESS = 0.1;
	SPECULAR = 0.7;
}
"""
	sea_mat = ShaderMaterial.new()
	sea_mat.shader = sh
	sea_mat.set_shader_parameter("landtex", tx)
	var pm := PlaneMesh.new()
	pm.size = Vector2(16000, 16000)
	var mi := MeshInstance3D.new()
	mi.mesh = pm
	mi.material_override = sea_mat
	mi.position = Vector3(World.CX, -6, World.CY)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.extra_cull_margin = 16000.0
	add_child(mi)

func _mountains() -> void:
	var mm := Mat.std(Color("#6f8f86"), 1.0)
	var sm := Mat.std(Color("#f2f6fa"), .9)
	for i in 18:
		var a := i / 18.0 * TAU + randf_range(-.12, .12)
		var d := randf_range(4700, 6300)
		var r := randf_range(380, 700)
		var h := randf_range(380, 820)
		var m := Mat.mi(Mat.cone(9), mm, Vector3(r, h, r), Vector3(World.CX + cos(a) * d, h / 2 - 12, World.CY + sin(a) * d))
		add_child(m)
		var cap := Mat.mi(Mat.cone(9), sm, Vector3(r * .34, h * .3, r * .34), Vector3(m.position.x, h * .85 - 12, m.position.z))
		add_child(cap)

func _clouds() -> void:
	var tex := _cloud_tex()
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_texture = tex
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	mat.billboard_keep_scale = true
	mat.disable_fog = true
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	var q := Mat.quad(1, 1)
	for i in 44:
		var m := MeshInstance3D.new()
		m.mesh = q
		m.material_override = mat
		m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		if i < 30:
			m.position = Vector3(randf_range(-600, World.W + 600), randf_range(320, 400), randf_range(-600, World.H + 600))
			m.scale = Vector3(randf_range(300, 520), randf_range(140, 220), 1)
		else:
			var a := randf() * TAU
			var d := randf_range(4000, 5200)
			m.position = Vector3(World.CX + cos(a) * d, randf_range(140, 380), World.CY + sin(a) * d)
			m.scale = Vector3(randf_range(1100, 1800), randf_range(420, 650), 1)
		add_child(m)
		clouds.append(m)

func _cloud_tex() -> ImageTexture:
	var w := 128
	var h := 64
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	var blobs := []
	for i in 12:
		blobs.append(Vector3(randf_range(24, 104), randf_range(24, 40), randf_range(10, 22)))
	for y in h:
		for x in w:
			var a := 0.0
			for b: Vector3 in blobs:
				var d := Vector2(x - b.x, y - b.y).length() / b.z
				a = maxf(a, clampf(1.0 - d, 0.0, 1.0))
			a = a * a * (3.0 - 2.0 * a)
			var shade := 1.0 - .12 * float(y) / h
			img.set_pixel(x, y, Color(shade, shade, 1.0, a * .92))
	return ImageTexture.create_from_image(img)

# ---------- здания ----------
func _buildings() -> void:
	var th := world.th
	var plaza_cache := {}
	for t in world.towns:
		var mat := Mat.std(Color(PLAZAC[t.bi]), .95)
		var m := Mat.mi(_cyl_mesh(1, 1, 48), mat, Vector3(210, 1.2, 210), Vector3(t.x, world.th(t.x, t.y) + .55, t.y))
		m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(m)
	var plaster := Mat.tri_mat("plaster", 1.0 / 64.0, .92)
	var box := Mat.box()
	var floors_i := []
	for f in world.floors:
		var cx: float = f.x + f.w / 2
		var cz: float = f.y + f.h / 2
		floors_i.append(_it(Vector3(cx, world.th(cx, cz) + 1.2, cz), Vector3(f.w, 2.4, f.h), Color(FLOORC[f.bt % 4]).srgb_to_linear()))
	_mm_all(box, Mat.tri_mat("wood", 1.0 / 48.0, .85), floors_i, false)
	var walls := []
	var trim_t := []
	var trim_b := []
	var wins := []
	for r in world.rects:
		if r.type != "wall":
			continue
		var cx: float = r.x + r.w / 2
		var cz: float = r.y + r.h / 2
		var g := world.th(cx, cz)
		walls.append(_it(Vector3(cx, g + 25, cz), Vector3(r.w, 50, r.h), Color(WALLB[r.bi][r.bt % 4]).srgb_to_linear()))
		trim_t.append(_it(Vector3(cx, g + 51.5, cz), Vector3(r.w + 2, 3, r.h + 2), Color("#6b5a4a").srgb_to_linear()))
		trim_b.append(_it(Vector3(cx, g + 3, cz), Vector3(r.w + 1.6, 6, r.h + 1.6), Color("#8f8170").srgb_to_linear()))
		var horiz: bool = r.w >= r.h
		var ln: float = r.w if horiz else r.h
		if ln < 70.0:
			continue
		var offs := [-ln / 4.0, ln / 4.0] if ln >= 150.0 else [0.0]
		for o in offs:
			wins.append({"x": cx + o if horiz else cx, "z": cz if horiz else cz + o, "horiz": horiz, "th": r.h if horiz else r.w})
	_mm_all(box, plaster, walls, true)
	_mm_all(box, plaster, trim_t, false)
	_mm_all(box, plaster, trim_b, false)
	var frames := []
	var panes := []
	for q in wins:
		var g := world.th(q["x"], q["z"])
		var horiz: bool = q["horiz"]
		var thk: float = q["th"]
		frames.append(_it(Vector3(q["x"], g + 31, q["z"]), Vector3(29 if horiz else thk + .8, 25, thk + .8 if horiz else 29), Color("#f6f1e8").srgb_to_linear()))
		panes.append(_it(Vector3(q["x"], g + 31, q["z"]), Vector3(22 if horiz else thk + 1.8, 19, thk + 1.8 if horiz else 22), Color.WHITE))
	_mm_all(box, plaster, frames, false)
	var glass := StandardMaterial3D.new()
	glass.albedo_color = Color("#7fb4d8")
	glass.metallic = .6
	glass.roughness = .08
	glass.emission_enabled = true
	glass.emission = Color("#274a6e")
	glass.emission_energy_multiplier = .6
	glass.vertex_color_use_as_albedo = false
	_mm_all(box, glass, panes, false)
	# крыши
	var chim := Mat.std(Color("#8b4a3b"), .9)
	for i in world.floors.size():
		var f = world.floors[i]
		var cx: float = f.x + f.w / 2
		var cz: float = f.y + f.h / 2
		var base := world.th(cx, cz)
		var along: bool = f.w >= f.h
		var L: float = (f.w if along else f.h) + 18.0
		var hw: float = (f.h if along else f.w) / 2.0 + 11.0
		var roof_h := maxf(24.0, hw * .62)
		var g := Node3D.new()
		var pm := PrismMesh.new()
		pm.size = Vector3(hw * 2.0, roof_h, L)
		pm.left_to_right = .5
		var rc := Color(ROOFB[f.bi][(f.bt + i) % 5])
		var rm := Mat.tri_mat("tile", 1.0 / 40.0, .75, rc, false)
		var roof := MeshInstance3D.new()
		roof.mesh = pm
		roof.material_override = rm
		roof.position = Vector3(cx, base + 52 + roof_h / 2.0, cz)
		roof.rotation.y = PI / 2 if along else 0.0
		roof.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		g.add_child(roof)
		if i % 2 == 0:
			var ch := Mat.mi(box, chim, Vector3(8, 20, 8), Vector3(cx + (L * .28 if along else hw * .35), base + 52 + roof_h * .55 + 8, cz + (hw * .35 if along else L * .28)), true)
			g.add_child(ch)
		add_child(g)
		roofs.append({"g": g, "x": f.x, "y": f.y, "w": f.w, "h": f.h})

# ---------- природа ----------
func _nature(tree: SceneTree) -> void:
	var hi := quality == "high"
	var pines := []
	var oaks := []
	var snowp := []
	for i in world.trees.size():
		var t = world.trees[i]
		if t.b == 2:
			snowp.append(t)
		elif t.b == 4 or (t.b != 3 and i % 3 == 0):
			oaks.append(t)
		else:
			pines.append(t)
	var pine := _pine_mesh()
	var oak := _oak_mesh()
	var vmat_tree := Mat.tri_mat("bark", 1.0 / 36.0, .9, Color.WHITE, true)
	var leaf := StandardMaterial3D.new()
	leaf.vertex_color_use_as_albedo = true
	leaf.roughness = .85
	var pitems := []
	for i in pines.size():
		var t = pines[i]
		var s: float = t.r / 25.0
		var tint := Color(FTINT[i % 4] if t.b == 3 else TINT[i % 4])
		pitems.append(_it(Vector3(t.x, world.th(t.x, t.y), t.y), Vector3(s, s, s), tint, i * 1.3))
	for i in snowp.size():
		var t = snowp[i]
		var s: float = t.r / 25.0
		pitems.append(_it(Vector3(t.x, world.th(t.x, t.y), t.y), Vector3(s, s, s), Color(STINT[i % 4]), i * 1.3))
	var oitems := []
	for i in oaks.size():
		var t = oaks[i]
		var s: float = t.r / 25.0
		oitems.append(_it(Vector3(t.x, world.th(t.x, t.y), t.y), Vector3(s, s, s), Color(FTINT[i % 4] if t.b == 4 else TINT[i % 4]), i * 2.1))
	_mm_chunks(pine, leaf, pitems, 700.0, 2300.0, hi)
	_mm_chunks(oak, leaf, oitems, 700.0, 2300.0, hi)
	progress = .7
	await tree.process_frame
	# кактусы
	var citems := []
	for i in world.cacti.size():
		var k: Vector3 = world.cacti[i]
		citems.append(_it(Vector3(k.x, world.th(k.x, k.y), k.y), Vector3(k.z, k.z, k.z), Color.WHITE, i * 2.1))
	var cmat := StandardMaterial3D.new()
	cmat.vertex_color_use_as_albedo = true
	cmat.roughness = .8
	_mm_chunks(_cactus_mesh(), cmat, citems, 700.0, 1800.0, false)
	# камни
	var ritems := []
	var ritems2 := []
	var rock := _rock_mesh()
	var rmat := Mat.tri_mat("rock", 1.0 / 52.0, .95, Color.WHITE, true)
	var ri := 0
	for r in world.rects:
		if r.type != "rock":
			continue
		var cx: float = r.x + r.w / 2
		var cz: float = r.y + r.h / 2
		ritems.append(_it(Vector3(cx, world.th(cx, cz) + r.hh * .34, cz), Vector3(r.w * .66, r.hh * .78, r.h * .66), Color(ROCKB[r.bi][ri % 4]).srgb_to_linear(), ri * 2.1))
		var cx2: float = r.x + r.w * .72
		var cz2: float = r.y + r.h * .3
		ritems2.append(_it(Vector3(cx2, world.th(cx2, cz2) + r.hh * .2, cz2), Vector3(r.w * .36, r.hh * .42, r.h * .36), Color(ROCKB[r.bi][(ri + 1) % 4]).srgb_to_linear(), ri * 3.7))
		ri += 1
	_mm_chunks(rock, rmat, ritems, 700.0, 2500.0, true)
	_mm_chunks(rock, rmat, ritems2, 700.0, 2500.0, false)
	# кусты
	var bitems := []
	for i in 520:
		var x: float
		var z: float
		if i < 370 and world.trees.size() > 0:
			var t = world.trees[randi() % world.trees.size()]
			var a := randf() * TAU
			var d := randf_range(26, 60)
			x = t.x + cos(a) * d
			z = t.y + sin(a) * d
		else:
			x = randf_range(40, World.W - 40)
			z = randf_range(40, World.H - 40)
		if x < 30 or z < 30 or x > World.W - 30 or z > World.H - 30 or not world.site_ok(x, z, -90.0) or world.overlaps_floor(x - 12, z - 12, 24, 24):
			continue
		var s := randf_range(6.5, 12.5)
		bitems.append(_it(Vector3(x, world.th(x, z) + s * .45, z), Vector3(s, s * .75, s), Color(TINT[i % 4]), i * 1.0))
	_mm_chunks(_bush_mesh(), leaf, bitems, 700.0, 1400.0, false)
	progress = .85
	await tree.process_frame
	# цветы и трава
	var fitems := []
	var tries := 0
	while tries < 3200 and fitems.size() < 900:
		tries += 1
		var x := randf_range(40, World.W - 40)
		var z := randf_range(40, World.H - 40)
		var b := world.biome_at(x, z)
		if b != 1 and b != 2 and world.site_ok(x, z, -90.0) and not world.overlaps_floor(x - 6, z - 6, 12, 12):
			fitems.append(_it(Vector3(x, world.th(x, z) + 2.6, z), Vector3(1.7, 1.7, 1.7), Color(FLOWC[fitems.size() % 5])))
	var fm := StandardMaterial3D.new()
	fm.vertex_color_use_as_albedo = true
	fm.roughness = .6
	_mm_chunks(_sph_mesh(8, 4), fm, fitems, 500.0, 520.0, false)
	var titems := []
	var nT := 9000 if hi else 2500
	tries = 0
	while tries < nT * 3 and titems.size() < nT:
		tries += 1
		var x := randf_range(30, World.W - 30)
		var z := randf_range(30, World.H - 30)
		if world.land_val(x, z) > 30.0 and world.river_d(x, z) > World.RW0 + 14.0 and not world.overlaps_floor(x - 6, z - 6, 12, 12):
			var s := .55 + (titems.size() % 7) * .07
			var sn := world.grid_at(world.bgSnow, x, z)
			var tc := Color(TINT[titems.size() % 4]).lerp(Color("#cfe0ee"), clampf(sn * 1.2, 0.0, 1.0))
			titems.append(_it(Vector3(x, world.th(x, z) - .3, z), Vector3(s, s, s), tc, titems.size() * 2.4))
	var gm := StandardMaterial3D.new()
	gm.vertex_color_use_as_albedo = true
	gm.cull_mode = BaseMaterial3D.CULL_DISABLED
	gm.roughness = 1.0
	_mm_chunks(_tuft_mesh(), gm, titems, 320.0, 700.0, false)

func update_roofs(px: float, py: float, cam: Vector3) -> void:
	for r in roofs:
		var m := 16.0
		var in_p: bool = px > r["x"] - m and px < r["x"] + r["w"] + m and py > r["y"] - m and py < r["y"] + r["h"] + m
		var in_c: bool = cam.x > r["x"] - m and cam.x < r["x"] + r["w"] + m and cam.z > r["y"] - m and cam.z < r["y"] + r["h"] + m
		r["g"].visible = not (in_p or in_c)
