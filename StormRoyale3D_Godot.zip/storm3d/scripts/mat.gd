class_name Mat
extends RefCounted
## Материалы, процедурные текстуры и кэш мешей.

static var _c := {}
static var _m := {}
static var _t := {}

static func std(c: Color, rough := .8, metal := 0.0) -> StandardMaterial3D:
	var k := "s" + c.to_html(true) + str(rough) + str(metal)
	if _c.has(k):
		return _c[k]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	_c[k] = m
	return m

## Уникальная (не из кэша) копия материала с цветом
static func uniq(c: Color, rough := .75, metal := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	return m

static func unlit(c: Color, alpha := 1.0) -> StandardMaterial3D:
	var k := "u" + c.to_html(false) + str(alpha)
	if _c.has(k):
		return _c[k]
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(c.r, c.g, c.b, alpha)
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_c[k] = m
	return m

static func glow(c: Color, alpha := .3) -> StandardMaterial3D:
	var k := "g" + c.to_html(false) + str(alpha)
	if _c.has(k):
		return _c[k]
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.no_depth_test = false
	m.albedo_color = Color(c.r, c.g, c.b, alpha)
	m.disable_receive_shadows = true
	_c[k] = m
	return m

static func emissive(c: Color, energy := 1.0) -> StandardMaterial3D:
	var k := "e" + c.to_html(false) + str(energy)
	if _c.has(k):
		return _c[k]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.emission_enabled = true
	m.emission = c
	m.emission_energy_multiplier = energy
	m.roughness = .2
	_c[k] = m
	return m

# ---------- меши ----------
static func box() -> BoxMesh:
	if not _m.has("box"):
		_m["box"] = BoxMesh.new()
	return _m["box"]

static func sph(seg := 40) -> SphereMesh:
	var k := "sph" + str(seg)
	if not _m.has(k):
		var s := SphereMesh.new()
		s.radius = 1.0
		s.height = 2.0
		s.radial_segments = seg
		s.rings = maxi(8, seg / 2)
		_m[k] = s
	return _m[k]

static func hemi(seg := 32) -> SphereMesh:
	var k := "hemi" + str(seg)
	if not _m.has(k):
		var s := SphereMesh.new()
		s.radius = 1.0
		s.height = 1.0
		s.is_hemisphere = true
		s.radial_segments = seg
		s.rings = maxi(6, seg / 3)
		_m[k] = s
	return _m[k]

static func cyl(seg := 32) -> CylinderMesh:
	var k := "cyl" + str(seg)
	if not _m.has(k):
		var s := CylinderMesh.new()
		s.top_radius = 1.0
		s.bottom_radius = 1.0
		s.height = 1.0
		s.radial_segments = seg
		s.rings = 1
		_m[k] = s
	return _m[k]

static func cone(seg := 32) -> CylinderMesh:
	var k := "cone" + str(seg)
	if not _m.has(k):
		var s := CylinderMesh.new()
		s.top_radius = 0.0001
		s.bottom_radius = 1.0
		s.height = 1.0
		s.radial_segments = seg
		s.rings = 1
		_m[k] = s
	return _m[k]

static func caps(r: float, ln: float, seg := 32) -> CapsuleMesh:
	var k := "caps%s_%s_%s" % [r, ln, seg]
	if not _m.has(k):
		var s := CapsuleMesh.new()
		s.radius = r
		s.height = ln + 2.0 * r
		s.radial_segments = seg
		s.rings = 12
		_m[k] = s
	return _m[k]

static func quad(w: float, h: float) -> QuadMesh:
	var k := "quad%s_%s" % [w, h]
	if not _m.has(k):
		var q := QuadMesh.new()
		q.size = Vector2(w, h)
		_m[k] = q
	return _m[k]

static func mi(mesh: Mesh, mat: Material, s: Vector3, p: Vector3, shadow := false) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	m.mesh = mesh
	m.material_override = mat
	m.scale = s
	m.position = p
	m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return m

# ---------- текстуры ----------
static func _noise_img(sz: int, freq: float, ntype: int, sd: int, oct := 3) -> Image:
	var n := FastNoiseLite.new()
	n.noise_type = ntype
	n.frequency = freq
	n.seed = sd
	n.fractal_octaves = oct
	return n.get_seamless_image(sz, sz, false, false, 0.15, true)

static func _finish(img: Image) -> ImageTexture:
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)

static func _nrm(h: Image, scale: float) -> ImageTexture:
	var n := h.duplicate() as Image
	n.convert(Image.FORMAT_RGB8)
	n.bump_map_to_normal_map(scale)
	return _finish(n)

## Возвращает словарь {a: albedo, n: normal} по имени
static func tex_set(name: String) -> Dictionary:
	if _t.has(name):
		return _t[name]
	var sz := 128
	var img := Image.create(sz, sz, false, Image.FORMAT_RGB8)
	var hmap := Image.create(sz, sz, false, Image.FORMAT_L8)
	var ns := _noise_img(sz, .06, FastNoiseLite.TYPE_SIMPLEX_SMOOTH, 11, 4)
	var ns2 := _noise_img(sz, .22, FastNoiseLite.TYPE_SIMPLEX, 23, 2)
	var res := {}
	for y in sz:
		for x in sz:
			var a := ns.get_pixel(x, y).r
			var b := ns2.get_pixel(x, y).r
			var v := 0.0
			var hv := 0.0
			match name:
				"plaster":
					v = .8 + .12 * a + .08 * b
					hv = .5 + .25 * b
					if y % 32 < 2:
						v *= .78
						hv = .2
				"rock":
					v = .62 + .3 * a + .1 * b
					hv = .3 + .5 * a + .2 * b
				"bark":
					var st := .5 + .5 * sin(x * .6 + a * 6.0)
					v = .55 + .3 * st + .15 * b
					hv = st
				"tile":
					var row := y / 16
					var off := (row % 2) * 16
					var gx := (x + off) % 32
					v = .85 + .1 * b
					hv = .7
					if y % 16 < 2 or gx < 2:
						v = .55
						hv = .1
				"wood":
					var gr := .5 + .5 * sin((x + a * 18.0) * .55)
					v = .7 + .22 * gr + .06 * b
					hv = gr
					if x % 32 < 2:
						v = .45
						hv = .1
				"cactus":
					var rb := .5 + .5 * sin(x * 1.1)
					v = .75 + .2 * rb + .05 * b
					hv = rb
				"sand":
					v = .86 + .1 * a
					hv = a
				_:
					v = .8 + .2 * a
					hv = a
			img.set_pixel(x, y, Color(v, v, v))
			hmap.set_pixel(x, y, Color(hv, hv, hv))
	res["a"] = _finish(img)
	res["n"] = _nrm(hmap, 3.0 if name != "plaster" else 2.0)
	_t[name] = res
	return res

static func tri_mat(name: String, scale: float, rough := .9, color := Color.WHITE, vcol := true) -> StandardMaterial3D:
	var k := "tri%s%s%s%s" % [name, scale, color.to_html(), vcol]
	if _c.has(k):
		return _c[k]
	var ts := tex_set(name)
	var m := StandardMaterial3D.new()
	m.albedo_texture = ts["a"]
	m.albedo_color = color
	m.normal_enabled = true
	m.normal_texture = ts["n"]
	m.normal_scale = 1.0
	m.roughness = rough
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3(scale, scale, scale)
	m.vertex_color_use_as_albedo = vcol
	_c[k] = m
	return m

static func radial_tex(inner: Color, outer: Color, sz := 64) -> ImageTexture:
	var k := "rad" + inner.to_html() + outer.to_html()
	if _t.has(k):
		return _t[k]["a"]
	var img := Image.create(sz, sz, false, Image.FORMAT_RGBA8)
	for y in sz:
		for x in sz:
			var d := Vector2(x - sz / 2.0 + .5, y - sz / 2.0 + .5).length() / (sz / 2.0)
			var t := clampf(d, 0.0, 1.0)
			img.set_pixel(x, y, inner.lerp(outer, t * t))
	var tx := ImageTexture.create_from_image(img)
	_t[k] = {"a": tx}
	return tx

static func flash_tex() -> ImageTexture:
	if _t.has("flash"):
		return _t["flash"]["a"]
	var sz := 64
	var img := Image.create(sz, sz, false, Image.FORMAT_RGBA8)
	for y in sz:
		for x in sz:
			var d := Vector2(x - 31.5, y - 31.5).length() / 32.0
			var a := clampf(1.0 - d, 0.0, 1.0)
			var c := Color(1.0, .85 - .3 * d, .45 - .3 * d, a * a * 1.2)
			if absf(x - 31.5) < 2.0 or absf(y - 31.5) < 2.0:
				c.a = maxf(c.a, a * .95)
			img.set_pixel(x, y, c)
	var tx := ImageTexture.create_from_image(img)
	_t["flash"] = {"a": tx}
	return tx

static func billboard(tex: Texture2D, additive := false, tint := Color.WHITE) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.albedo_texture = tex
	m.albedo_color = tint
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.disable_receive_shadows = true
	if additive:
		m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	return m
