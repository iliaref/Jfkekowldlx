extends Node
## Профиль игрока: уровень, пропуск, задания, скины, магазин, бонус, статистика.

const SAVE_PATH := "user://storm_royale_save.json"

class Seeded:
	var h: int = 0
	func _init(s: String) -> void:
		h = 2166136261
		for c in s.to_utf8_buffer():
			h ^= c
			h = (h * 16777619) & 0xFFFFFFFF
	func next() -> float:
		h = (h + 0x6D2B79F5) & 0xFFFFFFFF
		var t: int = h
		t = ((t ^ (t >> 15)) * (t | 1)) & 0xFFFFFFFF
		t = t ^ ((t + (((t ^ (t >> 7)) * (t | 61)) & 0xFFFFFFFF)) & 0xFFFFFFFF)
		return float((t ^ (t >> 14)) & 0xFFFFFFFF) / 4294967296.0

var p: Dictionary = {}
var ms := {"kills": 0, "dmg": 0.0, "chests": 0, "builds": 0, "heals": 0}
var last_rew: Dictionary = {}
var granted := true

func _ready() -> void:
	load_prof()
	ensure_challenges()

func need_xp(l: int) -> int:
	return 500 + 45 * (l - 1)

func new_profile() -> Dictionary:
	return {
		"v": 1, "xp": 0, "lvl": 1, "cr": 1000, "owned": ["ranger"], "eq": "ranger", "sens": 1.0, "prem": false,
		"cF": {}, "cP": {}, "gfx": "mid" if OS.has_feature("mobile") else "high", "sound": true,
		"st": {"matches": 0, "wins": 0, "kills": 0, "dmg": 0, "time": 0.0, "best": 99, "top10": 0, "chests": 0, "builds": 0, "heals": 0},
		"ch": {"d": "", "w": "", "dl": [], "wl": []}, "bonus": {"last": "", "streak": 0},
	}

func save_prof() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(p))

func load_prof() -> void:
	p = new_profile()
	if FileAccess.file_exists(SAVE_PATH):
		var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
		if f:
			var o = JSON.parse_string(f.get_as_text())
			if o is Dictionary and int(o.get("v", 0)) == 1:
				for k in o:
					p[k] = o[k]
				var st: Dictionary = new_profile()["st"]
				for k in o.get("st", {}):
					st[k] = o["st"][k]
				p["st"] = st
				p["cF"] = _int_keys(o.get("cF", {}))
				p["cP"] = _int_keys(o.get("cP", {}))
	if not Data.SKIN.has(p["eq"]) or not (p["eq"] in p["owned"]):
		p["eq"] = "ranger"
	if not ("ranger" in p["owned"]):
		p["owned"].append("ranger")
	p["lvl"] = int(p["lvl"]); p["cr"] = int(p["cr"]); p["xp"] = int(p["xp"])

func _int_keys(d: Dictionary) -> Dictionary:
	var r := {}
	for k in d:
		r[int(k)] = d[k]
	return r

func reset_profile() -> void:
	var gfx = p.get("gfx", "high")
	p = new_profile()
	p["gfx"] = gfx
	ensure_challenges()
	save_prof()

# ---------- даты ----------
func _pad2(n: int) -> String:
	return ("0" if n < 10 else "") + str(n)

func _key_from_unix(u: int) -> String:
	var d := Time.get_datetime_dict_from_unix_time(u)
	return "%d-%s-%s" % [d["year"], _pad2(d["month"]), _pad2(d["day"])]

func _local_day_unix() -> int:
	var d := Time.get_datetime_dict_from_system(false)
	return Time.get_unix_time_from_datetime_dict({"year": d["year"], "month": d["month"], "day": d["day"], "hour": 12, "minute": 0, "second": 0})

func day_key() -> String:
	return _key_from_unix(_local_day_unix())

func yesterday_key() -> String:
	return _key_from_unix(_local_day_unix() - 86400)

func week_key() -> String:
	var d := Time.get_datetime_dict_from_system(false)
	var k := (int(d["weekday"]) + 6) % 7
	return _key_from_unix(_local_day_unix() - k * 86400)

func until_midnight() -> int:
	var d := Time.get_datetime_dict_from_system(false)
	return ((23 - int(d["hour"])) * 3600 + (59 - int(d["minute"])) * 60 + (60 - int(d["second"]))) * 1000

func until_week_days() -> int:
	var d := Time.get_datetime_dict_from_system(false)
	return 7 - ((int(d["weekday"]) + 6) % 7)

func pick_seeded(pool: Array, n: int, seed_s: String) -> Array:
	var r := Seeded.new(seed_s)
	var a := pool.duplicate()
	for i in range(a.size() - 1, 0, -1):
		var j := int(floor(r.next() * (i + 1)))
		var t = a[i]; a[i] = a[j]; a[j] = t
	return a.slice(0, n)

# ---------- задания ----------
var CH_BY := {}

func _init_ch() -> void:
	if CH_BY.is_empty():
		for c in Data.CH_DAILY + Data.CH_WEEKLY:
			CH_BY[c["id"]] = c

func ensure_challenges() -> void:
	_init_ch()
	var dk := day_key()
	var wk := week_key()
	var ch: Dictionary = p["ch"]
	if ch["d"] != dk:
		ch["d"] = dk
		ch["dl"] = []
		for c in pick_seeded(Data.CH_DAILY, 3, "d" + dk):
			ch["dl"].append({"id": c["id"], "p": 0.0, "c": false})
	if ch["w"] != wk:
		ch["w"] = wk
		ch["wl"] = []
		for c in pick_seeded(Data.CH_WEEKLY, 3, "w" + wk):
			ch["wl"].append({"id": c["id"], "p": 0.0, "c": false})

func add_xp(n: int) -> Dictionary:
	var from: int = p["lvl"]
	p["xp"] += n
	while p["xp"] >= need_xp(p["lvl"]):
		p["xp"] -= need_xp(p["lvl"])
		p["lvl"] += 1
	return {"from": from, "to": p["lvl"]}

func claim_challenge(id: String) -> Dictionary:
	ensure_challenges()
	for l in [p["ch"]["dl"], p["ch"]["wl"]]:
		for q in l:
			if q["id"] == id:
				var d: Dictionary = CH_BY[id]
				if q["c"] or q["p"] < d["g"]:
					return {}
				q["c"] = true
				var r := add_xp(d["xp"])
				p["cr"] += 100 if d["xp"] >= 2000 else 40
				save_prof()
				return r
	return {}

func challenges_ready() -> bool:
	ensure_challenges()
	for l in [p["ch"]["dl"], p["ch"]["wl"]]:
		for q in l:
			if not q["c"] and q["p"] >= CH_BY[q["id"]]["g"]:
				return true
	return false

# ---------- боевой пропуск ----------
func pass_reward(t: int, prem: bool) -> Dictionary:
	if prem:
		if Data.PASS_SKINS.has(t):
			return {"k": "skin", "id": Data.PASS_SKINS[t]}
		return {"k": "cr", "n": 100 + (150 if t % 5 == 0 else 0) + int(t / 10) * 20}
	if Data.FREE_SKINS.has(t):
		return {"k": "skin", "id": Data.FREE_SKINS[t]}
	if t == 50:
		return {"k": "cr", "n": 500}
	if t % 2 == 0:
		return {"k": "cr", "n": 40 + t}
	return {}

func give_reward(rw: Dictionary) -> void:
	if rw.is_empty():
		return
	if rw["k"] == "cr":
		p["cr"] += int(rw["n"])
	elif rw["k"] == "skin" and not (rw["id"] in p["owned"]):
		p["owned"].append(rw["id"])

func claim_tier(t: int, prem: bool) -> bool:
	if t > mini(Data.PASS_TIERS, p["lvl"]) or (prem and not p["prem"]):
		return false
	var m: Dictionary = p["cP"] if prem else p["cF"]
	if m.has(t):
		return false
	var rw := pass_reward(t, prem)
	if rw.is_empty():
		return false
	m[t] = 1
	give_reward(rw)
	save_prof()
	return true

func claim_all_tiers() -> int:
	var n := 0
	for t in range(1, mini(Data.PASS_TIERS, p["lvl"]) + 1):
		if claim_tier(t, false):
			n += 1
		if claim_tier(t, true):
			n += 1
	return n

func ready_tiers() -> int:
	var n := 0
	for t in range(1, mini(Data.PASS_TIERS, p["lvl"]) + 1):
		if not pass_reward(t, false).is_empty() and not p["cF"].has(t):
			n += 1
		if p["prem"] and not pass_reward(t, true).is_empty() and not p["cP"].has(t):
			n += 1
	return n

func buy_pass() -> bool:
	if p["prem"] or p["cr"] < Data.PASS_PRICE:
		return false
	p["cr"] -= Data.PASS_PRICE
	p["prem"] = true
	save_prof()
	return true

# ---------- магазин ----------
func shop_items() -> Dictionary:
	var pool := []
	for s in Data.SKINS:
		if s["src"] == "shop":
			pool.append(s)
	var dk := day_key()
	var epic := pool.filter(func(s): return s["r"] == "epic" or s["r"] == "legendary")
	var big := pick_seeded(epic, 2, "f" + dk)
	var rest := pool.filter(func(s): return not (s in big))
	return {"feat": big, "daily": pick_seeded(rest, 4, "x" + dk)}

func buy_skin(id: String) -> bool:
	var s = Data.SKIN.get(id)
	if s == null or s["src"] != "shop" or id in p["owned"] or p["cr"] < s["p"]:
		return false
	p["cr"] -= int(s["p"])
	p["owned"].append(id)
	save_prof()
	return true

func equip_skin(id: String) -> bool:
	if id in p["owned"]:
		p["eq"] = id
		save_prof()
		return true
	return false

# ---------- ежедневный бонус ----------
func bonus_state() -> Dictionary:
	var today := day_key()
	var can: bool = p["bonus"]["last"] != today
	var streak: int = int(p["bonus"]["streak"])
	if can:
		streak = streak if p["bonus"]["last"] == yesterday_key() else 0
	return {"can": can, "streak": streak, "next": (streak % 7) if can else -1}

func claim_bonus() -> int:
	var b := bonus_state()
	if not b["can"]:
		return 0
	var amt: int = Data.BONUS[int(b["streak"]) % 7]
	p["cr"] += amt
	p["bonus"]["last"] = day_key()
	p["bonus"]["streak"] = int(b["streak"]) + 1
	save_prof()
	return amt

# ---------- результаты матча ----------
func begin_match_stats() -> void:
	ms = {"kills": 0, "dmg": 0.0, "chests": 0, "builds": 0, "heals": 0}
	granted = false

func grant_match(finished: bool, won: bool, final_place: int, clock: float, kills: int) -> Dictionary:
	if granted:
		return last_rew
	granted = true
	ensure_challenges()
	var place := (1 if won else final_place) if finished else 99
	var secs := maxf(0.0, clock)
	var dmg := int(round(ms["dmg"]))
	var xp := int(round(minf(secs, 720.0) / 60.0 * 25.0)) + kills * 70 + mini(150, int(round(dmg * .1)))
	var pb := 500 if place == 1 else (250 if place <= 5 else (150 if place <= 10 else (50 if place <= 25 else 0)))
	xp += pb
	var cr := 3 * (kills * 15 + (150 if place == 1 else (60 if place <= 5 else (30 if place <= 10 else 10))))
	var st: Dictionary = p["st"]
	st["matches"] += 1
	if place == 1:
		st["wins"] += 1
	st["kills"] += kills; st["dmg"] += dmg; st["time"] += secs
	st["chests"] += ms["chests"]; st["builds"] += ms["builds"]; st["heals"] += ms["heals"]
	if place <= 10:
		st["top10"] += 1
	if place < st["best"]:
		st["best"] = place
	var add := {"kills": kills, "dmg": dmg, "chests": ms["chests"], "builds": ms["builds"], "heals": ms["heals"], "mins": secs / 60.0, "matches": 1, "top10": 1 if place <= 10 else 0, "wins": 1 if place == 1 else 0}
	for l in [p["ch"]["dl"], p["ch"]["wl"]]:
		for q in l:
			var d: Dictionary = CH_BY[q["id"]]
			if not q["c"]:
				q["p"] = minf(float(d["g"]), q["p"] + float(add.get(d["s"], 0)))
	var tiers_before := ready_tiers()
	var lv := add_xp(xp)
	p["cr"] += cr
	save_prof()
	var done := 0
	for l in [p["ch"]["dl"], p["ch"]["wl"]]:
		for q in l:
			if not q["c"] and q["p"] >= CH_BY[q["id"]]["g"]:
				done += 1
	last_rew = {"xp": xp, "cr": cr, "place": place, "kills": kills, "from": lv["from"], "to": lv["to"], "pb": pb, "newTiers": maxi(0, ready_tiers() - tiers_before), "done": done}
	return last_rew
