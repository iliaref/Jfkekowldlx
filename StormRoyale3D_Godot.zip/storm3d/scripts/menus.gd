class_name Menus
extends Control
## Пауза, итоги матча, экран загрузки.

signal resumed
signal quit_menu
signal again
signal toggle_auto(on: bool)

var root: Control
var load_bar: Lobby.Bar
var load_lbl: Label
var load_pan: Control

func _fit() -> void:
	position = Vector2.ZERO
	size = get_viewport_rect().size

func _ready() -> void:
	get_viewport().size_changed.connect(_fit)
	_fit()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _lbl(t: String, size := 18, col := Color.WHITE, al := HORIZONTAL_ALIGNMENT_CENTER) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_constant_override("outline_size", 4)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, .6))
	l.horizontal_alignment = al
	return l

func _btn(t: String, cb: Callable, col := Lobby.GOLD, h := 54.0, dark := true) -> Button:
	var b := Button.new()
	b.text = t
	b.custom_minimum_size = Vector2(340, h)
	b.add_theme_font_size_override("font_size", 20)
	var fc := Color("#1a1204") if dark else Color.WHITE
	for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		b.add_theme_color_override(k, fc)
	for st in ["normal", "hover", "pressed", "focus"]:
		var s := StyleBoxFlat.new()
		s.bg_color = col if st != "pressed" else col.darkened(.2)
		s.set_corner_radius_all(12)
		b.add_theme_stylebox_override(st, s)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(cb)
	return b

func clear() -> void:
	if root:
		root.queue_free()
		root = null
	load_pan = null

func _base(dim := .72) -> VBoxContainer:
	clear()
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(root)
	var d := ColorRect.new()
	d.color = Color(.02, .04, .09, dim)
	d.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(d)
	var c := CenterContainer.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(c)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	c.add_child(v)
	return v

func show_pause(auto_on: bool) -> void:
	var v := _base()
	v.add_child(_lbl("Пауза", 42, Lobby.GOLD))
	v.add_child(_btn("ПРОДОЛЖИТЬ", func(): clear(); resumed.emit()))
	var sr := HBoxContainer.new()
	sr.add_theme_constant_override("separation", 10)
	v.add_child(sr)
	sr.add_child(_lbl("Чувствительность", 17))
	var sl := HSlider.new()
	sl.min_value = .5
	sl.max_value = 2.0
	sl.step = .05
	sl.value = Prof.p.get("sens", 1.0)
	sl.custom_minimum_size = Vector2(170, 30)
	sr.add_child(sl)
	sl.value_changed.connect(func(x: float): Prof.p["sens"] = x; Prof.save_prof())
	var snd := _btn("Звук: " + ("вкл" if Prof.p.get("sound", true) else "выкл"), func(): pass, Color(1, 1, 1, .14), 46, false)
	snd.pressed.connect(func():
		Prof.p["sound"] = not Prof.p.get("sound", true)
		Prof.save_prof()
		snd.text = "Звук: " + ("вкл" if Prof.p["sound"] else "выкл"))
	v.add_child(snd)
	var au := _btn("Автоогонь: " + ("вкл" if auto_on else "выкл"), func(): pass, Color(1, 1, 1, .14), 46, false)
	var st := [auto_on]
	au.pressed.connect(func():
		st[0] = not st[0]
		au.text = "Автоогонь: " + ("вкл" if st[0] else "выкл")
		toggle_auto.emit(st[0]))
	v.add_child(au)
	v.add_child(_btn("В МЕНЮ", func(): clear(); quit_menu.emit(), Color(1, 1, 1, .14), 46, false))

func show_end(g: Game, rw: Dictionary) -> void:
	var v := _base(.78)
	var won := g.won
	v.add_child(_lbl("Победа!" if won else "Вы выбыли", 46, Color("#ffd23c") if won else Color("#ff8a7a")))
	var sub := "Вы последний выживший" if won else ("Вас устранил: " + g.killer_name if g.killer_name != "" else "Вас накрыла буря")
	v.add_child(_lbl(sub, 18, Color(1, 1, 1, .8)))
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.add_theme_constant_override("separation", 14)
	v.add_child(h)
	var secs := int(g.clock)
	for c in [["#%d" % (1 if won else g.final_place), "Место"], [str(g.player.kills), "Убийств"], ["%d:%02d" % [secs / 60, secs % 60], "Время"]]:
		var p := PanelContainer.new()
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(1, 1, 1, .08)
		sb.set_corner_radius_all(10)
		sb.content_margin_left = 22
		sb.content_margin_right = 22
		sb.content_margin_top = 8
		sb.content_margin_bottom = 8
		p.add_theme_stylebox_override("panel", sb)
		var cv := VBoxContainer.new()
		p.add_child(cv)
		cv.add_child(_lbl(c[0], 30))
		cv.add_child(_lbl(c[1], 13, Color(1, 1, 1, .6)))
		h.add_child(p)
	if not rw.is_empty():
		var need := Prof.need_xp(Prof.p["lvl"])
		var rv := VBoxContainer.new()
		rv.custom_minimum_size = Vector2(420, 0)
		v.add_child(rv)
		rv.add_child(_lbl("Опыт  +%d XP" % rw["xp"], 18, Lobby.GOLD))
		var b := Lobby.Bar.new()
		b.frac = float(Prof.p["xp"]) / need
		b.col = Lobby.GOLD
		b.custom_minimum_size = Vector2(0, 14)
		rv.add_child(b)
		rv.add_child(_lbl("Уровень %d · %d / %d" % [Prof.p["lvl"], Prof.p["xp"], need], 14, Color(1, 1, 1, .7)))
		rv.add_child(_lbl("Кристаллы  +%d ◆" % rw["cr"], 18, Color("#7fe0ff")))
		if rw["to"] > rw["from"]:
			rv.add_child(_lbl("НОВЫЙ УРОВЕНЬ: %d → %d" % [rw["from"], rw["to"]], 20, Color("#ffd23c")))
		if rw["newTiers"] > 0:
			rv.add_child(_lbl("Доступны награды пропуска: %d" % rw["newTiers"], 15, Color("#5fd97a")))
		if rw["done"] > 0:
			rv.add_child(_lbl("Задания выполнены — заберите награду", 15, Color("#5fd97a")))
	v.add_child(_btn("ЕЩЁ РАЗ", func(): clear(); again.emit()))
	v.add_child(_btn("В МЕНЮ", func(): clear(); quit_menu.emit(), Color(1, 1, 1, .14), 46, false))

func show_loading(txt: String, frac: float) -> void:
	if load_pan == null:
		clear()
		root = Control.new()
		root.set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(root)
		var d := ColorRect.new()
		d.color = Color("#07101e")
		d.set_anchors_preset(Control.PRESET_FULL_RECT)
		root.add_child(d)
		var c := CenterContainer.new()
		c.set_anchors_preset(Control.PRESET_FULL_RECT)
		root.add_child(c)
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 14)
		c.add_child(v)
		v.add_child(_lbl("STORM ROYALE", 44, Lobby.GOLD))
		load_lbl = _lbl(txt, 18)
		v.add_child(load_lbl)
		load_bar = Lobby.Bar.new()
		load_bar.col = Lobby.GOLD
		load_bar.custom_minimum_size = Vector2(420, 14)
		v.add_child(load_bar)
		load_pan = v
	load_lbl.text = txt
	load_bar.frac = frac
	load_bar.queue_redraw()
