class_name Sfx
extends Node
## Простой синтезатор звуков (без внешних файлов).

var enabled := true
var _cache := {}
var _players: Array = []
var _next := 0

func _ready() -> void:
	for i in 12:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)

func tone(f: float, d: float, wave: String = "square", vol: float = .05, slide: float = 1.0) -> void:
	if not enabled:
		return
	var key := "%d_%d_%s_%d_%d" % [int(f / 10.0), int(d * 100.0), wave, int(vol * 1000.0), int(slide * 10.0)]
	var st: AudioStreamWAV = _cache.get(key)
	if st == null:
		st = _make(f, d, wave, vol, slide)
		_cache[key] = st
	var p: AudioStreamPlayer = _players[_next]
	_next = (_next + 1) % _players.size()
	p.stream = st
	p.play()

func _make(f: float, d: float, wave: String, vol: float, slide: float) -> AudioStreamWAV:
	var rate := 22050
	var n := int(rate * (d + .02))
	var data := PackedByteArray()
	data.resize(n * 2)
	var ph := 0.0
	for i in n:
		var t := float(i) / rate
		var k := t / maxf(d, .001)
		var fr := f * pow(slide, k) if slide != 1.0 else f
		ph += fr / rate
		var s := 0.0
		var frac := ph - floorf(ph)
		match wave:
			"sine":
				s = sin(ph * TAU)
			"triangle":
				s = 4.0 * absf(frac - .5) - 1.0
			"sawtooth":
				s = 2.0 * frac - 1.0
			_:
				s = 1.0 if frac < .5 else -1.0
		var env := exp(-k * 6.0) if t < d else 0.0
		var v := int(clampf(s * env * vol * 6.0, -1.0, 1.0) * 32000.0)
		data.encode_s16(i * 2, v)
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.data = data
	return w
