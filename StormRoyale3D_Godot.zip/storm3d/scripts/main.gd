extends Node
## Оркестрация: лобби → загрузка → матч → итоги.

var sfx: Sfx
var game: Game
var views: Views
var wmesh: WorldMesh
var hud: Hud
var lobby: Lobby
var menus: Menus
var scene3d: Node3D
var in_match := false
var last_diff := "normal"
var autostart := false
var shot_path := ""
var shot_after := 0.0
var t_run := 0.0
var start_tab := ""
var demo := ""
var post_t := 0.0

func _ready() -> void:
	randomize()
	sfx = Sfx.new()
	add_child(sfx)
	sfx.enabled = Prof.p.get("sound", true)
	game = Game.new()
	game.sfx = sfx
	add_child(game)
	scene3d = Node3D.new()
	add_child(scene3d)
	var cl_hud := CanvasLayer.new()
	cl_hud.layer = 10
	add_child(cl_hud)
	hud = Hud.new()
	cl_hud.add_child(hud)
	hud.pause_pressed.connect(_pause)
	var cl_lb := CanvasLayer.new()
	cl_lb.layer = 5
	add_child(cl_lb)
	lobby = Lobby.new()
	cl_lb.add_child(lobby)
	lobby.play_requested.connect(start_match)
	var cl_m := CanvasLayer.new()
	cl_m.layer = 20
	add_child(cl_m)
	menus = Menus.new()
	cl_m.add_child(menus)
	menus.resumed.connect(_resume)
	menus.quit_menu.connect(to_menu)
	menus.again.connect(func(): start_match(last_diff))
	menus.toggle_auto.connect(func(on: bool): game.auto_fire = on)
	game.match_over.connect(_on_over)
	hud.visible = false
	for a in OS.get_cmdline_user_args():
		if a == "--autostart":
			autostart = true
		elif a.begins_with("--shot="):
			shot_path = a.substr(7)
		elif a.begins_with("--demo="):
			demo = a.substr(7)
		elif a.begins_with("--tab="):
			start_tab = a.substr(6)
		elif a.begins_with("--shotafter="):
			shot_after = float(a.substr(12))
	get_tree().root.focus_exited.connect(_focus_lost)
	if autostart:
		start_match("normal")
	else:
		to_menu()
		if start_tab != "":
			lobby._tab_click(start_tab)
		if shot_path != "":
			await get_tree().create_timer(shot_after + 1.5).timeout
			_shot()

func _shot() -> void:
	var img := get_viewport().get_texture().get_image()
	img.save_png(shot_path)
	print("shot saved ", shot_path)
	get_tree().quit()

func _focus_lost() -> void:
	if in_match and game.running and not game.ended and not game.paused:
		_pause()

func to_menu() -> void:
	if in_match and game.running and not game.ended and game.clock > 15.0:
		Prof.grant_match(false, false, 99, game.clock, game.player.kills)
	in_match = false
	game.running = false
	game.paused = false
	hud.set_active(false)
	hud.visible = false
	menus.clear()
	if views:
		views.queue_free()
		views = null
	if wmesh:
		wmesh.queue_free()
		wmesh = null
	lobby.open()

func start_match(diff: String) -> void:
	last_diff = diff
	lobby.close()
	menus.clear()
	hud.visible = false
	game.running = false
	if views:
		views.queue_free()
		views = null
	if wmesh:
		wmesh.queue_free()
		wmesh = null
	sfx.enabled = Prof.p.get("sound", true)
	menus.show_loading("Создаём остров…", .02)
	await get_tree().process_frame
	await get_tree().process_frame
	var t0 := Time.get_ticks_msec()
	var w := World.new()
	w.gen_map()
	menus.show_loading("Рельеф…", .1)
	var gid := w.start_height_job()
	while not WorkerThreadPool.is_group_task_completed(gid):
		await get_tree().process_frame
	w.finish_height_job(gid)
	menus.show_loading("Строим мир…", .25)
	await get_tree().process_frame
	var q: String = Prof.p.get("gfx", "high")
	wmesh = WorldMesh.new()
	scene3d.add_child(wmesh)
	var bt := Timer.new()
	bt.wait_time = .1
	bt.autostart = true
	wmesh.add_child(bt)
	bt.timeout.connect(func(): menus.show_loading("Строим мир…", .25 + wmesh.progress * .7))
	await wmesh.build(w, q, get_tree())
	menus.show_loading("Почти готово…", .97)
	await get_tree().process_frame
	views = Views.new()
	scene3d.add_child(views)
	views.setup(game, wmesh, q)
	apply_quality(q)
	var skin: Dictionary = Data.SKIN[Prof.p["eq"]]
	var look := {}
	for k in skin:
		look[k] = skin[k]
	for k in ["top", "acc", "pants", "hair", "hatc", "glide", "tone"]:
		look[k] = Color(skin[k])
	game.begin(w, last_diff, look)
	game.cam_aspect = get_viewport().get_visible_rect().size.aspect()
	game.running = true
	game.paused = false
	game.update_camera(.016)
	views.sync(.016)
	hud.start(game, w.minimap_image(220))
	hud.visible = true
	menus.clear()
	in_match = true
	t_run = 0.0
	game.banner("Выберите момент и прыгайте с автобуса!")
	print("match ready in ", Time.get_ticks_msec() - t0, " ms")

func apply_quality(q: String) -> void:
	var vp := get_viewport()
	match q:
		"low":
			vp.msaa_3d = Viewport.MSAA_DISABLED
			vp.scaling_3d_scale = .75
		"mid":
			vp.msaa_3d = Viewport.MSAA_2X
			vp.scaling_3d_scale = .9
		_:
			vp.msaa_3d = Viewport.MSAA_4X
			vp.scaling_3d_scale = 1.0

func _pause() -> void:
	if not in_match or game.ended or game.paused:
		return
	game.paused = true
	hud.set_active(false)
	menus.show_pause(game.auto_fire)

func _resume() -> void:
	game.paused = false
	hud.set_active(true)

func _on_over(won: bool) -> void:
	hud.set_active(false)
	game.running = false
	var rw := Prof.grant_match(true, won, game.final_place, game.clock, game.player.kills)
	menus.show_end(game, rw)

func _process(dt: float) -> void:
	if in_match and shot_path != "" and not game.running:
		post_t += dt
		if post_t > 1.0:
			_shot()
	if not in_match or not game.running:
		return
	t_run += dt
	game.cam_aspect = get_viewport().get_visible_rect().size.aspect()
	if not game.paused:
		var d := minf(dt, .05)
		game.update(d)
		game.update_camera(d)
	if demo != "" and t_run > 3.0:
		var d := demo
		demo = ""
		if d == "pause":
			_pause()
		else:
			game.won = true
			game.final_place = 1
			game.player.kills = 4
			_on_over(true)
	if autostart:
		var pl := game.player
		if pl.air == 1 and t_run > 1.5:
			game.player_jump()
		elif pl.air == 2 and pl.alt < Game.BUS_ALT - 120.0 and t_run > 4.0:
			game.player_jump()
		elif pl.air == 0 and pl.alive:
			game.inp_my = -1.0
			game.inp_fire = int(t_run) % 3 == 0
			game.inp_build = int(t_run) % 7 == 0
			game.cam_yaw += dt * (1.2 if int(t_run / 5.0) % 2 == 0 else -.6)
			if int(t_run * 2.0) % 11 == 0:
				game.start_use(pl)
				game.ads_on = not game.ads_on
				game.start_reload(pl)
				game.start_emote(1 + randi() % 4)
			if int(t_run) % 9 == 0:
				game.player.cur = Data.WORDER[randi() % 5] if game.player.inv.size() > 1 else "pistol"
	views.sync(dt if not game.paused else 0.0)
	if shot_path != "" and t_run > shot_after:
		_shot()
