class_name Types
extends RefCounted
## Лёгкие структуры данных мира.

class Rc:
	var x := 0.0
	var y := 0.0
	var w := 0.0
	var h := 0.0
	var type := "wall"
	var bt := 0
	var bi := 0
	var hh := 30.0
	var hp := 200.0
	var mx := 200.0
	var fl := 0.0
	var t0 := 0.0
	var gone := false
	var view = null

class Tr:
	var x := 0.0
	var y := 0.0
	var r := 20.0
	var tr := 10.0
	var b := 0

class Item:
	var x := 0.0
	var y := 0.0
	var k := "w"
	var w := ""
	var rar := 0
	var amt := 0
	var gone := false
	var view = null

class Chest:
	var x := 0.0
	var y := 0.0
	var open := false
	var t := 0.0
	var drop := false
	var view = null

class Flr:
	var x := 0.0
	var y := 0.0
	var w := 0.0
	var h := 0.0
	var bt := 0
	var bi := 0

class Town:
	var x := 0.0
	var y := 0.0
	var name := ""
	var bi := 0
	var big := false

class Part:
	var x := 0.0
	var y := 0.0
	var z := 0.0
	var vx := 0.0
	var vy := 0.0
	var vz := 0.0
	var l := 0.0
	var col := Color.WHITE

class Bullet:
	var x := 0.0
	var y := 0.0
	var z := 0.0
	var vx := 0.0
	var vy := 0.0
	var vz := 0.0
	var dmg := 0.0
	var life := 0.0
	var own := 0
	var col := Color.WHITE

class DmgNum:
	var x := 0.0
	var y := 0.0
	var v := 0
	var t := 0.0
	var big := false

class DmgDir:
	var x := 0.0
	var y := 0.0
	var t := 0.0
