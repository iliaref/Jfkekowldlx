class_name Views
extends Node3D
## Синхронизация состояния игры с 3D-сценой: камера, свет, персонажи, лут, стены, пули, буря.

const EMOTES := ["Танец", "Привет", "Сила", "Вертушка"]

var game: Game
var wm: WorldMesh
var cam: Camera3D
var sun: DirectionalLight3D
var env: Environment
var wenv: WorldEnvironment
var quality := "high"
var tm := 0.0
var scan_t := 0.0
var cviews := {}
var bus_node: Node3D
var storm_wall: MeshInstance3D
var next_ring: MeshInstance3D
var storm_mat: ShaderMaterial
var ring_mat: ShaderMaterial
var bullet_mm: MultiMeshInstance3D
var part_mm: MultiMeshInstance3D
var dnum_pool: Array = []
var chest_views := {}
var loot_views := {}
var wall_views: Array = []
var muzzle: OmniLight3D
var bar_shader: Shader
var open_t := {}

func setup(g: Game, wmesh: WorldMesh, q: String) -> void:
	game = g
	wm = wmesh
	quality = q
	_build_env()
	_build_storm()
	_build_pools()
	bus_node = Models.make_bus()
	bus_node.visible = false
	add_child(bus_node)

func _build_env() -> void:
	var sky_m := ProceduralSkyMaterial.new()
	sky_m.sky_top_color = Color("#2f7fd6")
	sky_m.sky_horizon_color = Color("#bfe0f5")
	sky_m.ground_horizon_color = Color("#bfe0f5")
	sky_m.ground_bottom_color = Color("#8fb6cf")
	sky_m.sun_angle_max = 25.0
	sky_m.sun_curve = .12
	var sky := Sky.new()
	sky.sky_material = sky_m
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = .45
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = .9
	env.tonemap_white = 6.0
	env.fog_enabled = true
	env.fog_light_color = Color("#c4dff0")
	env.fog_density = .00011
	env.fog_sky_affect = .35
	env.fog_aerial_perspective = .4
	env.adjustment_enabled = true
	env.adjustment_saturation = 1.12
	env.adjustment_contrast = 1.06
	if quality != "low":
		env.glow_enabled = true
		env.glow_intensity = .5
		env.glow_bloom = .05
		env.glow_hdr_threshold = 1.15
	wenv = WorldEnvironment.new()
	wenv.environment = env
	add_child(wenv)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -38, 0)
	sun.light_color = Color("#fff1d6")
	sun.light_energy = .85
	sun.shadow_enabled = quality != "low"
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL if quality == "low" else DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	sun.directional_shadow_max_distance = 900.0 if quality == "high" else 600.0
	sun.directional_shadow_split_1 = .06
	sun.directional_shadow_split_2 = .2
	sun.directional_shadow_split_3 = .5
	sun.shadow_bias = .06
	sun.shadow_normal_bias = 1.2
	add_child(sun)
	cam = Camera3D.new()
	cam.near = 2.0
	cam.far = 14000.0
	cam.fov = 68.0
	add_child(cam)
	muzzle = OmniLight3D.new()
	muzzle.light_color = Color("#ffcf86")
	muzzle.omni_range = 160.0
	muzzle.light_energy = 0.0
	muzzle.shadow_enabled = false
	add_child(muzzle)

func _build_storm() -> void:
	var sh := Shader.new()
	sh.code = """
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_never, blend_mix, fog_disabled;
uniform vec4 col : source_color = vec4(.6,.2,1.,1.);
uniform float t = 0.0;
uniform float strength = 1.0;
varying vec3 wp;
void vertex() { wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	float ang = atan(wp.z, wp.x);
	float s1 = sin(ang * 90.0 + wp.y * .012 - t * 1.2);
	float s2 = sin(ang * 37.0 - wp.y * .02 + t * .8);
	float band = .5 + .25 * s1 + .25 * s2;
	float fade = clamp(1.0 - wp.y / 1500.0, 0.0, 1.0);
	float edge = smoothstep(0.0, 120.0, wp.y) * .0 + exp(-wp.y * .004);
	ALBEDO = col.rgb * (.7 + band * .6 + edge * .8);
	ALPHA = clamp((.16 + band * .22 + edge * .35) * fade * strength, 0.0, .85);
}
"""
	storm_mat = ShaderMaterial.new()
	storm_mat.shader = sh
	storm_mat.set_shader_parameter("col", Color("#9a3cff"))
	var cm := CylinderMesh.new()
	cm.top_radius = 1.0
	cm.bottom_radius = 1.0
	cm.height = 1.0
	cm.radial_segments = 160
	cm.rings = 1
	cm.cap_top = false
	cm.cap_bottom = false
	storm_wall = MeshInstance3D.new()
	storm_wall.mesh = cm
	storm_wall.material_override = storm_mat
	storm_wall.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	storm_wall.extra_cull_margin = 20000.0
	add_child(storm_wall)
	ring_mat = ShaderMaterial.new()
	ring_mat.shader = sh
	ring_mat.set_shader_parameter("col", Color("#ffffff"))
	ring_mat.set_shader_parameter("strength", .55)
	next_ring = MeshInstance3D.new()
	next_ring.mesh = cm
	next_ring.material_override = ring_mat
	next_ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	next_ring.extra_cull_margin = 20000.0
	add_child(next_ring)

func _build_pools() -> void:
	# пули
	var bm := BoxMesh.new()
	bm.size = Vector3(.9, .9, 20.0)
	var bmat := StandardMaterial3D.new()
	bmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bmat.vertex_color_use_as_albedo = true
	bmat.albedo_color = Color(1.6, 1.6, 1.6)
	bmat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	bmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bmat.disable_fog = true
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.mesh = bm
	mm.instance_count = 160
	mm.visible_instance_count = 0
	bullet_mm = MultiMeshInstance3D.new()
	bullet_mm.multimesh = mm
	bullet_mm.material_override = bmat
	bullet_mm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	bullet_mm.extra_cull_margin = 20000.0
	add_child(bullet_mm)
	# частицы
	var pm := BoxMesh.new()
	pm.size = Vector3(1, 1, 1)
	var pmat := StandardMaterial3D.new()
	pmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	pmat.vertex_color_use_as_albedo = true
	var mm2 := MultiMesh.new()
	mm2.transform_format = MultiMesh.TRANSFORM_3D
	mm2.use_colors = true
	mm2.mesh = pm
	mm2.instance_count = 420
	mm2.visible_instance_count = 0
	part_mm = MultiMeshInstance3D.new()
	part_mm.multimesh = mm2
	part_mm.material_override = pmat
	part_mm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	part_mm.extra_cull_margin = 20000.0
	add_child(part_mm)
	# цифры урона
	for i in 14:
		var l := Label3D.new()
		l.font_size = 56
		l.pixel_size = .2
		l.outline_size = 14
		l.outline_modulate = Color(0, 0, 0, .85)
		l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		l.no_depth_test = true
		l.render_priority = 9
		l.visible = false
		add_child(l)
		dnum_pool.append(l)
	bar_shader = Shader.new()
	bar_shader.code = """
shader_type spatial;
render_mode unshaded, depth_test_disabled, cull_disabled, fog_disabled;
uniform vec4 col : source_color = vec4(1.);
uniform float frac = 1.0;
void vertex() {
	MODELVIEW_MATRIX = VIEW_MATRIX * mat4(INV_VIEW_MATRIX[0], INV_VIEW_MATRIX[1], INV_VIEW_MATRIX[2], MODEL_MATRIX[3]);
}
void fragment() {
	if (UV.x > frac) discard;
	ALBEDO = col.rgb;
	ALPHA = col.a;
}
"""

func _bar_mat(c: Color, prio: int) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = bar_shader
	m.set_shader_parameter("col", c)
	m.render_priority = prio
	return m

func _ensure_char(e: Ent) -> Models.CharView:
	var v: Models.CharView = cviews.get(e.id)
	if v:
		return v
	v = Models.make_char(e, e.look, e.bot)
	add_child(v.root)
	if v.bg:
		var q := QuadMesh.new()
		q.size = Vector2(30, 3.2)
		v.bg.mesh = q
		v.fg.mesh = q
		v.shd.mesh = q
		v.bg.material_override = _bar_mat(Color(0, 0, 0, .6), 6)
		v.fg.material_override = _bar_mat(Color("#5fd97a"), 7)
		v.shd.material_override = _bar_mat(Color("#4fb3ff"), 7)
		v.bg.position = Vector3(0, 49, 0)
		v.fg.position = Vector3(0, 49, 0)
		v.shd.position = Vector3(0, 52.4, 0)
		v.bg.scale = Vector3.ONE
		v.fg.scale = Vector3.ONE
		v.shd.scale = Vector3.ONE
		v.name_l.position = Vector3(0, 58, 0)
	cviews[e.id] = v
	e.view = v
	return v

func clear_all() -> void:
	for k in cviews:
		cviews[k].root.queue_free()
	cviews.clear()
	for k in chest_views:
		chest_views[k].queue_free()
	chest_views.clear()
	for k in loot_views:
		loot_views[k].queue_free()
	loot_views.clear()
	for w in wall_views:
		w["n"].queue_free()
	wall_views.clear()

func _lerp_ang(a: float, b: float, k: float) -> float:
	return a + angle_difference(a, b) * k

# ---------- персонажи ----------
func _sync_char(e: Ent, dt: float) -> void:
	var v := _ensure_char(e)
	var vis := e.alive and e.air != 1
	if vis and e != game.player:
		var dc := Vector2(e.x - game.cam_pos.x, e.y - game.cam_pos.z).length()
		if dc > 3200.0 and e.air == 0:
			vis = false
	v.root.visible = vis
	if not vis:
		return
	var gy := game.world.th(e.x, e.y)
	var lift := e.alt if e.air > 0 else 0.0
	v.root.position = Vector3(e.x, gy + lift, e.y)
	v.body.rotation.y = -e.ang
	v.sh.visible = e.air == 0 or lift < 300.0
	v.sh.position.y = -lift + .5
	v.sh.scale = Vector3.ONE * (1.0 + lift * .002)
	var moving := Vector2(e.mx, e.my).length()
	var sw := sin(e.ph) * .75 * minf(1.0, moving * 1.2)
	var gun := game.has_gun(e) and e.using <= 0.0
	var t := tm
	var body := v.body
	body.rotation.z = 0.0
	body.rotation.x = 0.0
	body.position = Vector3.ZERO
	v.legL.rotation.z = sw
	v.legR.rotation.z = -sw
	v.legL.rotation.x = 0.0
	v.legR.rotation.x = 0.0
	v.chute.visible = e.air == 3
	var aim := game.cam_pitch - .3 if e == game.player else 0.0
	if gun:
		v.hold.visible = true
		if v.cur_w != e.cur:
			Models.set_char_gun(v, e.cur)
			v.cur_w = e.cur
		v.armR.rotation.z = 1.2 - aim * .6 + (-.1 if e.ads else 0.0)
		v.armL.rotation.z = 1.35 - aim * .6
		v.hold.rotation.z = -aim * .5
	else:
		v.hold.visible = false
		v.armR.rotation.z = -sw * .9
		v.armL.rotation.z = sw * .9
		v.hold.rotation.z = 0.0
	if e.using > 0.0:
		var k := sin(t * 12.0) * .08
		v.armR.rotation.z = 2.2 + k
		v.armL.rotation.z = 2.0 - k
	if e.air == 2:
		var d := clampf(e.dive, 0.0, 1.0)
		body.rotation.z = -(.5 + d * .9)
		body.position.y = 18.0 * (.5 + d)
		v.armR.rotation.z = -2.3
		v.armL.rotation.z = -2.3
		v.legL.rotation.z = .4 + sin(t * 18.0) * .08
		v.legR.rotation.z = .4 - sin(t * 18.0) * .08
	elif e.air == 3:
		v.armR.rotation.z = -2.9
		v.armL.rotation.z = -2.9
		v.legL.rotation.z = .15 + sin(t * 2.0) * .08
		v.legR.rotation.z = -.1 - sin(t * 2.0) * .08
		body.rotation.z = -.12
	elif e.em > 0:
		var et := e.em_t
		match e.em:
			1:
				body.position.y = absf(sin(et * 8.0)) * 3.0
				body.rotation.y = -e.ang + sin(et * 4.0) * .6
				v.armR.rotation.z = 2.6 + sin(et * 8.0) * .5
				v.armL.rotation.z = 2.6 - sin(et * 8.0) * .5
				v.legL.rotation.z = sin(et * 8.0) * .6
				v.legR.rotation.z = -sin(et * 8.0) * .6
			2:
				v.armR.rotation.z = 3.0
				v.armR.rotation.x = sin(et * 12.0) * .7
				v.armL.rotation.z = .1
			3:
				body.position.y = absf(sin(et * 6.0)) * 4.0
				v.armR.rotation.z = 2.9
				v.armL.rotation.z = 2.9
				v.legL.rotation.z = .3
				v.legR.rotation.z = -.3
			_:
				body.rotation.y = -e.ang + et * 9.0
				v.armR.rotation.z = 1.6
				v.armL.rotation.z = 1.6
	if e.em == 0 or e.em == 3 or e.em == 2:
		pass
	if e.em != 1:
		v.armR.rotation.x = 0.0
	# вспышки и урон
	v.flash.visible = e.flash > 0.0 and gun
	if e.flash > 0.0 and gun:
		v.flash.rotation.z = randf() * TAU
		if e == game.player or Vector2(e.x - game.player.x, e.y - game.player.y).length() < 500.0:
			muzzle.global_position = v.hold.global_position + Vector3(0, 6, 0)
			muzzle.light_energy = 3.0
	var hf := clampf(e.hit_flash * 5.0, 0.0, 1.0)
	if hf > 0.0 or v.hf:
		for m: StandardMaterial3D in v.mats:
			if hf > 0.0:
				m.emission_enabled = true
				var base: Color = m.get_meta("em", Color.BLACK)
				m.emission = base.lerp(Color(1.0, .15, .1), hf)
			else:
				var base2: Color = m.get_meta("em", Color.BLACK)
				m.emission_enabled = m.has_meta("em")
				m.emission = base2
		v.hf = hf > 0.0
	v.aura.visible = e.using > 0.0
	if e.using > 0.0:
		var ac := Color("#5fd97a") if e.use_kind == "med" else Color("#4fb3ff")
		(v.aura.material_override as StandardMaterial3D).albedo_color = Color(ac.r, ac.g, ac.b, .28)
		v.aura.scale = Vector3.ONE * (1.0 + sin(t * 8.0) * .06)
	if v.fx_spin:
		v.fx_spin.rotation.y += dt * 1.8
	# метки
	if v.name_l:
		var dist := Vector2(e.x - game.cam_pos.x, e.y - game.cam_pos.z).length()
		var show := dist < 650.0 and e.air != 2
		v.name_l.visible = show
		v.bg.visible = show
		v.fg.visible = show
		v.shd.visible = show and e.sh > 0.0
		if show:
			(v.fg.material_override as ShaderMaterial).set_shader_parameter("frac", clampf(e.hp / 100.0, 0.0, 1.0))
			(v.shd.material_override as ShaderMaterial).set_shader_parameter("frac", clampf(e.sh / 100.0, 0.0, 1.0))
			v.bg.material_override.set_shader_parameter("frac", 1.0)
	# дальний LOD: скрыть мелкие детали
	var far := Vector2(e.x - game.cam_pos.x, e.y - game.cam_pos.z).length() > 340.0
	if far != (not v.det):
		v.det = not far

# ---------- лут и сундуки ----------
func _sync_items(dt: float) -> void:
	var pp := Vector2(game.player.x, game.player.y)
	if game.cam_pos != Vector3.ZERO:
		pp = Vector2(game.cam_pos.x, game.cam_pos.z)
	var rng_in := 950.0 if quality == "high" else 650.0
	for it: Types.Item in game.world.loot:
		var vw = loot_views.get(it)
		if it.gone:
			if vw:
				vw.queue_free()
				loot_views.erase(it)
			continue
		var dx := it.x - pp.x
		var dy := it.y - pp.y
		var d2 := dx * dx + dy * dy
		if vw == null:
			if d2 < rng_in * rng_in:
				vw = Models.make_loot(it)
				add_child(vw)
				loot_views[it] = vw
		elif d2 > (rng_in + 150.0) * (rng_in + 150.0):
			vw.queue_free()
			loot_views.erase(it)
			continue
		if vw:
			var sp: Node3D = vw.get_meta("spin")
			sp.rotation.y += dt * 1.6
			sp.position.y = 9.0 + sin(tm * 2.2 + it.x * .1) * 1.8
			vw.position = Vector3(it.x, game.world.th(it.x, it.y), it.y)
	for c: Types.Chest in game.world.chests:
		var cv = chest_views.get(c)
		var dx2 := c.x - pp.x
		var dy2 := c.y - pp.y
		var dd := dx2 * dx2 + dy2 * dy2
		if cv == null:
			if dd < 1400.0 * 1400.0 or c.drop:
				cv = Models.make_chest()
				add_child(cv)
				cv.position = Vector3(c.x, game.world.th(c.x, c.y), c.y)
				chest_views[c] = cv
		elif dd > 1600.0 * 1600.0 and not c.drop:
			cv.queue_free()
			chest_views.erase(c)
			continue
		if cv:
			var lid: Node3D = cv.get_meta("lid")
			var cur: float = open_t.get(c, 0.0)
			cur = move_toward(cur, 1.0 if c.open else 0.0, dt * 3.0)
			open_t[c] = cur
			lid.rotation.x = -1.9 * (1.0 - pow(1.0 - cur, 3.0))
			cv.get_meta("glow").visible = not c.open
			var bm: MeshInstance3D = cv.get_meta("beam")
			bm.visible = not c.open
			if c.drop:
				bm.scale = Vector3(2.4, 6.0, 2.4)
				bm.position.y = 220.0
			if not c.open:
				var g: MeshInstance3D = cv.get_meta("glow")
				g.scale = Vector3.ONE * (1.0 + sin(tm * 3.0) * .08)

# ---------- построенные стены ----------
func _sync_walls(dt: float) -> void:
	scan_t -= dt
	if scan_t <= 0.0:
		scan_t = .12
		for r: Types.Rc in game.world.rects:
			if r.type == "built" and r.view == null:
				var n := Node3D.new()
				var m := Mat.tri_mat("wood", .03, .85, Color("#d8a463"), false).duplicate() as StandardMaterial3D
				var gy := game.world.th(r.x + r.w * .5, r.y + r.h * .5)
				var body := Mat.mi(Mat.box(), m, Vector3(r.w, 52, r.h), Vector3(0, 26, 0), true)
				n.add_child(body)
				var cap := Mat.mi(Mat.box(), Mat.std(Color("#a9763a"), .7), Vector3(r.w + 3, 4, r.h + 3), Vector3(0, 53, 0), true)
				n.add_child(cap)
				var base := Mat.mi(Mat.box(), Mat.std(Color("#7d5527"), .8), Vector3(r.w + 3, 5, r.h + 3), Vector3(0, 2, 0), true)
				n.add_child(base)
				n.position = Vector3(r.x + r.w * .5, gy - 6.0, r.y + r.h * .5)
				add_child(n)
				r.view = n
				wall_views.append({"r": r, "n": n, "m": m, "gy": gy})
	var i := wall_views.size() - 1
	while i >= 0:
		var w: Dictionary = wall_views[i]
		var r2: Types.Rc = w["r"]
		var n2: Node3D = w["n"]
		if r2.gone:
			n2.queue_free()
			wall_views.remove_at(i)
		else:
			var k := clampf((game.clock - r2.t0) / .22, 0.0, 1.0)
			n2.scale.y = maxf(.04, 1.0 - pow(1.0 - k, 3.0))
			var hp := clampf(r2.hp / r2.mx, 0.0, 1.0)
			var m2: StandardMaterial3D = w["m"]
			m2.albedo_color = Color("#d8a463").lerp(Color("#6d5038"), 1.0 - hp)
			m2.emission_enabled = r2.fl > 0.0
			m2.emission = Color(1, .7, .3) * (r2.fl * 6.0)
		i -= 1

# ---------- пули, частицы, цифры ----------
func _sync_fx(_dt: float) -> void:
	var mm := bullet_mm.multimesh
	var n := mini(game.bullets.size(), mm.instance_count)
	mm.visible_instance_count = n
	for i in n:
		var b: Types.Bullet = game.bullets[i]
		var dir := Vector3(b.vx, b.vz, b.vy).normalized()
		var up := Vector3.UP if absf(dir.y) < .95 else Vector3.RIGHT
		var bs := Basis.looking_at(dir, up)
		mm.set_instance_transform(i, Transform3D(bs, Vector3(b.x, b.z, b.y) - dir * 6.0))
		mm.set_instance_color(i, b.col.lerp(Color.WHITE, .5))
	var pm := part_mm.multimesh
	var np := mini(game.parts.size(), pm.instance_count)
	pm.visible_instance_count = np
	for i in np:
		var p: Types.Part = game.parts[i]
		var s := clampf(p.l * 9.0, .3, 1.6)
		pm.set_instance_transform(i, Transform3D(Basis.IDENTITY.scaled(Vector3(s, s, s)), Vector3(p.x, p.z + game.world.th(p.x, p.y), p.y)))
		pm.set_instance_color(i, p.col)
	var k := 0
	for dn: Types.DmgNum in game.dmg_nums:
		if k >= dnum_pool.size():
			break
		var l: Label3D = dnum_pool[k]
		k += 1
		l.visible = true
		l.text = str(dn.v)
		l.position = Vector3(dn.x, game.world.th(dn.x, dn.y) + 55.0 + dn.t * 40.0, dn.y)
		l.modulate = Color("#ffd23c") if dn.big else Color.WHITE
		l.modulate.a = clampf(2.0 - dn.t * 2.0, 0.0, 1.0)
		l.font_size = 78 if dn.big else 56
	while k < dnum_pool.size():
		dnum_pool[k].visible = false
		k += 1
	muzzle.light_energy = maxf(0.0, muzzle.light_energy - _dt * 40.0)

# ---------- буря ----------
func _sync_storm() -> void:
	var s := game.storm
	if s.is_empty():
		return
	storm_wall.position = Vector3(s["cx"], 0, s["cy"])
	storm_wall.scale = Vector3(s["r"], 3000.0, s["r"])
	storm_wall.position.y = 1400.0
	storm_mat.set_shader_parameter("t", tm)
	var show_ring: bool = s["mode"] != "done" and s["phase"] >= 0
	next_ring.visible = show_ring
	if show_ring:
		next_ring.position = Vector3(s["tcx"], 500.0, s["tcy"])
		next_ring.scale = Vector3(s["tr"], 1000.0, s["tr"])
		ring_mat.set_shader_parameter("t", tm)

# ---------- главный синк ----------
func sync(dt: float) -> void:
	tm += dt
	if game == null or game.player == null:
		return
	for e in game.players:
		_sync_char(e, dt)
	_sync_items(dt)
	_sync_walls(dt)
	_sync_fx(dt)
	_sync_storm()
	var b := game.bus
	bus_node.visible = b["on"]
	if b["on"]:
		bus_node.position = Vector3(b["x"], Game.BUS_ALT, b["y"])
		bus_node.rotation.y = -b["ang"]
	cam.global_position = game.cam_pos
	if game.cam_pos.distance_to(game.cam_target) > .01:
		cam.look_at(game.cam_target, Vector3.UP)
	cam.fov = game.cam_fov
	if wm:
		if wm.sea_mat:
			wm.sea_mat.set_shader_parameter("t", tm)
		for c in wm.clouds:
			c.position.x += dt * 6.0
			if c.position.x > World.W + 1800.0:
				c.position.x = -1800.0
		wm.update_roofs(game.player.x, game.player.y, game.cam_pos)
	sun.global_position = game.cam_pos
