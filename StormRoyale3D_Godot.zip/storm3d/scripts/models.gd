class_name Models
extends RefCounted
## Высокополигональные процедурные модели: персонажи, оружие, лут, сундуки, автобус.

const GUNLEN := {"pistol": 11.5, "smg": 19.5, "rifle": 31.0, "shotgun": 26.0, "sniper": 36.0}
const PANTS := ["#2c3140", "#3b4a63", "#4b3b2a", "#274a3d"]
const HAIRC := ["#f4d35e", "#2b2b33", "#e63946", "#8a5a3a", "#cfd4dc"]

class CharView:
	extends RefCounted
	var root: Node3D
	var body: Node3D
	var legL: Node3D
	var legR: Node3D
	var armR: Node3D
	var armL: Node3D
	var hold: Node3D
	var flash: MeshInstance3D
	var aura: MeshInstance3D
	var chute: Node3D
	var sh: MeshInstance3D
	var guns := {}
	var cur_w := ""
	var mats: Array = []
	var detail: Array = []
	var fx_spin: Node3D = null
	var hf := false
	var name_l: Label3D = null
	var bg: MeshInstance3D = null
	var fg: MeshInstance3D = null
	var shd: MeshInstance3D = null
	var det := true

static func _pv(x: float, y: float, z: float) -> Vector3:
	return Vector3(x, y, z)

# ---------- оружие (вперёд +X) ----------
static func gun_model(key: String) -> Node3D:
	var g := Node3D.new()
	var w: Data.WDef = Data.WPN[key]
	var mt := Mat.std(Color("#2b2f3a"), .35, .75)
	var m2 := Mat.std(Color("#505867"), .4, .7)
	var ac := Mat.std(w.c, .4, .35)
	var wd := Mat.std(Color("#7a4a26"), .7, 0.0)
	var box := Mat.box()
	var add := func(mesh: Mesh, mat: Material, sx: float, sy: float, sz: float, x: float, y: float, z: float, rz: float = 0.0) -> MeshInstance3D:
		var m := Mat.mi(mesh, mat, Vector3(sx, sy, sz), Vector3(x, y, z), false)
		m.rotation.z = rz
		g.add_child(m)
		return m
	var barrel := func(ln: float, r: float, x: float, y: float, mat: Material = null) -> void:
		var m: MeshInstance3D = add.call(Mat.cyl(20), mat if mat else m2, r, ln, r, x, y, 0.0)
		m.rotation.z = PI / 2
	if key == "pistol":
		add.call(box, mt, 10, 3.2, 2.6, 5, .6, 0)
		add.call(box, ac, 9.6, .9, 2.7, 5, -1.1, 0)
		add.call(box, mt, 3, 6.5, 2.4, 1.6, -4, 0, .18)
		add.call(box, mt, 3, .6, 2, 4.2, -2.2, 0)
		add.call(box, m2, .8, .8, 1, 9.5, 2.4, 0)
		barrel.call(2.4, .8, 10.4, .8)
	elif key == "smg":
		add.call(box, mt, 13, 4.4, 3, 6, 0, 0)
		add.call(box, ac, 9, .8, 3.1, 7, 2.4, 0)
		add.call(box, m2, 2.6, 8.5, 2.4, 6, -6, 0)
		add.call(box, mt, 2, 4.5, 2.2, 11, -4, 0)
		add.call(box, mt, 6.5, 2.4, 2.6, -3.5, .4, 0)
		add.call(box, ac, 1.2, 4, 2.8, -7, .4, 0)
		barrel.call(9, 1.4, 16.5, .6, mt)
		add.call(box, wd, 2.4, 5, 2.2, 1.5, -3.8, 0, .2)
	elif key == "rifle":
		add.call(box, mt, 18, 4.4, 3.2, 8, 0, 0)
		add.call(box, m2, 11, 3.8, 3.6, 17.5, 0, 0)
		barrel.call(8, .85, 26, .6)
		add.call(box, m2, 2, 2, 2.4, 30.4, .6, 0)
		add.call(box, wd, 10, 5, 2.8, -4, -.6, 0)
		add.call(box, ac, 1.4, 6, 3, -9.4, -.6, 0)
		add.call(box, m2, 3, 9, 2.6, 9, -6.6, 0, .22)
		add.call(box, mt, 12, .9, 2, 9, 2.8, 0)
		add.call(box, ac, 3.4, 2.2, 2.6, 8, 4.2, 0)
		add.call(box, mt, 2.4, 5, 2.2, 2.5, -4.2, 0, .2)
	elif key == "shotgun":
		barrel.call(22, 1.25, 14, .8)
		barrel.call(18, 1.0, 12, -1.4, mt)
		add.call(box, wd, 8, 3.4, 3.6, 11, -1.2, 0)
		add.call(box, mt, 10, 4, 3.2, 3, 0, 0)
		add.call(box, wd, 11, 4.8, 2.8, -6, -1, 0)
		add.call(box, ac, 1.5, 3.2, 3.4, 24, .4, 0)
		add.call(box, m2, .8, 1, .8, 25.5, 2.2, 0)
		add.call(box, mt, 2.4, 5, 2.2, 1.5, -4, 0, .2)
	else:
		var lens := Mat.emissive(Color("#9fe0ff"), .9)
		barrel.call(30, 1.0, 21, .9)
		add.call(box, mt, 17, 4.2, 3, 6, 0, 0)
		add.call(box, wd, 12, 5.4, 2.8, -6.5, -.8, 0)
		add.call(box, ac, 5, 1.2, 3, -4, 3, 0)
		var sc: MeshInstance3D = add.call(Mat.cyl(20), mt, 1.7, 11, 1.7, 8, 5.2, 0)
		sc.rotation.z = PI / 2
		var l1: MeshInstance3D = add.call(Mat.cyl(20), lens, 2.05, .6, 2.05, 13.9, 5.2, 0)
		l1.rotation.z = PI / 2
		var l2: MeshInstance3D = add.call(Mat.cyl(20), lens, 2.05, .6, 2.05, 2.3, 5.2, 0)
		l2.rotation.z = PI / 2
		add.call(box, m2, 1.2, 2, 1.4, 5, 3.2, 0)
		add.call(box, m2, 1.2, 2, 1.4, 11, 3.2, 0)
		add.call(box, m2, 2.6, 5, 2.6, 7, -4.4, 0)
		add.call(box, m2, .7, 5, .7, 24, -2.2, 1.7)
		add.call(box, m2, .7, 5, .7, 24, -2.2, -1.7)
		add.call(box, mt, 2.4, 5, 2.2, 1.5, -4, 0, .2)
	return g

# ---------- персонаж ----------
static func bot_look(e: Ent) -> Dictionary:
	var top := e.color
	return {"top": top, "acc": top.lerp(Color.WHITE, .55), "pants": Color(PANTS[e.id % 4]), "hat": e.id % 4, "hair": Color(HAIRC[e.id % 5]), "hatc": e.color, "glide": e.color, "r": "common", "tone": e.skin}

static func make_char(e: Ent, look: Dictionary, with_tag: bool) -> CharView:
	var st: Dictionary = look if not look.is_empty() else bot_look(e)
	var tone: Color = e.skin
	var mTop := Mat.uniq(st["top"], .75)
	var mAcc := Mat.uniq(st["acc"], .6)
	var mPants := Mat.uniq(st["pants"], .8)
	var mSkin := Mat.uniq(tone, .65)
	var mBoot := Mat.uniq(Color("#2a1c14"), .8)
	var mHat := Mat.uniq(st["hatc"], .55)
	var mHair := Mat.uniq(st["hair"], .85)
	var v := CharView.new()
	v.root = Node3D.new()
	v.body = Node3D.new()
	v.root.add_child(v.body)
	var body := v.body
	var cyl := Mat.cyl(28)
	var sph := Mat.sph(40)
	var sphlo := Mat.sph(18)
	var box := Mat.box()
	var add := func(m: MeshInstance3D, parent: Node3D = null, det: bool = false) -> MeshInstance3D:
		(parent if parent else body).add_child(m)
		if det:
			m.visibility_range_end = 340.0
			v.detail.append(m)
		return m
	var mk_leg := func(z: float) -> Node3D:
		var p := Node3D.new()
		p.position = Vector3(0, 14.5, z)
		p.add_child(Mat.mi(Mat.caps(2.9, 8.6, 20), mPants, Vector3.ONE, Vector3(0, -7.2, 0), true))
		p.add_child(Mat.mi(cyl, mBoot, Vector3(3.3, 3.6, 3.3), Vector3(0, -12.8, 0), true))
		var toe := Mat.mi(sph, mBoot, Vector3(2.1, 1.6, 2.6), Vector3(2.1, -13.4, 0))
		toe.visibility_range_end = 340.0
		v.detail.append(toe)
		p.add_child(toe)
		body.add_child(p)
		return p
	v.legL = mk_leg.call(-3.7)
	v.legR = mk_leg.call(3.7)
	# торс
	body.add_child(Mat.mi(Mat.caps(5.5, 7.5, 32), mTop, Vector3(.88, 1, 1.12), Vector3(0, 23.4, 0), true))
	add.call(Mat.mi(cyl, mPants, Vector3(5.2, 1.9, 6.4), Vector3(0, 15.4, 0)), null, true)
	var logo: MeshInstance3D = add.call(Mat.mi(cyl, mAcc, Vector3(1.7, .5, 1.7), Vector3(5.2, 24.6, 0)), null, true)
	logo.rotation.z = PI / 2
	# рюкзак
	add.call(Mat.mi(Mat.caps(2.8, 7, 20), mAcc, Vector3(.9, 1, 1.7), Vector3(-6.4, 24, 0), true))
	add.call(Mat.mi(box, mTop, Vector3(1.2, 12, 1.2), Vector3(-4.8, 26, 4.6)), null, true)
	add.call(Mat.mi(box, mTop, Vector3(1.2, 12, 1.2), Vector3(-4.8, 26, -4.6)), null, true)
	# голова
	add.call(Mat.mi(cyl, mSkin, Vector3(1.9, 2.8, 1.9), Vector3(0, 32.8, 0)))
	add.call(Mat.mi(Mat.sph(48), mSkin, Vector3(5.6, 5.9, 5.6), Vector3(.5, 37.6, 0), true))
	var eyeW := Mat.std(Color.WHITE, .3)
	for s in [-1.0, 1.0]:
		add.call(Mat.mi(sphlo, eyeW, Vector3(.6, 1.3, 1.25), Vector3(5.3, 38.2, 2.2 * s)), null, true)
		add.call(Mat.mi(sphlo, Mat.std(Color("#15151f"), .5), Vector3(.35, .7, .7), Vector3(5.75, 38.2, 2.2 * s)), null, true)
		add.call(Mat.mi(box, mHair, Vector3(.6, .5, 2.2), Vector3(5.2, 40.2, 2.3 * s)), null, true)
	add.call(Mat.mi(sphlo, mSkin, Vector3(.9, .9, .9), Vector3(6.1, 36.9, 0)), null, true)
	add.call(Mat.mi(box, Mat.std(Color("#15151f"), .6), Vector3(.3, .45, 2.8), Vector3(5.9, 35.2, 0)), null, true)
	# головной убор
	var hs: int = st["hat"]
	var hemi := Mat.hemi(32)
	if hs == 0:
		add.call(Mat.mi(hemi, mHat, Vector3(6.3, 5.6, 6.3), Vector3(.4, 38.6, 0), true))
		add.call(Mat.mi(box, mHat, Vector3(3.6, .8, 8.6), Vector3(5.4, 39.4, 0)), null, true)
	elif hs == 1:
		add.call(Mat.mi(hemi, mHat, Vector3(6.2, 6.6, 6.2), Vector3(.4, 38.8, 0), true))
		add.call(Mat.mi(cyl, mAcc, Vector3(6.3, 1.6, 6.3), Vector3(.4, 38.9, 0)), null, true)
		add.call(Mat.mi(sphlo, mAcc, Vector3(1.9, 1.9, 1.9), Vector3(.4, 45.6, 0)), null, true)
	elif hs == 2:
		for k in 7:
			var a := k / 7.0 * TAU
			var c := Mat.mi(Mat.cone(12), mHair, Vector3(1.9, 6.5, 1.9), Vector3(.4 + cos(a) * 3.4, 43.1, sin(a) * 3.4))
			c.rotation = Vector3(sin(a) * .5, 0, -cos(a) * .5)
			add.call(c, null, true)
		add.call(Mat.mi(hemi, mHair, Vector3(5.8, 3.6, 5.8), Vector3(.4, 39.8, 0)))
	else:
		add.call(Mat.mi(hemi, mHat, Vector3(6.1, 4.4, 6.1), Vector3(.4, 39.2, 0), true))
		add.call(Mat.mi(box, mHat, Vector3(6.2, .7, 8.2), Vector3(6.4, 39.6, 0)), null, true)
	# руки
	var mk_arm := func(z: float, yaw: float, sw: float) -> Node3D:
		var piv := Node3D.new()
		piv.position = Vector3(0, 29.2, z)
		piv.rotation.y = yaw
		var swing := Node3D.new()
		swing.rotation.z = sw
		piv.add_child(swing)
		swing.add_child(Mat.mi(Mat.caps(2.3, 6.5, 20), mTop, Vector3.ONE, Vector3(0, -5.6, 0), true))
		swing.add_child(Mat.mi(Mat.sph(24), mSkin, Vector3(2.4, 2.4, 2.4), Vector3(0, -11.2, 0)))
		body.add_child(piv)
		return swing
	v.armR = mk_arm.call(6.6, .49, 1.2)
	v.armL = mk_arm.call(-6.6, -.5, 1.35)
	for s in [-1.0, 1.0]:
		add.call(Mat.mi(sph, mAcc, Vector3(3.4, 2.3, 3.6), Vector3(0, 30.4, 6.9 * s), true), null, true)
		add.call(Mat.mi(sphlo, mSkin, Vector3(.9, 1.5, .8), Vector3(.2, 37.2, 5.7 * s)), null, true)
		add.call(Mat.mi(sph, mAcc, Vector3(2.5, 2.1, 2.7), Vector3(1.5, 8.6, 3.7 * s)), null, true)
	add.call(Mat.mi(sph, mHair, Vector3(4.6, 3.8, 5.2), Vector3(-3.2, 37.2, 0)), null, true)
	add.call(Mat.mi(box, mAcc, Vector3(1.4, 1.8, 3.2), Vector3(5.6, 15.6, 0)), null, true)
	v.hold = Node3D.new()
	v.hold.position = Vector3(8.4, 25.4, 1.4)
	body.add_child(v.hold)
	v.flash = MeshInstance3D.new()
	v.flash.mesh = Mat.quad(15, 15)
	v.flash.material_override = Mat.billboard(Mat.flash_tex(), true)
	v.flash.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	v.flash.visible = false
	v.hold.add_child(v.flash)
	v.aura = Mat.mi(sph, Mat.glow(Color("#5fd97a"), .28), Vector3(22, 26, 22), Vector3(0, 21, 0))
	v.aura.visible = false
	body.add_child(v.aura)
	# редкость скина: эффекты
	var tier: int = Data.RAR_TIER.get(st.get("r", "common"), 0)
	var acc: Color = st["acc"]
	if tier > 0:
		var glow_m := func(m: StandardMaterial3D, k: float) -> void:
			m.emission_enabled = true
			m.emission = Color(acc.r * k, acc.g * k, acc.b * k)
			m.set_meta("em", m.emission)
		if tier >= 1:
			mAcc.metallic = .55; mAcc.roughness = .35; mHat.metallic = .3; mHat.roughness = .4; mTop.roughness = .55
		if tier >= 2:
			glow_m.call(mAcc, .45)
			glow_m.call(mHat, .2)
			var vis := Mat.unlit(acc)
			add.call(Mat.mi(box, vis, Vector3(.5, .9, 4.6), Vector3(5.9, 38, 0)), null, true)
		if tier >= 3:
			glow_m.call(mAcc, .8)
			mTop.metallic = .25; mTop.roughness = .4
			var capeM := Mat.uniq(st["top"], .6)
			capeM.cull_mode = BaseMaterial3D.CULL_DISABLED
			capeM.emission_enabled = true
			capeM.emission = Color(acc.r * .18, acc.g * .18, acc.b * .18)
			var cape := Mat.mi(box, capeM, Vector3(.7, 20, 13), Vector3(-7.4, 21, 0), true)
			cape.rotation.z = .1
			add.call(cape)
			for s in [-1.0, 1.0]:
				var sp := Mat.mi(Mat.cone(14), mAcc, Vector3(1.7, 5.5, 1.7), Vector3(0, 33.5, 7.4 * s), true)
				sp.rotation.x = .6 * s
				add.call(sp, null, true)
			var bootG := Mat.unlit(acc, .85)
			for s in [-1.0, 1.0]:
				add.call(Mat.mi(cyl, bootG, Vector3(3.5, .5, 3.5), Vector3(0, 3.2, 3.7 * s)), null, true)
		if tier >= 4:
			glow_m.call(mAcc, 1.1)
			glow_m.call(mHat, .5)
			glow_m.call(mTop, .25)
			var gm := Mat.unlit(acc, .9)
			var halo := Mat.mi(_torus(), gm, Vector3(5.6, 5.6, 5.6), Vector3(0, 50, 0))
			add.call(halo)
			var wm := Mat.unlit(acc, .55)
			wm = wm.duplicate()
			wm.cull_mode = BaseMaterial3D.CULL_DISABLED
			for s in [-1.0, 1.0]:
				for k in 3:
					var wg := Mat.mi(Mat.cone(10), wm, Vector3(2.2, 15 - k * 3, .5), Vector3(-6.8, 28 + k * 2.6, 3 * s + 7 * s * (k + 1) * .5))
					wg.rotation = Vector3((1.1 + k * .2) * s, 0, .5)
					add.call(wg, null, true)
			var orbs := Node3D.new()
			orbs.position = Vector3(0, 24, 0)
			body.add_child(orbs)
			var om := Mat.unlit(st["hatc"])
			for k in 5:
				var a := k / 5.0 * TAU
				orbs.add_child(Mat.mi(sphlo, om, Vector3(1.1, 1.1, 1.1), Vector3(cos(a) * 11, sin(k * 2.0) * 6, sin(a) * 11)))
			v.fx_spin = orbs
	# парашют
	var chute := Node3D.new()
	var gcol: Color = st["glide"]
	var dm := Mat.uniq(gcol, .6)
	dm.cull_mode = BaseMaterial3D.CULL_DISABLED
	var dome := Mat.mi(Mat.hemi(40), dm, Vector3(30, 30, 30), Vector3(0, 84, 0))
	chute.add_child(dome)
	var sm := Mat.uniq(Color.WHITE, .6)
	sm.cull_mode = BaseMaterial3D.CULL_DISABLED
	chute.add_child(Mat.mi(Mat.hemi(40), sm, Vector3(29.5, 30.3, 10.5), Vector3(0, 84.4, 0)))
	var lm := ArrayMesh.new()
	var lv := PackedVector3Array()
	for k in 8:
		var a := k / 8.0 * TAU
		lv.append(Vector3(cos(a) * 30, 84, sin(a) * 30))
		lv.append(Vector3(0, 38, 0))
	var la := []
	la.resize(Mesh.ARRAY_MAX)
	la[Mesh.ARRAY_VERTEX] = lv
	lm.add_surface_from_arrays(Mesh.PRIMITIVE_LINES, la)
	var lmi := MeshInstance3D.new()
	lmi.mesh = lm
	lmi.material_override = Mat.unlit(Color("#eeeeee"))
	chute.add_child(lmi)
	chute.visible = false
	body.add_child(chute)
	v.chute = chute
	# тень-пятно
	v.sh = MeshInstance3D.new()
	var shm := QuadMesh.new()
	shm.size = Vector2(26, 26)
	shm.orientation = PlaneMesh.FACE_Y
	v.sh.mesh = shm
	var sm2 := StandardMaterial3D.new()
	sm2.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm2.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm2.albedo_texture = Mat.radial_tex(Color(0, 0, 0, .45), Color(0, 0, 0, 0))
	sm2.disable_receive_shadows = true
	v.sh.material_override = sm2
	v.sh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	v.sh.position.y = .5
	v.root.add_child(v.sh)
	v.mats = [mTop, mAcc, mPants, mSkin, mHat, mHair]
	if with_tag:
		v.name_l = Label3D.new()
		v.name_l.text = e.name
		v.name_l.font_size = 40
		v.name_l.pixel_size = .22
		v.name_l.outline_size = 12
		v.name_l.outline_modulate = Color(.04, .04, .12, .9)
		v.name_l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		v.name_l.no_depth_test = true
		v.name_l.render_priority = 8
		v.name_l.position = Vector3(0, 55, 0)
		v.root.add_child(v.name_l)
		v.bg = _bar(Color(0, 0, 0, .6), 6)
		v.fg = _bar(Color("#5fd97a"), 7)
		v.shd = _bar(Color("#4fb3ff"), 7)
		v.root.add_child(v.bg)
		v.root.add_child(v.fg)
		v.root.add_child(v.shd)
	return v

static var _tor: TorusMesh = null
static func _torus() -> TorusMesh:
	if _tor == null:
		_tor = TorusMesh.new()
		_tor.inner_radius = .92
		_tor.outer_radius = 1.0
		_tor.rings = 32
		_tor.ring_segments = 8
	return _tor

static func _bar(c: Color, prio: int) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(1, 1)
	q.center_offset = Vector3(.5, 0, 0)
	m.mesh = q
	var mt := StandardMaterial3D.new()
	mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mt.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	mt.billboard_keep_scale = true
	mt.no_depth_test = true
	mt.render_priority = prio
	mt.albedo_color = c
	if c.a < 1.0:
		mt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.material_override = mt
	m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return m

static func set_char_gun(v: CharView, key: String) -> void:
	if not v.guns.has(key):
		var gm := gun_model(key)
		v.hold.add_child(gm)
		v.guns[key] = gm
	for k in v.guns:
		v.guns[k].visible = k == key
	v.flash.position = Vector3(GUNLEN[key] + 1.5, .8, 0)

# ---------- лут ----------
static func make_loot(it: Types.Item) -> Node3D:
	var root := Node3D.new()
	var spin := Node3D.new()
	root.add_child(spin)
	var beam_c := Color.WHITE
	var has_beam := false
	var ring_c := Color.WHITE
	var has_ring := true
	var box := Mat.box()
	var cyl := Mat.cyl(18)
	var sph := Mat.sph(24)
	if it.k == "w":
		var gm := gun_model(it.w)
		gm.scale = Vector3(1.35, 1.35, 1.35)
		gm.position = Vector3(-GUNLEN[it.w] * .6, 0, 0)
		gm.rotation.z = .35
		spin.add_child(gm)
		beam_c = Data.rar_col(it.rar) if it.rar > 0 else Data.WPN[it.w].c
		ring_c = beam_c
		has_beam = true
	elif it.k == "med":
		spin.add_child(Mat.mi(box, Mat.std(Color.WHITE, .5), Vector3(12, 9, 12), Vector3.ZERO))
		spin.add_child(Mat.mi(box, Mat.std(Color("#e0364a"), .5), Vector3(8, 1.2, 2.4), Vector3(0, 4.8, 0)))
		spin.add_child(Mat.mi(box, Mat.std(Color("#e0364a"), .5), Vector3(2.4, 1.2, 8), Vector3(0, 4.8, 0)))
		spin.add_child(Mat.mi(box, Mat.std(Color("#9aa3ad"), .4, .6), Vector3(5, 1.6, 1.6), Vector3(0, 6.2, 5.8)))
		beam_c = Color("#5fd97a")
		ring_c = beam_c
		has_beam = true
	elif it.k == "pot":
		var gl := Mat.emissive(Color("#4fb3ff"), .8)
		spin.add_child(Mat.mi(sph, gl, Vector3(6.4, 6.8, 6.4), Vector3.ZERO))
		spin.add_child(Mat.mi(cyl, gl, Vector3(2, 5, 2), Vector3(0, 6.4, 0)))
		spin.add_child(Mat.mi(cyl, Mat.std(Color("#a07a4a"), .8), Vector3(2.4, 2, 2.4), Vector3(0, 9.4, 0)))
		beam_c = Color("#4fb3ff")
		ring_c = beam_c
		has_beam = true
	elif it.k == "mats":
		var wd := Mat.std(Color("#a8742e"), .9)
		var ed := Mat.std(Color("#d9ad74"), .9)
		for p in [[-3.2, -3.6], [-3.2, 3.6], [2.2, 0.0]]:
			var l := Mat.mi(cyl, wd, Vector3(3.4, 17, 3.4), Vector3(0, p[0], p[1]))
			l.rotation.z = PI / 2
			spin.add_child(l)
			var e2 := Mat.mi(cyl, ed, Vector3(3.0, .5, 3.0), Vector3(8.6, p[0], p[1]))
			e2.rotation.z = PI / 2
			spin.add_child(e2)
		ring_c = Color("#d9ad74")
	else:
		spin.add_child(Mat.mi(box, Mat.std(Color("#5c6b3a"), .7), Vector3(14, 8, 10), Vector3.ZERO))
		spin.add_child(Mat.mi(box, Mat.std(Color("#d6b24a"), .4, .6), Vector3(14.4, 1.4, 10.4), Vector3(0, 3.2, 0)))
		for k in [-1, 0, 1]:
			spin.add_child(Mat.mi(cyl, Mat.std(Color("#e0b24a"), .3, .8), Vector3(1.1, 5, 1.1), Vector3(k * 3.4, 6.4, 0)))
		beam_c = Color("#ffd23c")
		ring_c = beam_c
		has_beam = true
	if has_ring:
		var r := Mat.mi(_ring_mesh(), Mat.glow(ring_c, .3), Vector3(12, 1, 12), Vector3(0, .9, 0))
		root.add_child(r)
	if has_beam:
		root.add_child(Mat.mi(_beam_mesh(), Mat.glow(beam_c, .3), Vector3.ONE, Vector3(0, 40, 0)))
	root.set_meta("spin", spin)
	return root

static var _ringm: Mesh = null
static func _ring_mesh() -> Mesh:
	if _ringm == null:
		var t := TorusMesh.new()
		t.inner_radius = .78
		t.outer_radius = 1.0
		t.rings = 36
		t.ring_segments = 4
		_ringm = t
	return _ringm

static var _beamm: CylinderMesh = null
static func _beam_mesh() -> CylinderMesh:
	if _beamm == null:
		_beamm = CylinderMesh.new()
		_beamm.top_radius = 5.0
		_beamm.bottom_radius = 5.0
		_beamm.height = 80.0
		_beamm.radial_segments = 12
		_beamm.rings = 1
		_beamm.cap_top = false
		_beamm.cap_bottom = false
	return _beamm

# ---------- сундук ----------
static func make_chest() -> Node3D:
	var root := Node3D.new()
	var wd := Mat.tri_mat("wood", .04, .8, Color("#c58a4a"), false)
	var gold := Mat.std(Color("#f1c232"), .3, .85)
	var box := Mat.box()
	root.add_child(Mat.mi(box, wd, Vector3(24, 11, 16), Vector3(0, 5.5, 0), true))
	root.add_child(Mat.mi(box, gold, Vector3(2.2, 11.4, 16.6), Vector3(-7, 5.6, 0), true))
	root.add_child(Mat.mi(box, gold, Vector3(2.2, 11.4, 16.6), Vector3(7, 5.6, 0), true))
	root.add_child(Mat.mi(box, gold, Vector3(25, 1.6, 16.8), Vector3(0, .8, 0), true))
	var lid := Node3D.new()
	lid.position = Vector3(0, 11, -8)
	root.add_child(lid)
	var hc := CylinderMesh.new()
	hc.top_radius = 1.0
	hc.bottom_radius = 1.0
	hc.height = 24.0
	hc.radial_segments = 24
	hc.rings = 1
	var lm := Mat.mi(hc, wd, Vector3(8, 1, 8), Vector3(0, 0, 8), true)
	lm.rotation.z = PI / 2
	lid.add_child(lm)
	for x in [-7.0, 7.0]:
		var b := Mat.mi(Mat.cyl(24), gold, Vector3(8.4, 2.4, 8.4), Vector3(x, 0, 8), true)
		b.rotation.z = PI / 2
		lid.add_child(b)
	root.add_child(Mat.mi(box, gold, Vector3(3.4, 4, 1.4), Vector3(0, 9.6, 8.4), true))
	var glow := MeshInstance3D.new()
	glow.mesh = Mat.quad(46, 46)
	glow.material_override = Mat.billboard(Mat.flash_tex(), true, Color("#ffcf5a"))
	glow.position.y = 11
	glow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(glow)
	var beam := Mat.mi(_beam_mesh(), Mat.glow(Color("#ffd23c"), .3), Vector3(1.5, 1.3, 1.5), Vector3(0, 52, 0))
	root.add_child(beam)
	root.set_meta("lid", lid)
	root.set_meta("glow", glow)
	root.set_meta("beam", beam)
	return root

# ---------- автобус ----------
static func make_bus() -> Node3D:
	var g := Node3D.new()
	var body := Node3D.new()
	g.add_child(body)
	var bx := func(w: float, h: float, d: float, c: String, x: float, y: float, z: float, r: float = .55, m: float = 0.0) -> void:
		body.add_child(Mat.mi(Mat.box(), Mat.std(Color(c), r, m), Vector3(w, h, d), Vector3(x, y, z)))
	bx.call(120, 34, 50, "#2f8fe8", 0, 22, 0)
	bx.call(122, 6, 52, "#ffffff", 0, 20, 0)
	bx.call(124, 5, 54, "#1b5fae", 0, 38, 0)
	bx.call(30, 20, 46, "#2f8fe8", 52, 20, 0)
	bx.call(8, 14, 40, "#bfe8ff", 66, 26, 0, .1)
	for i in 4:
		bx.call(15, 12, 52, "#cfeeff", -42 + i * 22, 32, 0, .1)
	for x in [-36.0, 40.0]:
		for z in [-26.0, 26.0]:
			var w := Mat.mi(Mat.cyl(20), Mat.std(Color("#222a33"), .8), Vector3(9, 8, 9), Vector3(x, 8, z))
			w.rotation.x = PI / 2
			body.add_child(w)
	body.add_child(Mat.mi(Mat.sph(40), Mat.std(Color("#ff5a3d"), .5), Vector3(95, 110, 95), Vector3(0, 215, 0)))
	var top := Mat.mi(Mat.hemi(40), Mat.std(Color("#ffd23d"), .5), Vector3(48, 56, 48), Vector3(0, 255, 0))
	body.add_child(top)
	var lv := PackedVector3Array()
	for p in [[-45.0, -22.0], [45.0, -22.0], [-45.0, 22.0], [45.0, 22.0]]:
		lv.append(Vector3(p[0], 40, p[1]))
		lv.append(Vector3(p[0] * .8, 135, p[1] * .8))
	var lm := ArrayMesh.new()
	var la := []
	la.resize(Mesh.ARRAY_MAX)
	la[Mesh.ARRAY_VERTEX] = lv
	lm.add_surface_from_arrays(Mesh.PRIMITIVE_LINES, la)
	var lmi := MeshInstance3D.new()
	lmi.mesh = lm
	lmi.material_override = Mat.unlit(Color("#eeeeee"))
	body.add_child(lmi)
	body.scale = Vector3(1.5, 1.5, 1.5)
	return g
