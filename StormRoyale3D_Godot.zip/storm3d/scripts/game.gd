class_name Game
extends Node
## Игровая логика: бой, боты, буря, автобус, управление игроком.

signal banner_msg(msg: String)
signal match_over(won: bool)

const BUS_ALT := 1200.0
const BUS_SPD := 270.0
const GLIDE_AT := 300.0
const ROUTE_R := 4300.0
const PH := [
	{"w": 50.0, "s": 70.0, "r": 2450.0, "d": 1.0}, {"w": 35.0, "s": 60.0, "r": 1550.0, "d": 2.0}, {"w": 28.0, "s": 50.0, "r": 900.0, "d": 4.0},
	{"w": 20.0, "s": 40.0, "r": 420.0, "d": 7.0}, {"w": 14.0, "s": 30.0, "r": 40.0, "d": 12.0}]

var world: World
var sfx: Sfx
var players: Array = []
var player: Ent = null
var bullets: Array = []
var parts: Array = []
var dmg_nums: Array = []
var dmg_dirs: Array = []
var feed: Array = []
var feed_ver := 0
var storm := {}
var bus := {"on": false, "x": 0.0, "y": 0.0, "x0": 0.0, "y0": 0.0, "dx": 1.0, "dy": 0.0, "ang": 0.0, "t": 0.0, "len": ROUTE_R * 2.0}
var DF: Dictionary = Data.DIFFS["normal"]
var clock := 0.0
var running := false
var paused := false
var ended := false
var end_timer := 0.0
var won := false
var final_place := 0
var alive_n := 25
var killer_name := ""
var shake := 0.0
var dmg_flash := 0.0
var hit_mark := 0.0
var drop_t := 35.0
var drop_n := 0
var next_id := 1
# ввод
var inp_mx := 0.0
var inp_my := 0.0
var inp_fire := false
var inp_build := false
var cam_yaw := 0.0
var cam_pitch := .3
var ads_on := false
var shoulder := 1.0
var auto_fire := true
var recoil_acc := 0.0
var prev_fire := false
var assist_off := 0.0
var aim_lock := {"on": false, "ang": 0.0, "dist": 0.0, "tight": false, "tgt": null}
var cam_ray := {"ok": false, "cx": 0.0, "cy": 0.0, "cz": 0.0, "ux": 1.0, "uz": 0.0, "L": 300.0, "ty": 0.0, "sy": 0.0}
var aim_hit = null
var scoped_now := false
var cur_zoom := 1.0
var cam_pos := Vector3.ZERO
var cam_target := Vector3.ZERO
var cam_fov := 68.0
var cam_aspect := 1.77

func rnd(a: float, b: float) -> float:
	return randf_range(a, b)

func irnd(a: int, b: int) -> int:
	return randi_range(a, b)

func tone(f: float, d: float, wave: String = "square", vol: float = .05, slide: float = 1.0) -> void:
	if sfx:
		sfx.tone(f, d, wave, vol, slide)

func vib(ms: int) -> void:
	if Prof.p.get("vibe", true):
		Input.vibrate_handheld(ms)

func banner(msg: String) -> void:
	banner_msg.emit(msg)

func th(x: float, y: float) -> float:
	return world.th(x, y)

# ---------- запуск матча ----------
func mk_ent(nm: String, bot: bool, x: float, y: float, color: Color) -> Ent:
	var e := Ent.new()
	e.id = next_id
	next_id += 1
	e.name = nm
	e.bot = bot
	e.x = x
	e.y = y
	e.ang = rnd(0, TAU)
	if bot:
		e.inv = {"pistol": 30}
	e.mats = 120 if bot else 200
	e.color = color
	e.skin = Color(["#f1c9a0", "#d9a47a", "#b97c55", "#8a5a3a"][irnd(0, 3)])
	e.tx = x
	e.ty = y
	e.react = rnd(0, .3)
	e.lx = x
	e.ly = y
	return e

func begin(w: World, diff_key: String, look: Dictionary) -> void:
	world = w
	DF = Data.DIFFS[diff_key]
	next_id = 1
	players = []
	bullets = []
	parts = []
	dmg_nums = []
	dmg_dirs = []
	feed = []
	feed_ver += 1
	clock = 0.0
	ads_on = false
	recoil_acc = 0.0
	prev_fire = false
	assist_off = 0.0
	ended = false
	won = false
	end_timer = 0.0
	dmg_flash = 0.0
	shake = 0.0
	hit_mark = 0.0
	killer_name = ""
	drop_t = 35.0
	drop_n = 0
	cur_zoom = 1.0
	Prof.begin_match_stats()
	player = mk_ent("Вы", false, World.CX, World.CY, Color.WHITE)
	player.look = look
	player.skin = look["tone"]
	players.append(player)
	var names := Data.NAMES.duplicate()
	names.shuffle()
	for i in DF["bots"]:
		var pos: Vector2
		if randf() < .65:
			var t = world.towns[irnd(0, world.towns.size() - 1)]
			pos = world.free_near(t.x, t.y, 260.0, 14.0)
		else:
			pos = world.free_pos(14.0)
		var b := mk_ent(names[i % names.size()], true, pos.x, pos.y, Color(Data.BOT_COLORS[i % Data.BOT_COLORS.size()]))
		b.tgt0 = pos
		b.look = Data.SKINS[irnd(0, Data.SKINS.size() - 1)]
		b.skin = b.look["tone"]
		players.append(b)
	alive_n = players.size()
	init_storm()
	init_bus()
	for p in players:
		assign_air(p, p.tgt0 if p.bot else null, p.bot)
	cam_yaw = bus["ang"]
	cam_pitch = .3
	running = true
	paused = false
	banner("Автобус летит над островом")

func alive_count() -> int:
	var n := 0
	for p in players:
		if p.alive:
			n += 1
	return n

func has_gun(e: Ent) -> bool:
	return e.inv.has(e.cur)

func has_ammo(e: Ent) -> bool:
	for w in e.inv:
		if e.inv[w] > 0:
			return true
	return false

# ---------- буря ----------
func init_storm() -> void:
	storm = {"cx": World.CX, "cy": World.CY, "r": 4600.0, "phase": -1, "t": 0.0, "mode": "wait", "tcx": World.CX, "tcy": World.CY, "tr": 4600.0, "fcx": World.CX, "fcy": World.CY, "fr": 4600.0, "dps": 1.0, "shrink": 40.0}
	next_phase()

func next_phase() -> void:
	storm["phase"] += 1
	if storm["phase"] >= PH.size():
		storm["mode"] = "done"
		return
	var p: Dictionary = PH[storm["phase"]]
	storm["mode"] = "wait"
	storm["t"] = p["w"]
	storm["fr"] = storm["r"]
	storm["fcx"] = storm["cx"]
	storm["fcy"] = storm["cy"]
	storm["tr"] = p["r"]
	storm["dps"] = p["d"]
	storm["shrink"] = p["s"]
	var max_off: float = maxf(0.0, storm["r"] - p["r"]) * .85
	var a := rnd(0, TAU)
	var d := sqrt(randf()) * max_off
	storm["tcx"] = clampf(storm["cx"] + cos(a) * d, p["r"], World.W - p["r"])
	storm["tcy"] = clampf(storm["cy"] + sin(a) * d, p["r"], World.H - p["r"])
	if storm["phase"] > 0 and running:
		banner("Новая зона отмечена на карте")

func update_storm(dt: float) -> void:
	if storm["mode"] == "wait":
		storm["t"] -= dt
		if storm["t"] <= 0.0:
			storm["mode"] = "shrink"
			storm["t"] = storm["shrink"]
			banner("Буря сужается")
			tone(200, .6, "sawtooth", .05, 1.5)
	elif storm["mode"] == "shrink":
		storm["t"] -= dt
		var k: float = 1.0 - maxf(0.0, storm["t"] / storm["shrink"])
		storm["r"] = storm["fr"] + (storm["tr"] - storm["fr"]) * k
		storm["cx"] = storm["fcx"] + (storm["tcx"] - storm["fcx"]) * k
		storm["cy"] = storm["fcy"] + (storm["tcy"] - storm["fcy"]) * k
		if storm["t"] <= 0.0:
			next_phase()

# ---------- оружие ----------
func clip_of(e: Ent, w: String) -> int:
	var m: int = Data.WPN[w].mag
	var a: int = e.inv.get(w, 0)
	if not e.clip.has(w):
		e.clip[w] = mini(m, a)
	if e.clip[w] > a:
		e.clip[w] = a
	return e.clip[w]

func start_reload(e: Ent) -> bool:
	var w: Data.WDef = Data.WPN[e.cur]
	var a: int = e.inv.get(e.cur, 0)
	if e.rl > 0.0 or e.using > 0.0 or not (a > 0):
		return false
	if clip_of(e, e.cur) >= mini(w.mag, a):
		return false
	e.rl = w.rld * (1.0 - .06 * e.rar.get(e.cur, 0))
	e.rl_w = e.cur
	e.rl_max = e.rl
	if e == player:
		vib(12)
		tone(180, .06, "square", .05, .8)
	return true

func step_reload(e: Ent, dt: float) -> void:
	if not (e.rl > 0.0):
		return
	if e.cur != e.rl_w or e.using > 0.0:
		e.rl = 0.0
		return
	e.rl -= dt
	if e.rl <= 0.0:
		e.rl = 0.0
		e.clip[e.rl_w] = mini(Data.WPN[e.rl_w].mag, e.inv.get(e.rl_w, 0))
		if e == player:
			tone(520, .05, "square", .05, .8)
			tone(300, .07, "square", .05, .8)

func eff_spread(e: Ent, w: Data.WDef) -> float:
	var mv := 1.25 if Vector2(e.mx, e.my).length() > .1 else 1.0
	return w.spr * (w.ads_mul if e.ads else w.hip_mul) * (1.0 + e.bloom * w.bloom_mul) * mv

func fire(e: Ent) -> bool:
	var w: Data.WDef = Data.WPN[e.cur]
	var a: int = e.inv.get(e.cur, 0)
	if not (a > 0) or e.cd > 0.0 or e.using > 0.0 or e.rl > 0.0:
		return false
	if clip_of(e, e.cur) <= 0:
		start_reload(e)
		return false
	e.inv[e.cur] = a - 1
	e.clip[e.cur] -= 1
	e.cd = w.rate
	e.flash = .06
	if e.clip[e.cur] <= 0 and e.inv[e.cur] > 0:
		start_reload(e)
	var is_p := e == player
	var spr: float = eff_spread(e, w) if is_p else w.spr
	e.bloom = minf(1.0, e.bloom + w.bloom)
	if is_p:
		var k := .6 if e.ads else 1.0
		var before := cam_pitch
		cam_pitch = maxf(-.55, cam_pitch - w.kick * k)
		recoil_acc += before - cam_pitch
		cam_yaw += (randf() - .5) * 2.0 * w.kick_x * k
		shake = minf(10.0, shake + w.kick * 28.0)
		vib(roundi(4 + w.kick * 320))
	var mz := th(e.x, e.y) + 24.0
	var slope := 0.0
	if is_p:
		slope = aim_slope_for(e, mz)
	elif e.target and e.target.alive:
		var dd := maxf(1.0, Vector2(e.target.x - e.x, e.target.y - e.y).length())
		slope = (th(e.target.x, e.target.y) + 22.0 - mz) / dd
	for i in w.pel:
		var ang := e.ang + (randf() - .5) * 2.0 * spr
		if e.bot:
			ang += (randf() - .5) * 2.0 * DF["err"] * .6
		var b := Types.Bullet.new()
		b.x = e.x + cos(e.ang) * (e.r + 8.0)
		b.y = e.y + sin(e.ang) * (e.r + 8.0)
		b.vx = cos(ang) * w.spd
		b.vy = sin(ang) * w.spd
		b.dmg = w.dmg * (1.0 + .08 * e.rar.get(e.cur, 0))
		b.life = w.rng / w.spd
		b.own = e.id
		b.col = w.c
		b.z = mz
		b.vz = slope * w.spd * (1.0 + (randf() - .5) * 2.0 * spr * .6)
		bullets.append(b)
	if player:
		var d := Vector2(e.x - player.x, e.y - player.y).length()
		var v := maxf(0.0, 1.0 - d / 800.0)
		if v > 0.0:
			var fr: float = {"pistol": 240.0, "smg": 300.0, "rifle": 180.0, "shotgun": 110.0, "sniper": 90.0}[e.cur]
			tone(fr, .2 if (e.cur == "shotgun" or e.cur == "sniper") else .08, "sawtooth" if e.cur == "rifle" else "square", .06 * v, .35)
	return true

func spark(x: float, y: float, col: Color) -> void:
	if parts.size() > 380:
		return
	for i in 3:
		var a := rnd(0, TAU)
		var s := rnd(40, 140)
		var p := Types.Part.new()
		p.x = x; p.y = y; p.z = rnd(8, 24); p.vz = rnd(20, 110); p.vx = cos(a) * s; p.vy = sin(a) * s; p.l = rnd(.15, .35); p.col = col
		parts.append(p)

func ent_by_id(id: int) -> Ent:
	for p in players:
		if p.id == id:
			return p
	return null

func damage(e: Ent, d: float, by: int) -> void:
	if not e.alive or e.spawn_t > 0.0:
		return
	var d0 := d
	e.hit_flash = .12
	if e.sh > 0.0:
		var a := minf(e.sh, d)
		e.sh -= a
		d -= a
	e.hp -= d
	var att := ent_by_id(by)
	if e == player:
		if att and att != e:
			var dd := Types.DmgDir.new()
			dd.x = att.x; dd.y = att.y; dd.t = 1.6
			dmg_dirs.append(dd)
			if dmg_dirs.size() > 4:
				dmg_dirs.pop_front()
		shake = minf(10.0, shake + d * .25)
		dmg_flash = .3
		vib(25)
		tone(120, .1, "sawtooth", .06, .5)
	if att == player and e != player:
		Prof.ms["dmg"] += d0
		hit_mark = .18
		tone(900, .04, "square", .03)
		var dn := Types.DmgNum.new()
		dn.x = e.x; dn.y = e.y; dn.v = maxi(1, roundi(d0)); dn.big = d0 >= 40.0
		dmg_nums.append(dn)
	if e.hp <= 0.0:
		kill_ent(e, by)
	elif e.bot and att:
		e.threat = att
		e.threat_t = 4.0

func push_feed(msg: String) -> void:
	feed.append({"t": 5.0, "msg": msg})
	if feed.size() > 4:
		feed.pop_front()
	feed_ver += 1

func kill_ent(e: Ent, by: int) -> void:
	e.alive = false
	e.dead_t = 0.0
	e.hp = 0.0
	e.sh = 0.0
	e.using = 0.0
	for w in Data.WORDER:
		if e.inv.get(w, 0) > 0 and w != "pistol":
			var it := Types.Item.new()
			it.x = e.x + rnd(-16, 16); it.y = e.y + rnd(-16, 16); it.k = "w"; it.w = w; it.amt = e.inv[w]; it.rar = e.rar.get(w, 0)
			world.loot.append(it)
	if e.meds > 0:
		_drop(e, "med")
	if e.pots > 0:
		_drop(e, "pot")
	_drop(e, "mats")
	for i in 10:
		var a := rnd(0, TAU)
		var s := rnd(40, 180)
		var p := Types.Part.new()
		p.x = e.x; p.y = e.y; p.z = 18.0; p.vz = rnd(30, 140); p.vx = cos(a) * s; p.vy = sin(a) * s; p.l = rnd(.3, .7); p.col = e.color
		parts.append(p)
	var k := ent_by_id(by)
	if k == player and e != player:
		banner("Устранён " + e.name)
	if k and k != e:
		k.kills += 1
		push_feed("%s устранил %s" % [k.name, e.name])
	else:
		push_feed(e.name + " погиб в буре")
	alive_n = alive_count()
	if e == player:
		killer_name = k.name if (k and k != e) else "буря"
		final_place = alive_n + 1
		ended = true
		end_timer = 1.3
		vib(200)
		tone(80, .5, "sawtooth", .08, .3)

func _drop(e: Ent, kind: String) -> void:
	var it := Types.Item.new()
	it.x = e.x + rnd(-14, 14)
	it.y = e.y + rnd(-14, 14)
	it.k = kind
	world.loot.append(it)

func step_bullets(dt: float) -> void:
	var i := bullets.size() - 1
	while i >= 0:
		var b: Types.Bullet = bullets[i]
		var dead := false
		var n := maxi(1, ceili(Vector2(b.vx, b.vy).length() * dt / 8.0))
		var sx := b.vx * dt / n
		var sy := b.vy * dt / n
		var sz := b.vz * dt / n
		for s in n:
			b.x += sx
			b.y += sy
			b.z += sz
			if b.x < 0 or b.y < 0 or b.x > World.W or b.y > World.H:
				dead = true
				break
			var bg := th(b.x, b.y)
			if b.z < bg:
				dead = true
				spark(b.x, b.y, Color("#b9a77a"))
				break
			for rc in world.rects_at(b.x, b.y):
				if b.x >= rc.x and b.x <= rc.x + rc.w and b.y >= rc.y and b.y <= rc.y + rc.h and b.z <= bg + (rc.hh if rc.type == "rock" else 52.0):
					dead = true
					spark(b.x, b.y, Color("#ffcf86") if rc.type == "built" else Color("#dcdcdc"))
					if rc.type == "built":
						rc.hp -= b.dmg
						rc.fl = .1
						if rc.hp <= 0.0:
							world.remove_rect(rc)
							for q in 6:
								spark(rc.x + rc.w / 2, rc.y + rc.h / 2, Color("#e0ac5c"))
					break
			if dead:
				break
			for e in players:
				if not e.alive or e.id == b.own or e.spawn_t > 0.0:
					continue
				var dx: float = e.x - b.x
				var dy: float = e.y - b.y
				if dx > 40.0 or dx < -40.0 or dy > 40.0 or dy < -40.0:
					continue
				var eg := th(e.x, e.y)
				if b.z < eg - 3.0 or b.z > eg + 46.0:
					continue
				if dx * dx + dy * dy < (e.r + 2.0) * (e.r + 2.0):
					damage(e, b.dmg, b.own)
					dead = true
					break
		b.life -= dt
		if dead or b.life <= 0.0:
			bullets.remove_at(i)
		i -= 1

# ---------- предметы ----------
func apply_item(e: Ent, it: Types.Item) -> bool:
	if it.k == "w":
		var w: Data.WDef = Data.WPN[it.w]
		var had := e.inv.has(it.w)
		var up: bool = it.rar > int(e.rar.get(it.w, 0))
		if had and e.inv[it.w] >= w.cap and not up:
			return false
		if up:
			e.rar[it.w] = it.rar
			if e == player:
				banner(w.n + ": " + Data.rar_name(it.rar).to_lower())
		e.inv[it.w] = mini(w.cap, e.inv.get(it.w, 0) + (it.amt if it.amt > 0 else w.ammo))
		if not had and (e.cur == "pistol" or not (e.inv.get(e.cur, 0) > 0)):
			e.cur = it.w
		return true
	if it.k == "med":
		if e.meds >= 5:
			return false
		e.meds += 1
		return true
	if it.k == "pot":
		if e.pots >= 5:
			return false
		e.pots += 1
		return true
	if it.k == "mats":
		if e.mats >= 999:
			return false
		e.mats = mini(999, e.mats + 50)
		return true
	if it.k == "ammo":
		for w in e.inv:
			e.inv[w] = mini(Data.WPN[w].cap, e.inv[w] + ceili(Data.WPN[w].ammo * .6))
		return true
	return false

func open_chest(c: Types.Chest, e: Ent) -> void:
	c.open = true
	c.t = 0.0
	if e == player:
		Prof.ms["chests"] += 1
	var a0 := rnd(0, TAU)
	if c.drop:
		var ws := [World.pick_weapon(true), "rifle", "sniper", "shotgun"]
		for i in 5:
			var a := a0 + i * 1.257
			var it := Types.Item.new()
			it.x = c.x + cos(a) * 22.0
			it.y = c.y + sin(a) * 22.0
			if i < 2:
				it.k = "w"
				it.w = ws[irnd(0, ws.size() - 1)]
				it.rar = maxi(3, World.roll_rar(true))
			else:
				it.k = "med" if i == 2 else ("pot" if i == 3 else "mats")
			world.loot.append(it)
		for k in 24:
			spark(c.x, c.y, Color("#ffd86b"))
		if e == player:
			tone(880, .22, "triangle", .06, 1.8)
			vib(40)
		return
	for i in 4:
		var a := a0 + i * 1.57
		var px := c.x + cos(a) * 17.0
		var py := c.y + sin(a) * 17.0
		if i == 0:
			var it := Types.Item.new()
			it.x = px; it.y = py; it.k = "w"; it.w = World.pick_weapon(true); it.rar = maxi(1, World.roll_rar(true))
			world.loot.append(it)
		else:
			world.roll_loot(px, py, true)
	for k in 16:
		spark(c.x, c.y, Color("#ffd86b"))
	if e == player:
		tone(880, .22, "triangle", .06, 1.8)
		vib(30)

func try_pickup(e: Ent) -> void:
	for c in world.chests:
		if c.open:
			continue
		var dx: float = e.x - c.x
		var dy: float = e.y - c.y
		if dx * dx + dy * dy < (e.r + 18.0) * (e.r + 18.0):
			open_chest(c, e)
	var i := world.loot.size() - 1
	while i >= 0:
		var it: Types.Item = world.loot[i]
		var dx: float = e.x - it.x
		var dy: float = e.y - it.y
		if dx * dx + dy * dy < (e.r + 12.0) * (e.r + 12.0) and apply_item(e, it):
			world.loot.remove_at(i)
			it.gone = true
			if e == player:
				tone(660, .07, "triangle", .05, 1.4)
		i -= 1

func start_use(e: Ent) -> bool:
	if e.using > 0.0:
		return false
	if e.pots > 0 and e.sh <= 50.0:
		e.use_kind = "pot"
		e.using = 1.4
		return true
	if e.meds > 0 and e.hp < 100.0:
		e.use_kind = "med"
		e.using = 1.8
		return true
	if e.pots > 0 and e.sh < 100.0:
		e.use_kind = "pot"
		e.using = 1.4
		return true
	return false

func finish_use(e: Ent) -> void:
	if e.use_kind == "med" and e.meds > 0:
		e.meds -= 1
		e.hp = minf(100.0, e.hp + 60.0)
	elif e.use_kind == "pot" and e.pots > 0:
		e.pots -= 1
		e.sh = minf(100.0, e.sh + 50.0)
	e.use_kind = ""
	if e == player:
		Prof.ms["heals"] += 1
		tone(520, .15, "sine", .06, 1.6)

func build_wall(e: Ent) -> bool:
	if e.mats < 10:
		return false
	var a := e.ang
	var vertical := absf(cos(a)) > absf(sin(a))
	var w := 14.0 if vertical else 84.0
	var h := 84.0 if vertical else 14.0
	for dd in [66.0, 88.0, 110.0]:
		var px: float = roundf((e.x + cos(a) * dd) / 42.0) * 42.0
		var py: float = roundf((e.y + sin(a) * dd) / 42.0) * 42.0
		var rc := Types.Rc.new()
		rc.x = px - w / 2.0; rc.y = py - h / 2.0; rc.w = w; rc.h = h; rc.type = "built"; rc.hp = 200.0; rc.mx = 200.0; rc.t0 = clock
		if rc.x < 0 or rc.y < 0 or rc.x + w > World.W or rc.y + h > World.H:
			continue
		var blocked := false
		for p in players:
			if p.alive and World.circle_hits_rect(p.x, p.y, p.r + 2.0, rc):
				blocked = true
				break
		if blocked:
			continue
		for o in world.rects_near(px, py, 100.0):
			if o.type == "built" and absf(o.x - rc.x) < 2.0 and absf(o.y - rc.y) < 2.0:
				return false
		world.add_rect(rc)
		e.mats -= 10
		if e == player:
			Prof.ms["builds"] += 1
			tone(160, .09, "square", .06, .6)
		return true
	return false

# ---------- боты ----------
func choose_weapon(e: Ent, d: float) -> void:
	var best := e.cur
	var bs := -1e9
	for w in e.inv:
		if not (e.inv[w] > 0):
			continue
		var wd: Data.WDef = Data.WPN[w]
		var s := wd.base - absf(d - wd.ideal) / 450.0
		if s > bs:
			bs = s
			best = w
	e.cur = best

func bot_think(e: Ent, dt: float) -> void:
	e.react -= dt
	e.trig -= dt
	e.strafe_t -= dt
	e.bias_t -= dt
	e.threat_t -= dt
	e.chk_t += dt
	e.wep_t -= dt
	e.tmr -= dt
	e.mx = 0.0
	e.my = 0.0
	if e.using > 0.0:
		return
	if e.react <= 0.0:
		e.react = DF["react"] * (.7 + randf() * .6)
		var best: Ent = null
		var bd := 1e9
		for p in players:
			if p == e or not p.alive or p.spawn_t > 0.0:
				continue
			var d := Vector2(e.x - p.x, e.y - p.y).length()
			if d < 560.0 and d < bd and world.los(e.x, e.y, p.x, p.y):
				best = p
				bd = d
		if best == null and e.threat_t > 0.0 and e.threat and e.threat.alive:
			var d2 := Vector2(e.x - e.threat.x, e.y - e.threat.y).length()
			if d2 < 600.0:
				best = e.threat
		if best != e.target:
			e.wep_t = 0.0
		e.target = best
	var tg: Ent = e.target if (e.target and e.target.alive and has_ammo(e)) else null
	if tg:
		var dx := tg.x - e.x
		var dy := tg.y - e.y
		var d := maxf(.001, sqrt(dx * dx + dy * dy))
		if e.wep_t <= 0.0:
			choose_weapon(e, d)
			e.wep_t = 1.0
		if e.bias_t <= 0.0:
			e.bias = (randf() - .5) * 2.0 * DF["err"]
			e.bias_t = rnd(.5, 1.2)
		var want := atan2(dy, dx) + e.bias
		var step: float = DF["turn"] * dt
		e.ang += clampf(angle_difference(e.ang, want), -step, step)
		var w: Data.WDef = Data.WPN[e.cur]
		if e.trig <= 0.0:
			e.trig_on = not e.trig_on
			e.trig = rnd(.6, 1.5) if e.trig_on else rnd(.3, .9)
		if e.trig_on and absf(angle_difference(e.ang, want)) < .14 and d < w.rng * .92 and e.inv.get(e.cur, 0) > 0:
			fire(e)
		if e.strafe_t <= 0.0:
			e.strafe = -1.0 if randf() < .5 else 1.0
			e.strafe_t = rnd(.8, 2.0)
		var fx := dx / d
		var fy := dy / d
		var mvf := 0.0
		if d > w.ideal + 50.0:
			mvf = 1.0
		elif d < w.ideal - 60.0:
			mvf = -1.0
		var mx := fx * mvf - fy * e.strafe * .7
		var my := fy * mvf + fx * e.strafe * .7
		var l := sqrt(mx * mx + my * my)
		if l > 1.0:
			mx /= l
			my /= l
		e.mx = mx
		e.my = my
		if e.hp + e.sh < 45.0 and (e.meds > 0 or e.pots > 0) and d > 220.0 and randf() < dt * 1.2:
			start_use(e)
		if e.hp + e.sh < 75.0 and e.build_cd <= 0.0 and e.mats >= 10 and d < 420.0:
			var keep := e.ang
			e.ang = atan2(dy, dx)
			e.build_cd = 5.0 if build_wall(e) else 1.5
			e.ang = keep
	else:
		e.target = null
		if (e.hp < 65.0 and e.meds > 0) or (e.sh < 30.0 and e.pots > 0):
			if start_use(e):
				return
		if Vector2(e.x - storm["cx"], e.y - storm["cy"]).length() > storm["r"] - 25.0:
			e.tx = storm["cx"] + rnd(-60, 60)
			e.ty = storm["cy"] + rnd(-60, 60)
			e.tmr = 1.0
		elif e.tmr <= 0.0:
			e.tmr = rnd(2.5, 5.0)
			var use_next: bool = storm["mode"] == "shrink" or (storm["mode"] == "wait" and storm["t"] < 14.0)
			var zx: float = storm["tcx"] if use_next else storm["cx"]
			var zy: float = storm["tcy"] if use_next else storm["cy"]
			var zr: float = storm["tr"] if use_next else storm["r"]
			if Vector2(e.x - zx, e.y - zy).length() > zr * .7:
				e.tx = zx + rnd(-.4, .4) * zr
				e.ty = zy + rnd(-.4, .4) * zr
			else:
				var best = null
				var bd := 520.0
				for it in world.loot:
					var dxl: float = e.x - it.x
					var dyl: float = e.y - it.y
					if absf(dxl) > bd or absf(dyl) > bd:
						continue
					var d3 := sqrt(dxl * dxl + dyl * dyl)
					if d3 >= bd:
						continue
					var ok := false
					if it.k == "w":
						ok = not e.inv.has(it.w) or e.inv[it.w] < Data.WPN[it.w].cap * .5
					elif it.k == "med":
						ok = e.meds < 3
					elif it.k == "pot":
						ok = e.pots < 3
					elif it.k == "mats":
						ok = e.mats < 100
					else:
						ok = true
					if ok:
						best = it
						bd = d3
				if best == null:
					for c in world.chests:
						if c.open:
							continue
						var d4 := Vector2(e.x - c.x, e.y - c.y).length()
						if d4 < bd:
							best = c
							bd = d4
				if best:
					e.tx = best.x
					e.ty = best.y
				else:
					var a := rnd(0, TAU)
					var r := rnd(200, 520)
					var x := e.x + cos(a) * r
					var y := e.y + sin(a) * r
					var dz := Vector2(x - zx, y - zy).length()
					if dz > zr * .85:
						x = zx + (x - zx) / dz * zr * .85
						y = zy + (y - zy) / dz * zr * .85
					for k in 30:
						if world.land_val(x, y) >= 140.0 and world.river_d(x, y) >= World.RW0 + 20.0:
							break
						x += (World.CX - x) * .06
						y += (World.CY - y) * .06
					e.tx = clampf(x, 40.0, World.W - 40.0)
					e.ty = clampf(y, 40.0, World.H - 40.0)
		var gx := e.tx - e.x
		var gy := e.ty - e.y
		var gd := sqrt(gx * gx + gy * gy)
		if gd > 16.0:
			var ax := gx / gd
			var ay := gy / gd
			if e.avoid_t > 0.0:
				e.avoid_t -= dt
				var px := -ay * e.avoid_dir
				var py := ax * e.avoid_dir
				ax = ax * .3 + px * .9
				ay = ay * .3 + py * .9
			e.mx = ax
			e.my = ay
			var want2 := atan2(ay, ax)
			var step2: float = DF["turn"] * dt
			e.ang += clampf(angle_difference(e.ang, want2), -step2, step2)
		else:
			e.tmr = minf(e.tmr, .15)
	if e.chk_t >= .6:
		if Vector2(e.x - e.lx, e.y - e.ly).length() < 10.0 and (e.mx != 0.0 or e.my != 0.0) and tg == null:
			e.avoid_t = 1.0
			e.avoid_dir = -1.0 if randf() < .5 else 1.0
			e.tmr = minf(e.tmr, 1.2)
		e.lx = e.x
		e.ly = e.y
		e.chk_t = 0.0

# ---------- управление игроком ----------
func aim_slope_for(e: Ent, mz: float) -> float:
	var cam: float
	if not cam_ray["ok"] or scoped_now:
		cam = -(cam_pitch - .3) * 150.0 / 160.0
	else:
		cam = (cam_ray["ty"] - mz) / (cam_ray["L"] if cam_ray["L"] != 0.0 else 300.0)
	if aim_hit:
		return (aim_hit["z"] - mz) / aim_hit["d"]
	var t = aim_lock["tgt"]
	if aim_lock["on"] and t:
		var d := maxf(1.0, Vector2(t.x - e.x, t.y - e.y).length())
		var sl: float = (th(t.x, t.y) + 22.0 - mz) / d
		if absf(sl - cam) * d < 40.0:
			return sl
	return cam

func aim_base(e: Ent) -> float:
	if not cam_ray["ok"] or scoped_now:
		aim_hit = null
		return cam_yaw
	var w: Data.WDef = Data.WPN[e.cur]
	var best: Ent = null
	var bt := 1e9
	for p in players:
		if p == e or not p.alive or p.spawn_t > 0.0:
			continue
		var dx: float = p.x - cam_ray["cx"]
		var dz: float = p.y - cam_ray["cz"]
		var t: float = dx * cam_ray["ux"] + dz * cam_ray["uz"]
		if t < 0.0 or t > w.rng + 160.0:
			continue
		var perp: float = absf(dx * cam_ray["uz"] - dz * cam_ray["ux"])
		var hy: float = cam_ray["cy"] + cam_ray["sy"] * t
		var pg := th(p.x, p.y)
		if hy < pg - 8.0 or hy > pg + 54.0:
			continue
		if perp < p.r + 2.0 and t < bt and world.los(e.x, e.y, p.x, p.y):
			bt = t
			best = p
	aim_hit = null
	if best:
		var pg2 := th(best.x, best.y)
		var hz: float = cam_ray["cy"] + cam_ray["sy"] * bt
		aim_hit = {"z": maxf(pg2 + 6.0, minf(pg2 + 38.0, hz)), "d": maxf(1.0, Vector2(best.x - e.x, best.y - e.y).length())}
	var tx: float = best.x if best else e.x + cos(cam_yaw) * cam_ray["L"]
	var ty: float = best.y if best else e.y + sin(cam_yaw) * cam_ray["L"]
	return atan2(ty - e.y, tx - e.x)

func compute_lock(e: Ent) -> void:
	var w: Data.WDef = Data.WPN[e.cur]
	aim_lock["on"] = false
	aim_lock["tgt"] = null
	aim_lock["tight"] = false
	if not (w.assist_cone > 0.0):
		return
	var cone := w.assist_cone * (.65 if e.ads else 1.0)
	var rng := w.rng * .95
	var best = null
	var bs := 1e9
	for p in players:
		if p == e or not p.alive or p.spawn_t > 0.0:
			continue
		var dx: float = p.x - e.x
		var dy: float = p.y - e.y
		var d := sqrt(dx * dx + dy * dy)
		if d > rng:
			continue
		var moving := Vector2(p.mx, p.my).length() > .05
		var spd: float = (float(DF["spd"]) if p.bot else float(Data.PSPEED)) if moving else 0.0
		var t := d / w.spd * w.lead
		var a := atan2(p.y + p.my * spd * t - e.y, p.x + p.mx * spd * t - e.x)
		var diff := absf(angle_difference(e.ang, a)) - atan2(p.r, d)
		if diff < cone and diff < bs and world.los(e.x, e.y, p.x, p.y):
			bs = diff
			best = {"p": p, "a": a, "d": d, "diff": diff}
	if best:
		aim_lock["on"] = true
		aim_lock["ang"] = best["a"]
		aim_lock["dist"] = best["d"]
		aim_lock["tgt"] = best["p"]
		aim_lock["tight"] = best["diff"] < .05 + atan2(14.0, best["d"]) * .5

func player_control(e: Ent, dt: float) -> void:
	var sx := inp_mx
	var sy := inp_my
	if e.em > 0 and not won and (Vector2(sx, sy).length() > .2 or inp_fire or e.using > 0.0):
		e.em = 0
	if e.em > 0:
		sx = 0.0
		sy = 0.0
	var w: Data.WDef = Data.WPN[e.cur]
	if e.using > 0.0:
		ads_on = false
	e.ads = ads_on and has_gun(e)
	e.slow = w.slow if e.ads else 1.0
	var fwd := -sy
	var side := sx
	var ca := cos(cam_yaw)
	var sa := sin(cam_yaw)
	e.mx = fwd * ca - side * sa
	e.my = fwd * sa + side * ca
	var base := aim_base(e)
	e.ang = base + assist_off
	compute_lock(e)
	var firing := inp_fire
	if not firing and auto_fire and aim_lock["on"] and aim_lock["tight"] and (not w.scope or e.ads) and e.inv.get(e.cur, 0) > 0:
		firing = true
	if firing and aim_lock["on"]:
		var want := angle_difference(base, aim_lock["ang"])
		if not prev_fire:
			assist_off = want * minf(1.0, w.assist_pull * 1.6)
		else:
			assist_off += (want - assist_off) * (1.0 - exp(-dt * w.assist_pull * 22.0 * (.8 if e.ads else 1.0)))
	else:
		assist_off *= exp(-dt * 9.0)
	assist_off = clampf(assist_off, -.35, .35)
	e.ang = base + assist_off
	prev_fire = firing
	if firing:
		fire(e)
	elif recoil_acc > 0.0:
		var r := minf(recoil_acc, dt * .3)
		cam_pitch = minf(.95, cam_pitch + r)
		recoil_acc -= r
	if inp_build and e.build_cd <= 0.0:
		build_wall(e)
		e.build_cd = .2

# ---------- шаг ----------
func step_entity(e: Ent, dt: float) -> void:
	if e.air > 0:
		air_step(e, dt)
		return
	if e.em > 0:
		e.em_t += dt
	e.cd -= dt
	e.hit_flash -= dt
	e.flash -= dt
	e.build_cd -= dt
	e.bloom = maxf(0.0, e.bloom - dt * Data.WPN[e.cur].recov)
	step_reload(e, dt)
	if e.bot:
		bot_think(e, dt)
	else:
		player_control(e, dt)
	if e.using > 0.0:
		e.using -= dt
		if e.using <= 0.0:
			finish_use(e)
	if e.bot and e.target == null and e.rl <= 0.0 and e.inv.get(e.cur, 0) > 0 and clip_of(e, e.cur) < Data.WPN[e.cur].mag * .5:
		start_reload(e)
	var sp: float = (DF["spd"] if e.bot else Data.PSPEED) * (.5 if e.using > 0.0 else 1.0) * e.slow * (.5 if e.wet else 1.0)
	e.x += e.mx * sp * dt
	e.y += e.my * sp * dt
	e.ph += Vector2(e.mx, e.my).length() * sp * dt * .07
	world.collide(e)
	try_pickup(e)
	if Vector2(e.x - storm["cx"], e.y - storm["cy"]).length() > storm["r"]:
		e.storm_t += dt
		if e.storm_t >= 1.0:
			e.storm_t = 0.0
			damage(e, storm["dps"], -1)
	else:
		e.storm_t = 0.0

func update(dt: float) -> void:
	clock += dt
	update_bus(dt)
	if not (player.air > 0) and not ended:
		drop_t -= dt
		if drop_t <= 0.0 and drop_n < 3:
			drop_t = rnd(55, 75)
			drop_n += 1
			var p = null
			for i in 12:
				if p != null:
					break
				var q := world.free_pos(14.0)
				if Vector2(q.x - storm["tcx"], q.y - storm["tcy"]).length() < storm["tr"] * .85:
					p = q
			if p != null:
				var c := Types.Chest.new()
				c.x = p.x
				c.y = p.y
				c.drop = true
				world.chests.append(c)
				banner("Воздушная поставка! Смотрите на карту")
				tone(520, .3, "sawtooth", .05, 1.2)
	if not (player.air > 0):
		update_storm(dt)
	for e in players:
		if e.alive:
			step_entity(e, dt)
		else:
			e.dead_t += dt
	step_bullets(dt)
	var i := parts.size() - 1
	while i >= 0:
		var p: Types.Part = parts[i]
		p.x += p.vx * dt
		p.y += p.vy * dt
		p.vz -= 420.0 * dt
		p.z += p.vz * dt
		if p.z < 1.0:
			p.z = 1.0
			p.vz *= -.3
		p.l -= dt
		if p.l <= 0.0:
			parts.remove_at(i)
		i -= 1
	i = dmg_dirs.size() - 1
	while i >= 0:
		dmg_dirs[i].t -= dt
		if dmg_dirs[i].t <= 0.0:
			dmg_dirs.remove_at(i)
		i -= 1
	for r in world.rects:
		if r.fl > 0.0:
			r.fl -= dt
	i = feed.size() - 1
	while i >= 0:
		feed[i]["t"] -= dt
		if feed[i]["t"] <= 0.0:
			feed.remove_at(i)
			feed_ver += 1
		i -= 1
	i = dmg_nums.size() - 1
	while i >= 0:
		dmg_nums[i].t += dt
		if dmg_nums[i].t > 1.0:
			dmg_nums.remove_at(i)
		i -= 1
	shake = maxf(0.0, shake - dt * 20.0)
	dmg_flash = maxf(0.0, dmg_flash - dt)
	hit_mark = maxf(0.0, hit_mark - dt)
	if not ended and player.alive and alive_n == 1:
		won = true
		player.em = 1
		player.em_t = 0.0
		ended = true
		final_place = 1
		killer_name = ""
		end_timer = 1.4
		tone(523, .5, "triangle", .07, 1.5)
	if ended and end_timer > 0.0:
		end_timer -= dt
		if end_timer <= 0.0:
			match_over.emit(won)

func start_emote(k: int) -> void:
	if not player or not player.alive or player.air > 0 or player.using > 0.0 or ended:
		return
	player.em = k
	player.em_t = 0.0
	tone(440 + k * 110, .12, "triangle", .05, 1.3)

func player_jump() -> void:
	if not player or not player.alive:
		return
	if player.air == 1:
		leave_bus(player)
	elif player.air == 2 and player.alt < BUS_ALT - 100.0:
		deploy_glider(player)

# ---------- автобус и приземление ----------
func init_bus() -> void:
	var a := rnd(0, TAU)
	var off := rnd(-1500, 1500)
	var dx := cos(a)
	var dy := sin(a)
	bus["dx"] = dx
	bus["dy"] = dy
	bus["ang"] = a
	bus["x0"] = World.CX - dy * off - dx * ROUTE_R
	bus["y0"] = World.CY + dx * off - dy * ROUTE_R
	bus["t"] = 0.0
	bus["x"] = bus["x0"]
	bus["y"] = bus["y0"]
	bus["on"] = true

func assign_air(e: Ent, tgt, is_bot: bool) -> void:
	e.air = 1
	e.spawn_t = 1.0
	e.alt = BUS_ALT
	e.vs = 0.0
	e.vh = 0.0
	e.dive = .45
	e.x = bus["x"]
	e.y = bus["y"]
	e.ang = bus["ang"]
	if tgt != null and is_bot:
		e.tgt = Vector2(tgt.x, tgt.y)
		var st: float = (tgt.x - bus["x0"]) * bus["dx"] + (tgt.y - bus["y0"]) * bus["dy"]
		e.jump_s = maxf(ROUTE_R - 3000.0, minf(bus["len"] - 200.0, st - rnd(150, 800)))

func leave_bus(e: Ent) -> void:
	e.air = 2
	e.alt = BUS_ALT - 25.0
	e.vs = 60.0
	e.vh = 80.0
	if e == player:
		cam_pitch = maxf(.55, cam_pitch)
		banner("Свободное падение")
		tone(300, .2, "sawtooth", .05, .5)
		vib(25)

func deploy_glider(e: Ent) -> void:
	if e.air != 2:
		return
	e.air = 3
	if e == player:
		banner("Планер раскрыт")
		tone(520, .18, "triangle", .06, .5)
		vib(20)

func land_entity(e: Ent) -> void:
	e.air = 0
	e.spawn_t = 0.0
	e.alt = 0.0
	e.vs = 0.0
	e.vh = 0.0
	e.mx = 0.0
	e.my = 0.0
	if e == player:
		var where := world.nearest_town_name(e.x, e.y)
		if where == "":
			where = Data.BIOMES[world.biome_at(e.x, e.y)]["n"]
		banner("Приземление: " + where + ("" if has_gun(e) else " · найдите оружие"))
		tone(180, .14, "triangle", .07, .6)
		vib(35)

func air_step(e: Ent, dt: float) -> void:
	e.spawn_t = 1.0
	if e.air == 1:
		e.x = bus["x"]
		e.y = bus["y"]
		e.alt = BUS_ALT
		e.ang = bus["ang"]
		if e.bot:
			if bus["t"] >= e.jump_s:
				leave_bus(e)
		elif bus["t"] >= bus["len"] - 60.0:
			leave_bus(e)
		return
	var fwd := 0.0
	var side := 0.0
	if e.bot:
		var dx := e.tgt.x - e.x
		var dy := e.tgt.y - e.y
		var d := sqrt(dx * dx + dy * dy)
		e.ang += angle_difference(e.ang, atan2(dy, dx)) * minf(1.0, dt * 3.0)
		var need: float = (e.alt - GLIDE_AT) * .75 + 650.0 if e.air == 2 else e.alt * 2.1
		fwd = 1.0 if d > need else (-.7 if d < need * .5 else .2)
		if e.air == 2 and e.alt <= GLIDE_AT + 30.0:
			deploy_glider(e)
	else:
		fwd = -inp_my
		side = inp_mx
		e.ang += angle_difference(e.ang, cam_yaw) * minf(1.0, dt * 9.0)
		if e.air == 2 and e.alt <= GLIDE_AT:
			deploy_glider(e)
	if e.air == 2:
		var dive := clampf(.45 + .55 * fwd, 0.0, 1.0)
		e.dive += (dive - e.dive) * minf(1.0, dt * 4.0)
		var ts := 230.0 + 200.0 * e.dive
		var thh := 80.0 + 300.0 * e.dive
		e.vs += (ts - e.vs) * minf(1.0, dt * 3.0)
		e.vh += (thh - e.vh) * minf(1.0, dt * 3.0)
		side *= 110.0
	else:
		var ts2 := 90.0 + 55.0 * fwd if fwd >= 0.0 else 90.0 - 35.0 * -fwd
		var th2 := 200.0 + 90.0 * fwd if fwd >= 0.0 else 200.0 - 100.0 * -fwd
		e.dive += (0.0 - e.dive) * minf(1.0, dt * 4.0)
		e.vs += (ts2 - e.vs) * minf(1.0, dt * 4.0)
		e.vh += (th2 - e.vh) * minf(1.0, dt * 4.0)
		side *= 130.0
	var c := cos(e.ang)
	var s := sin(e.ang)
	e.x = clampf(e.x + (c * e.vh - s * side) * dt, 12.0, World.W - 12.0)
	e.y = clampf(e.y + (s * e.vh + c * side) * dt, 12.0, World.H - 12.0)
	e.alt -= e.vs * dt
	if e.alt <= 0.0:
		land_entity(e)

func update_bus(dt: float) -> void:
	if not bus["on"]:
		return
	bus["t"] += BUS_SPD * dt
	bus["x"] = bus["x0"] + bus["dx"] * bus["t"]
	bus["y"] = bus["y0"] + bus["dy"] * bus["t"]
	if bus["t"] > bus["len"] + 300.0:
		bus["on"] = false

# ---------- камера ----------
func blocked_at(x: float, y: float) -> bool:
	for r in world.rects_near(x, y, 6.0):
		if x > r.x - 5.0 and x < r.x + r.w + 5.0 and y > r.y - 5.0 and y < r.y + r.h + 5.0:
			return true
	return false

func update_camera(dt: float) -> void:
	var e := player
	var lift := e.alt if e.air > 0 else 0.0
	var gy := th(e.x, e.y)
	var w: Data.WDef = Data.WPN[e.cur]
	var ads := e.ads and lift < 1.0 and e.alive
	scoped_now = ads and w.scope
	cur_zoom += ((w.ads_zoom if ads else 1.0) - cur_zoom) * minf(1.0, maxf(dt, .016) * 11.0)
	cam_fov = (84.0 if cam_aspect < 1.0 else 68.0) / cur_zoom
	var ca := cos(cam_yaw)
	var sa := sin(cam_yaw)
	if scoped_now:
		var ey := gy + 35.5
		cam_pos = Vector3(e.x + ca * 5.0, ey, e.y + sa * 5.0)
		cam_target = Vector3(e.x + ca * 160.0, ey - (cam_pitch - .3) * 150.0, e.y + sa * 160.0)
		cam_ray["ok"] = false
		return
	if e.air == 1:
		var p := clampf(cam_pitch, .05, .7)
		var D := 420.0
		cam_pos = Vector3(bus["x"] - ca * cos(p) * D, BUS_ALT + 60.0 + sin(p) * D, bus["y"] - sa * cos(p) * D)
		cam_target = Vector3(bus["x"], BUS_ALT + 30.0, bus["y"])
		cam_ray["ok"] = false
		return
	if lift > 1.0:
		var p2 := clampf(cam_pitch, .55, .95)
		var D2 := 150.0
		cam_pos = Vector3(e.x - ca * cos(p2) * D2, gy + lift + 24.0 + sin(p2) * D2, e.y - sa * cos(p2) * D2)
		cam_target = Vector3(e.x + ca * 36.0, gy + lift + 22.0, e.y + sa * 36.0)
		cam_ray["ok"] = false
		return
	var p3 := clampf(cam_pitch, -.55, .95)
	var zf := minf(1.0, (cur_zoom - 1.0) / .55)
	var D3 := 108.0 - zf * 26.0
	var S := shoulder * (27.0 - zf * 9.0)
	var cp := cos(p3)
	var sp := sin(p3)
	var bx := e.x - ca * cp * D3 - sa * S
	var bz := e.y - sa * cp * D3 + ca * S
	var bh := sp * D3
	var k := 1.0
	for i in 9:
		var hit := false
		var n := ceili(Vector2(bx - e.x, bz - e.y).length() * k / 7.0)
		for s in range(1, n + 1):
			var f := k * s / n
			if blocked_at(e.x + (bx - e.x) * f, e.y + (bz - e.y) * f):
				hit = true
				break
		if not hit:
			break
		k = maxf(.22, k - .12)
	var px := e.x + (bx - e.x) * k
	var pz := e.y + (bz - e.y) * k
	var sk := shake * .25
	var py := maxf(th(px, pz) + 8.0, gy + 24.0 + bh * k)
	cam_pos = Vector3(px + (randf() - .5) * sk, py + (randf() - .5) * sk, pz + (randf() - .5) * sk)
	var L := 300.0
	var tx := e.x + ca * L
	var tz := e.y + sa * L
	var ty := gy - 8.0 + (.3 - p3) * 160.0
	cam_target = Vector3(tx, ty, tz)
	var ux := tx - px
	var uz := tz - pz
	var ul := maxf(.001, sqrt(ux * ux + uz * uz))
	cam_ray["cx"] = px
	cam_ray["cz"] = pz
	cam_ray["cy"] = py
	cam_ray["ty"] = ty
	cam_ray["sy"] = (ty - py) / maxf(.001, Vector2(tx - px, tz - pz).length())
	cam_ray["ux"] = ux / ul
	cam_ray["uz"] = uz / ul
	cam_ray["L"] = L
	cam_ray["ok"] = true
