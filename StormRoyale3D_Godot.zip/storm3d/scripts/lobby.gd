class_name Lobby
extends Control
## Лобби: вкладки, боевой пропуск, задания, гардероб, магазин, карьера, бонус, настройки + 3D-витрина.

signal play_requested(diff_key: String)

const TABS := [["lobby", "ЛОББИ"], ["pass", "БОЕВОЙ ПРОПУСК"], ["quests", "ЗАДАНИЯ"], ["locker", "ГАРДЕРОБ"], ["shop", "МАГАЗИН"], ["career", "КАРЬЕРА"], ["bonus", "БОНУС"]]
const GOLD := Color("#ffb43a")
const PANEL := Color(.05, .09, .16, .86)

# ---------- мелкие контролы ----------
class Bar extends Control:
	var frac := 0.0
	var col := Color("#5fd97a")
	func _draw() -> void:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, .5))
		draw_rect(Rect2(Vector2(1, 1), Vector2((size.x - 2) * clampf(frac, 0, 1), size.y - 2)), col)

class CrIcon extends Control:
	func _draw() -> void:
		var c := size * .5
		var r := minf(size.x, size.y * .83) * .5
		var pts := PackedVector2Array([c + Vector2(0, -r * 1.2), c + Vector2(r * .8, -r * .35), c + Vector2(0, r * 1.2), c + Vector2(-r * .8, -r * .35)])
		draw_colored_polygon(pts, Color("#7fe0ff"))
		draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]]), Color.WHITE, 1.5)
		draw_line(pts[1], pts[3], Color(1, 1, 1, .6), 1.0)

class SkinArt extends Control:
	var skin: Dictionary = {}
	var selected := false
	var unowned := false
	var plain := false
	func _init() -> void:
		clip_contents = true
	func _rr(r: Rect2, c: Color, rad: float) -> void:
		var sb := StyleBoxFlat.new()
		sb.bg_color = c
		sb.set_corner_radius_all(int(rad))
		draw_style_box(sb, r)
	func _half(c: Vector2, r: float, col: Color) -> void:
		var pts := PackedVector2Array()
		for i in 13:
			var a := PI + i / 12.0 * PI
			pts.append(c + Vector2(cos(a), sin(a)) * r)
		draw_colored_polygon(pts, col)
	func _draw() -> void:
		if skin.is_empty():
			return
		var rc: Color = Data.rar_col(Data.RAR_IDS.find(skin["r"]))
		if not plain:
			draw_rect(Rect2(Vector2.ZERO, size), Color("#0b1424"))
			var cc := Vector2(size.x * .5, size.y * .35)
			for i in 8:
				draw_circle(cc, size.x * (.75 - i * .08), Color(rc.r, rc.g, rc.b, .07))
			draw_rect(Rect2(Vector2.ZERO, size), rc, false, 3.0 if selected else 1.5)
		var k := minf(size.x / 60.0, size.y / 80.0) * (.78 if not plain else .95)
		var o := Vector2((size.x - 60 * k) * .5, (size.y - 80 * k) * .5 - (size.y * .04 if not plain else 0.0))
		var R := func(x: float, y: float, w: float, h: float, col: Color, rad: float = 0.0) -> void:
			_rr(Rect2(o + Vector2(x, y) * k, Vector2(w, h) * k), col, rad * k)
		var C := func(x: float, y: float, r: float, col: Color) -> void:
			draw_circle(o + Vector2(x, y) * k, r * k, col)
		var top := Color(skin["top"])
		var acc := Color(skin["acc"])
		var pants := Color(skin["pants"])
		var tone := Color(skin["tone"])
		var hatc := Color(skin["hatc"])
		var hair := Color(skin["hair"])
		R.call(19, 56, 9, 18, pants, 3)
		R.call(32, 56, 9, 18, pants, 3)
		R.call(18, 72, 11, 5, Color("#2a1c14"), 2)
		R.call(31, 72, 11, 5, Color("#2a1c14"), 2)
		R.call(11, 36, 8, 20, top, 4)
		R.call(41, 36, 8, 20, top, 4)
		C.call(15, 57, 3.5, tone)
		C.call(45, 57, 3.5, tone)
		R.call(17, 34, 26, 26, top, 7)
		R.call(17, 53, 26, 4, acc)
		R.call(26, 28, 8, 8, tone)
		C.call(30, 22, 10, tone)
		C.call(26.5, 23, 1.3, Color("#111"))
		C.call(33.5, 23, 1.3, Color("#111"))
		var hs: int = skin["hat"]
		var c0 := o + Vector2(30, 22) * k
		if hs == 0:
			_half(c0, 11 * k, hatc)
			R.call(30, 20, 16, 3, hatc, 1.5)
		elif hs == 1:
			_half(o + Vector2(30, 23) * k, 11 * k, hatc)
			R.call(19, 20, 22, 3.5, acc)
			C.call(30, 10, 3, acc)
		elif hs == 2:
			var pts := PackedVector2Array([Vector2(20, 22), Vector2(22, 10), Vector2(26, 18), Vector2(30, 7), Vector2(34, 18), Vector2(38, 10), Vector2(40, 22)])
			for i in pts.size():
				pts[i] = o + pts[i] * k
			draw_colored_polygon(pts, hair)
		else:
			_half(c0, 11 * k, hatc)
			R.call(22, 20, 24, 3, hatc, 1.5)
		if unowned:
			draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, .5))

class Cell extends Control:
	signal tapped
	var reward: Dictionary = {}
	var done := false
	var can_claim := false
	var locked := false
	var prem := false
	var art: SkinArt = null
	var _pp := Vector2.ZERO
	func _gui_input(ev: InputEvent) -> void:
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
			if ev.pressed:
				_pp = ev.position
			elif ev.position.distance_to(_pp) < 14.0 and can_claim:
				tapped.emit()
	func _draw() -> void:
		var bg := Color(.12, .18, .3, .9) if not prem else Color(.25, .15, .35, .9)
		draw_rect(Rect2(Vector2.ZERO, size), bg)
		var bc := Color(1, 1, 1, .15)
		if can_claim:
			bc = Color("#ffd23c")
		elif done:
			bc = Color("#5fd97a")
		draw_rect(Rect2(Vector2.ZERO, size), bc, false, 3.0 if ready else 1.5)
		if reward.is_empty():
			draw_string(ThemeDB.fallback_font, Vector2(0, size.y * .55), "—", HORIZONTAL_ALIGNMENT_CENTER, size.x, 20, Color(1, 1, 1, .3))
		elif reward["k"] == "cr":
			var ic := PackedVector2Array()
			var c := Vector2(size.x * .5, size.y * .38)
			ic = PackedVector2Array([c + Vector2(0, -16), c + Vector2(13, -5), c + Vector2(0, 18), c + Vector2(-13, -5)])
			draw_colored_polygon(ic, Color("#7fe0ff"))
			draw_polyline(PackedVector2Array([ic[0], ic[1], ic[2], ic[3], ic[0]]), Color.WHITE, 1.5)
			draw_string(ThemeDB.fallback_font, Vector2(0, size.y - 12), str(reward["n"]), HORIZONTAL_ALIGNMENT_CENTER, size.x, 18, Color.WHITE)
		if locked and not done:
			draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, .4))
		if done:
			draw_rect(Rect2(Vector2.ZERO, size), Color(0, .1, 0, .45))
			draw_string(ThemeDB.fallback_font, Vector2(0, size.y * .62), "✓", HORIZONTAL_ALIGNMENT_CENTER, size.x, 34, Color("#5fd97a"))

# ---------- состояние ----------
var tab := "lobby"
var diff_key := "normal"
var sel_id := "ranger"
var body: Control
var top_cr: Label
var tabs_box: HBoxContainer
var toast: Label
var toast_t := 0.0
var modal: Control = null
var cd_labels: Array = []
var cd_t := 0.0
# 3D витрина
var pv: SubViewportContainer
var pv_vp: SubViewport
var pv_group: Node3D
var pv_view: Models.CharView = null
var pv_look: Dictionary = {}
var pv_x := 0.0
var pv_yaw := .5
var pv_t := 0.0
var pv_drag := false
var pv_ring: MeshInstance3D
var pv_glow: MeshInstance3D
var pv_parts: MultiMeshInstance3D
var pv_cam: Camera3D
var pv_seeds: Array = []
var pass_scroll: ScrollContainer = null

func _fit() -> void:
	position = Vector2.ZERO
	size = get_viewport_rect().size

func _ready() -> void:
	get_viewport().size_changed.connect(_fit)
	_fit()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_build_preview()
	_build_frame()
	visible = false

# ---------- помощники ----------
func _sb(col: Color, rad := 10, border := Color(0, 0, 0, 0), bw := 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = col
	s.set_corner_radius_all(rad)
	if bw > 0:
		s.border_color = border
		s.set_border_width_all(bw)
	s.content_margin_left = 12
	s.content_margin_right = 12
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	return s

func _panel(col := PANEL) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", _sb(col, 12, Color(1, 1, 1, .08), 1))
	return p

func _lbl(t: String, size := 18, col := Color.WHITE, align := HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_constant_override("outline_size", 4)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, .6))
	l.horizontal_alignment = align
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _button(t: String, cb: Callable, col := GOLD, minsz := Vector2(0, 46), fs := 18, dark := true) -> Button:
	var b := Button.new()
	b.text = t
	b.custom_minimum_size = minsz
	b.add_theme_font_size_override("font_size", fs)
	var fc := Color("#1a1204") if dark else Color.WHITE
	for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		b.add_theme_color_override(k, fc)
	b.add_theme_stylebox_override("normal", _sb(col, 12))
	b.add_theme_stylebox_override("hover", _sb(col.lightened(.12), 12))
	b.add_theme_stylebox_override("pressed", _sb(col.darkened(.2), 12))
	b.add_theme_stylebox_override("focus", _sb(col, 12))
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(cb)
	return b

func _ghost(t: String, cb: Callable, minsz := Vector2(0, 46), fs := 17) -> Button:
	var b := _button(t, cb, Color(1, 1, 1, .12), minsz, fs, false)
	return b

func _bar(frac: float, col: Color, h := 12.0) -> Bar:
	var b := Bar.new()
	b.frac = frac
	b.col = col
	b.custom_minimum_size = Vector2(0, h)
	return b

func _num(n: float) -> String:
	var s := str(int(round(n)))
	var out := ""
	var c := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		c += 1
		if c % 3 == 0 and i > 0:
			out = " " + out
	return out

func _hms(ms: int) -> String:
	var s := maxi(0, ms / 1000)
	return "%02d:%02d:%02d" % [s / 3600, (s % 3600) / 60, s % 60]

func toast_msg(m: String, bad := false) -> void:
	toast.text = m
	toast.add_theme_color_override("font_color", Color("#ff8a7a") if bad else Color.WHITE)
	toast.visible = true
	toast_t = 2.2

func _clear(n: Node) -> void:
	for c in n.get_children():
		n.remove_child(c)
		c.queue_free()

func _skin_art(s: Dictionary, sz: Vector2, sel := false, unowned := false, plain := false) -> SkinArt:
	var a := SkinArt.new()
	a.skin = s
	a.selected = sel
	a.unowned = unowned
	a.plain = plain
	a.custom_minimum_size = sz
	a.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return a

# ---------- каркас ----------
func _build_frame() -> void:
	var top := PanelContainer.new()
	top.add_theme_stylebox_override("panel", _sb(Color(.03, .05, .1, .92), 0))
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.offset_bottom = 64
	add_child(top)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	top.add_child(hb)
	var logo := _lbl("STORM ", 26, Color.WHITE)
	hb.add_child(logo)
	var logo2 := _lbl("ROYALE", 26, GOLD)
	hb.add_child(logo2)
	var sc := ScrollContainer.new()
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.scroll_deadzone = 12
	hb.add_child(sc)
	tabs_box = HBoxContainer.new()
	tabs_box.add_theme_constant_override("separation", 6)
	sc.add_child(tabs_box)
	top_cr = _lbl("0", 22, Color("#7fe0ff"))
	var ci := CrIcon.new()
	ci.custom_minimum_size = Vector2(22, 26)
	hb.add_child(ci)
	hb.add_child(top_cr)
	hb.add_child(_ghost("⚙", _open_settings, Vector2(48, 44), 22))
	body = Control.new()
	body.set_anchors_preset(Control.PRESET_FULL_RECT)
	body.offset_top = 72
	body.offset_left = 14
	body.offset_right = -14
	body.offset_bottom = -10
	body.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(body)
	toast = _lbl("", 22, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	toast.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	toast.offset_top = -90
	toast.offset_left = -300
	toast.offset_right = 300
	toast.visible = false
	add_child(toast)

func open() -> void:
	visible = true
	sel_id = Prof.p["eq"]
	Prof.ensure_challenges()
	render()
	pv.visible = true

func close() -> void:
	visible = false
	pv.visible = false

func _tab_click(t: String) -> void:
	tab = t
	if t == "locker":
		sel_id = Prof.p["eq"]
	elif t == "shop":
		sel_id = Prof.shop_items()["feat"][0]["id"]
	render()

func render() -> void:
	top_cr.text = _num(Prof.p["cr"])
	_clear(tabs_box)
	var badge := {"pass": Prof.ready_tiers() > 0, "quests": Prof.challenges_ready(), "bonus": Prof.bonus_state()["can"]}
	for t in TABS:
		var on: bool = tab == t[0]
		var b := _button(t[1] + (" •" if badge.get(t[0], false) else ""), _tab_click.bind(t[0]), GOLD if on else Color(1, 1, 1, .1), Vector2(0, 44), 16, on)
		tabs_box.add_child(b)
	_clear(body)
	cd_labels.clear()
	pass_scroll = null
	match tab:
		"lobby": _pg_lobby()
		"pass": _pg_pass()
		"quests": _pg_quests()
		"locker": _pg_skins(false)
		"shop": _pg_skins(true)
		"career": _pg_career()
		"bonus": _pg_bonus()
	var sk: Dictionary = Data.SKIN[Prof.p["eq"] if tab == "lobby" else sel_id]
	set_preview_look(sk)

func _fill(parent: Control, c: Control) -> void:
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	parent.add_child(c)

# ---------- страницы ----------
func _pg_lobby() -> void:
	var p: Dictionary = Prof.p
	var need := Prof.need_xp(p["lvl"])
	var left := VBoxContainer.new()
	left.add_theme_constant_override("separation", 12)
	left.set_anchors_preset(Control.PRESET_LEFT_WIDE)
	left.offset_right = 330
	body.add_child(left)
	var c1 := _panel()
	left.add_child(c1)
	var v1 := VBoxContainer.new()
	v1.add_theme_constant_override("separation", 6)
	c1.add_child(v1)
	v1.add_child(_lbl("СЕЗОН 1", 14, GOLD))
	v1.add_child(_lbl("УРОВЕНЬ %d" % p["lvl"], 26))
	v1.add_child(_bar(float(p["xp"]) / need, Color("#ffb43a"), 14))
	v1.add_child(_lbl("%s / %s XP" % [_num(p["xp"]), _num(need)], 14, Color(1, 1, 1, .7)))
	v1.add_child(_lbl("Боевой пропуск: ур. %d/%d" % [mini(Data.PASS_TIERS, p["lvl"]), Data.PASS_TIERS], 15, Color(1, 1, 1, .8)))
	var c2 := _panel()
	left.add_child(c2)
	var v2 := VBoxContainer.new()
	v2.add_theme_constant_override("separation", 6)
	c2.add_child(v2)
	v2.add_child(_lbl("ЗАДАНИЯ", 14, GOLD))
	var act: Array = []
	for l in [p["ch"]["dl"], p["ch"]["wl"]]:
		for q in l:
			if not q["c"]:
				act.append(q)
	if act.is_empty():
		v2.add_child(_lbl("Все задания выполнены!", 15))
	for i in mini(3, act.size()):
		var q: Dictionary = act[i]
		var d: Dictionary = Prof.CH_BY[q["id"]]
		v2.add_child(_lbl(d["t"], 15))
		v2.add_child(_bar(q["p"] / float(d["g"]), Color("#5fd97a"), 8))
		v2.add_child(_lbl("%d / %d · +%d XP" % [int(q["p"]), d["g"], d["xp"]], 12, Color(1, 1, 1, .6)))
	v2.add_child(_ghost("Все задания", _tab_click.bind("quests"), Vector2(0, 38), 15))
	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 12)
	right.set_anchors_preset(Control.PRESET_RIGHT_WIDE)
	right.offset_left = -340
	body.add_child(right)
	var mp := _panel()
	right.add_child(mp)
	var mv := VBoxContainer.new()
	mv.add_theme_constant_override("separation", 8)
	mp.add_child(mv)
	mv.add_child(_lbl("СОЛО", 24))
	mv.add_child(_lbl("Королевская битва · %d игроков" % (Data.DIFFS[diff_key]["bots"] + 1), 14, Color(1, 1, 1, .7)))
	var seg := HBoxContainer.new()
	seg.add_theme_constant_override("separation", 6)
	mv.add_child(seg)
	for k in ["easy", "normal", "hard"]:
		var on: bool = diff_key == k
		var b := _button(Data.DIFF_NAMES[k], _set_diff.bind(k), GOLD if on else Color(1, 1, 1, .12), Vector2(0, 42), 15, on)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		seg.add_child(b)
	var play := _button("В БОЙ", func(): play_requested.emit(diff_key), Color("#ffc23a"), Vector2(0, 92), 38)
	right.add_child(play)
	var nm := _lbl("Вы · %s" % Data.SKIN[p["eq"]]["n"], 18, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	nm.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	nm.offset_left = -200
	nm.offset_right = 200
	nm.offset_top = -40
	body.add_child(nm)

func _set_diff(k: String) -> void:
	diff_key = k
	render()

func _cell_for(t: int, prem: bool) -> Control:
	var p: Dictionary = Prof.p
	var rw := Prof.pass_reward(t, prem)
	var unlocked: bool = t <= p["lvl"] and t <= Data.PASS_TIERS
	var done: bool = (p["cP"] if prem else p["cF"]).has(t)
	var locked: bool = (not unlocked) or (prem and not p["prem"])
	var cell := Cell.new()
	cell.custom_minimum_size = Vector2(98, 104)
	cell.reward = rw
	cell.done = done
	cell.prem = prem
	cell.locked = locked
	cell.can_claim = (not rw.is_empty()) and unlocked and not done and not (prem and not p["prem"])
	if not rw.is_empty() and rw["k"] == "skin":
		var a := _skin_art(Data.SKIN[rw["id"]], Vector2(98, 104), false, false, false)
		cell.add_child(a)
		a.set_anchors_preset(Control.PRESET_FULL_RECT)
		var l := _lbl(Data.SKIN[rw["id"]]["n"], 12, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
		l.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
		l.offset_top = -20
		cell.add_child(l)
	cell.tapped.connect(_claim_tier.bind(t, prem))
	return cell

func _claim_tier(t: int, prem: bool) -> void:
	if Prof.claim_tier(t, prem):
		var rw := Prof.pass_reward(t, prem)
		toast_msg("+%d кристаллов" % rw["n"] if rw["k"] == "cr" else "Новый скин: " + Data.SKIN[rw["id"]]["n"])
		keep_scroll_render()

func keep_scroll_render() -> void:
	var sx := pass_scroll.scroll_horizontal if pass_scroll else 0
	render()
	if pass_scroll:
		pass_scroll.scroll_horizontal = sx

func _pg_pass() -> void:
	var p: Dictionary = Prof.p
	var t := mini(Data.PASS_TIERS, p["lvl"])
	var rd := Prof.ready_tiers()
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 8)
	_fill(body, col)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	col.add_child(hb)
	var tl := VBoxContainer.new()
	tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(tl)
	tl.add_child(_lbl("БОЕВОЙ ПРОПУСК", 26, GOLD))
	tl.add_child(_lbl("Сезон 1 · Уровень %d из %d · игровой опыт повышает уровень" % [t, Data.PASS_TIERS], 14, Color(1, 1, 1, .7)))
	if p["prem"]:
		hb.add_child(_lbl("ПРОПУСК АКТИВЕН", 18, Color("#5fd97a")))
	else:
		hb.add_child(_button("КУПИТЬ ◆ %d" % Data.PASS_PRICE, _buy_pass, GOLD, Vector2(190, 46)))
	hb.add_child(_ghost("ЗАБРАТЬ ВСЁ" + (" (%d)" % rd if rd > 0 else ""), _claim_all, Vector2(190, 46)))
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.scroll_deadzone = 14
	col.add_child(sc)
	pass_scroll = sc
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	sc.add_child(row)
	var lab := VBoxContainer.new()
	lab.add_theme_constant_override("separation", 6)
	row.add_child(lab)
	var sp0 := Control.new()
	sp0.custom_minimum_size = Vector2(80, 26)
	lab.add_child(sp0)
	var lf := _lbl("БЕСПЛАТНО", 12, Color(1, 1, 1, .7), HORIZONTAL_ALIGNMENT_CENTER)
	lf.custom_minimum_size = Vector2(80, 104)
	lf.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	lab.add_child(lf)
	var lp := _lbl("ПРЕМИУМ", 12, Color("#c58bff"), HORIZONTAL_ALIGNMENT_CENTER)
	lp.custom_minimum_size = Vector2(80, 104)
	lp.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	lab.add_child(lp)
	for i in range(1, Data.PASS_TIERS + 1):
		var c := VBoxContainer.new()
		c.add_theme_constant_override("separation", 6)
		row.add_child(c)
		c.add_child(_lbl(str(i), 16, GOLD if i == t else Color(1, 1, 1, .6), HORIZONTAL_ALIGNMENT_CENTER))
		c.add_child(_cell_for(i, false))
		c.add_child(_cell_for(i, true))
	await get_tree().process_frame
	if is_instance_valid(sc):
		sc.scroll_horizontal = maxi(0, (t - 2) * 104)

func _buy_pass() -> void:
	if Prof.p["prem"]:
		return
	if Prof.p["cr"] < Data.PASS_PRICE:
		toast_msg("Нужно %d кристаллов, у вас %d" % [Data.PASS_PRICE, Prof.p["cr"]], true)
	elif Prof.buy_pass():
		toast_msg("Премиум-пропуск открыт!")
	keep_scroll_render()

func _claim_all() -> void:
	var n := Prof.claim_all_tiers()
	toast_msg("Получено наград: %d" % n if n > 0 else ("Нет доступных наград" if Prof.p["prem"] else "Премиум-награды откроются с пропуском"), n == 0)
	keep_scroll_render()

func _quest_card(a: Dictionary) -> Control:
	var d: Dictionary = Prof.CH_BY[a["id"]]
	var done: bool = a["p"] >= d["g"]
	var pn := _panel(Color(.05, .16, .1, .8) if a["c"] else PANEL)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	pn.add_child(v)
	v.add_child(_lbl(d["t"], 18))
	v.add_child(_bar(minf(1.0, a["p"] / float(d["g"])), Color("#5fd97a"), 10))
	var h := HBoxContainer.new()
	v.add_child(h)
	var l := _lbl("%d / %d" % [int(a["p"]), d["g"]], 14, Color(1, 1, 1, .7))
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(l)
	h.add_child(_lbl("+%d XP  " % d["xp"], 15, GOLD))
	if a["c"]:
		h.add_child(_lbl("ПОЛУЧЕНО", 14, Color("#5fd97a")))
	elif done:
		h.add_child(_button("ЗАБРАТЬ", _claim_q.bind(a["id"]), GOLD, Vector2(110, 38), 15))
	return pn

func _claim_q(id: String) -> void:
	var r := Prof.claim_challenge(id)
	if not r.is_empty():
		toast_msg("Задание выполнено!" + (" Новый уровень: %d" % r["to"] if r["to"] > r["from"] else ""))
	render()

func _cd_label(t: String, kind: String) -> Label:
	var l := _lbl(t, 14, GOLD)
	cd_labels.append({"l": l, "k": kind})
	return l

func _pg_quests() -> void:
	var sc := ScrollContainer.new()
	sc.scroll_deadzone = 14
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_fill(body, sc)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 8)
	sc.add_child(v)
	var two := HBoxContainer.new()
	two.add_theme_constant_override("separation", 16)
	two.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(two)
	for sec in [["ЕЖЕДНЕВНЫЕ", Prof.p["ch"]["dl"], "d"], ["НЕДЕЛЬНЫЕ", Prof.p["ch"]["wl"], "w"]]:
		var c := VBoxContainer.new()
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		c.add_theme_constant_override("separation", 8)
		two.add_child(c)
		var h := HBoxContainer.new()
		c.add_child(h)
		h.add_child(_lbl(sec[0] + "  ", 20, GOLD))
		h.add_child(_lbl("обновятся через ", 13, Color(1, 1, 1, .6)))
		h.add_child(_cd_label("", sec[2]))
		for a in sec[1]:
			c.add_child(_quest_card(a))
	v.add_child(_lbl("Прогресс засчитывается после каждого матча. Опыт повышает уровень и открывает награды боевого пропуска.", 13, Color(1, 1, 1, .5)))
	_refresh_cd()

func _src_hint(s: Dictionary) -> String:
	if s["src"] == "pass":
		for t in Data.PASS_SKINS:
			if Data.PASS_SKINS[t] == s["id"]:
				return "Пропуск · премиум, ур. %d" % t
		for t in Data.FREE_SKINS:
			if Data.FREE_SKINS[t] == s["id"]:
				return "Пропуск · бесплатно, ур. %d" % t
	return "Магазин" if s["src"] == "shop" else "Стартовый"

func _skin_card(s: Dictionary, shop: bool, big := false) -> Control:
	var own: bool = s["id"] in Prof.p["owned"]
	var w := Vector2(170, 200) if big else Vector2(130, 160)
	var c := Control.new()
	c.custom_minimum_size = w
	var a := _skin_art(s, w, sel_id == s["id"], not own)
	a.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.add_child(a)
	var nm := _lbl(s["n"], 14, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	nm.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	nm.offset_top = -40
	c.add_child(nm)
	var sub := ""
	var sc := Color(1, 1, 1, .8)
	if own:
		if Prof.p["eq"] == s["id"]:
			sub = "НАДЕТО"
			sc = Color("#5fd97a")
	elif shop:
		sub = "◆ " + _num(s["p"])
		sc = Color("#7fe0ff")
	else:
		sub = "🔒"
	var sl := _lbl(sub, 13, sc, HORIZONTAL_ALIGNMENT_CENTER)
	sl.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	sl.offset_top = -22
	c.add_child(sl)
	var btn := Button.new()
	btn.flat = true
	btn.focus_mode = Control.FOCUS_NONE
	btn.set_anchors_preset(Control.PRESET_FULL_RECT)
	btn.pressed.connect(_sel_skin.bind(s["id"]))
	c.add_child(btn)
	return c

func _sel_skin(id: String) -> void:
	sel_id = id
	if tab == "locker" and id in Prof.p["owned"]:
		Prof.equip_skin(id)
	var sc: ScrollContainer = body.get_node_or_null("sc")
	var sy := sc.scroll_vertical if sc else 0
	render()
	sc = body.get_node_or_null("sc")
	if sc:
		await get_tree().process_frame
		sc.scroll_vertical = sy

func _pg_skins(shop: bool) -> void:
	var sc := ScrollContainer.new()
	sc.name = "sc"
	sc.scroll_deadzone = 14
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.set_anchors_preset(Control.PRESET_LEFT_WIDE)
	sc.offset_right = 0
	sc.anchor_right = .64
	body.add_child(sc)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(v)
	if shop:
		var it := Prof.shop_items()
		var h := HBoxContainer.new()
		v.add_child(h)
		h.add_child(_lbl("МАГАЗИН  ", 24, GOLD))
		h.add_child(_lbl("обновление через ", 13, Color(1, 1, 1, .6)))
		h.add_child(_cd_label("", "s"))
		v.add_child(_lbl("ИЗБРАННОЕ", 16, Color(1, 1, 1, .7)))
		var g1 := HFlowContainer.new()
		g1.add_theme_constant_override("h_separation", 10)
		g1.add_theme_constant_override("v_separation", 10)
		v.add_child(g1)
		for s in it["feat"]:
			g1.add_child(_skin_card(s, true, true))
		v.add_child(_lbl("СЕГОДНЯ", 16, Color(1, 1, 1, .7)))
		var g2 := HFlowContainer.new()
		g2.add_theme_constant_override("h_separation", 10)
		g2.add_theme_constant_override("v_separation", 10)
		v.add_child(g2)
		for s in it["daily"]:
			g2.add_child(_skin_card(s, true))
		_refresh_cd()
	else:
		v.add_child(_lbl("ГАРДЕРОБ", 24, GOLD))
		var g := HFlowContainer.new()
		g.add_theme_constant_override("h_separation", 10)
		g.add_theme_constant_override("v_separation", 10)
		v.add_child(g)
		for s in Data.SKINS:
			if s["id"] in Prof.p["owned"]:
				g.add_child(_skin_card(s, false))
	# панель деталей
	var s2: Dictionary = Data.SKIN[sel_id]
	var own: bool = sel_id in Prof.p["owned"]
	var det := VBoxContainer.new()
	det.add_theme_constant_override("separation", 8)
	det.set_anchors_preset(Control.PRESET_RIGHT_WIDE)
	det.anchor_left = .7
	det.offset_top = 0
	body.add_child(det)
	var ri: int = Data.RAR_IDS.find(s2["r"])
	det.add_child(_lbl(Data.rar_name(ri).to_upper(), 16, Data.rar_col(ri), HORIZONTAL_ALIGNMENT_CENTER))
	det.add_child(_lbl(s2["n"], 30, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER))
	det.add_child(_lbl("В коллекции" if own else _src_hint(s2), 14, Color(1, 1, 1, .6), HORIZONTAL_ALIGNMENT_CENTER))
	if own:
		if Prof.p["eq"] == sel_id:
			det.add_child(_lbl("НАДЕТО", 20, Color("#5fd97a"), HORIZONTAL_ALIGNMENT_CENTER))
		else:
			det.add_child(_button("НАДЕТЬ", _equip.bind(sel_id), GOLD, Vector2(0, 52)))
	elif s2["src"] == "shop":
		det.add_child(_button("КУПИТЬ ◆ %s" % _num(s2["p"]), _buy.bind(sel_id), Color("#7fe0ff"), Vector2(0, 52)))
	else:
		det.add_child(_ghost(_src_hint(s2), _tab_click.bind("pass"), Vector2(0, 52)))

func _equip(id: String) -> void:
	Prof.equip_skin(id)
	toast_msg("Скин надет: " + Data.SKIN[id]["n"])
	render()

func _buy(id: String) -> void:
	var s: Dictionary = Data.SKIN[id]
	if Prof.p["cr"] < s["p"]:
		toast_msg("Не хватает кристаллов: нужно ещё %d" % (s["p"] - Prof.p["cr"]), true)
	elif Prof.buy_skin(id):
		toast_msg("Куплено: " + s["n"])
	render()

func _pg_career() -> void:
	var s: Dictionary = Prof.p["st"]
	var kd := "%.2f" % (float(s["kills"]) / s["matches"]) if s["matches"] > 0 else "0.00"
	var wr := roundi(float(s["wins"]) / s["matches"] * 100.0) if s["matches"] > 0 else 0
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	_fill(body, v)
	v.add_child(_lbl("КАРЬЕРА · УРОВЕНЬ %d" % Prof.p["lvl"], 24, GOLD))
	var g := GridContainer.new()
	g.columns = 4
	g.add_theme_constant_override("h_separation", 12)
	g.add_theme_constant_override("v_separation", 12)
	v.add_child(g)
	var cells := [[_num(s["matches"]), "Матчей"], [_num(s["wins"]), "Побед"], ["%d%%" % wr, "Процент побед"], [_num(s["kills"]), "Убийств"],
		[kd, "Убийств за матч"], [_num(s["dmg"]), "Урона нанесено"], ["—" if s["best"] >= 99 else "#%d" % s["best"], "Лучшее место"], [_num(s["top10"]), "В топ-10"],
		[_num(s["chests"]), "Сундуков"], [_num(s["builds"]), "Стен построено"], [_num(s["heals"]), "Лечений"], ["%d мин" % int(s["time"] / 60.0), "Время в игре"]]
	for c in cells:
		var p := _panel()
		p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var cv := VBoxContainer.new()
		p.add_child(cv)
		cv.add_child(_lbl(c[0], 30, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER))
		cv.add_child(_lbl(c[1], 14, Color(1, 1, 1, .6), HORIZONTAL_ALIGNMENT_CENTER))
		g.add_child(p)
	v.add_child(_lbl("Статистика хранится на этом устройстве.", 13, Color(1, 1, 1, .5)))

func _pg_bonus() -> void:
	var b := Prof.bonus_state()
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	_fill(body, v)
	v.add_child(_lbl("ЕЖЕДНЕВНЫЙ БОНУС", 24, GOLD))
	v.add_child(_lbl("Заходите каждый день, чтобы получать больше", 14, Color(1, 1, 1, .6)))
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 10)
	v.add_child(h)
	for i in 7:
		var got: bool = (i < int(b["streak"]) % 7) if b["can"] else (i < ((int(b["streak"]) - 1) % 7) + 1)
		var now: bool = b["can"] and i == b["next"]
		var p := _panel(Color(.1, .25, .15, .9) if got else (Color(.3, .22, .05, .95) if now else PANEL))
		p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var cv := VBoxContainer.new()
		cv.alignment = BoxContainer.ALIGNMENT_CENTER
		p.add_child(cv)
		cv.add_child(_lbl("День %d" % (i + 1), 13, Color(1, 1, 1, .7), HORIZONTAL_ALIGNMENT_CENTER))
		var ci := CrIcon.new()
		ci.custom_minimum_size = Vector2(0, 40)
		cv.add_child(ci)
		cv.add_child(_lbl(str(Data.BONUS[i]) + (" ✓" if got else ""), 20, Color("#5fd97a") if got else Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER))
		h.add_child(p)
	if b["can"]:
		v.add_child(_button("ЗАБРАТЬ %d ◆" % Data.BONUS[b["next"]], _claim_bonus, GOLD, Vector2(320, 64), 24))
	else:
		var hh := HBoxContainer.new()
		v.add_child(hh)
		hh.add_child(_lbl("Сегодня бонус уже получен · следующий через ", 16, Color(1, 1, 1, .8)))
		hh.add_child(_cd_label("", "b"))
	v.add_child(_lbl("Кристаллы также выдаются за матчи, задания и награды боевого пропуска.", 13, Color(1, 1, 1, .5)))
	_refresh_cd()

func _claim_bonus() -> void:
	var n := Prof.claim_bonus()
	if n > 0:
		toast_msg("Бонус: +%d кристаллов" % n)
	render()

func _refresh_cd() -> void:
	for c in cd_labels:
		if not is_instance_valid(c["l"]):
			continue
		c["l"].text = ("%d дн." % Prof.until_week_days()) if c["k"] == "w" else _hms(Prof.until_midnight())

# ---------- настройки ----------
func _open_settings() -> void:
	if modal:
		return
	modal = Control.new()
	modal.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(modal)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, .65)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	modal.add_child(dim)
	var pn := _panel(Color(.06, .1, .18, .98))
	pn.set_anchors_preset(Control.PRESET_CENTER)
	pn.custom_minimum_size = Vector2(620, 0)
	pn.offset_left = -310
	pn.offset_right = 310
	pn.offset_top = -250
	pn.offset_bottom = 250
	modal.add_child(pn)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	pn.add_child(v)
	v.add_child(_lbl("Настройки", 28, GOLD))
	var g := HBoxContainer.new()
	g.add_theme_constant_override("separation", 8)
	v.add_child(g)
	g.add_child(_lbl("Графика   ", 18))
	for q in [["low", "Быстрая"], ["mid", "Баланс"], ["high", "Максимум"]]:
		var on: bool = Prof.p.get("gfx", "high") == q[0]
		g.add_child(_button(q[1], _set_gfx.bind(q[0]), GOLD if on else Color(1, 1, 1, .12), Vector2(130, 42), 16, on))
	var sr := HBoxContainer.new()
	sr.add_theme_constant_override("separation", 10)
	v.add_child(sr)
	sr.add_child(_lbl("Чувствительность камеры", 18))
	var sl := HSlider.new()
	sl.min_value = .5
	sl.max_value = 2.0
	sl.step = .05
	sl.value = Prof.p.get("sens", 1.0)
	sl.custom_minimum_size = Vector2(200, 30)
	sl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sr.add_child(sl)
	var sv := _lbl("%.2f" % sl.value, 16, GOLD)
	sr.add_child(sv)
	sl.value_changed.connect(func(x: float): Prof.p["sens"] = x; sv.text = "%.2f" % x; Prof.save_prof())
	var tr := HBoxContainer.new()
	tr.add_theme_constant_override("separation", 8)
	v.add_child(tr)
	var snd := _button("Звук: " + ("вкл" if Prof.p.get("sound", true) else "выкл"), func(): Prof.p["sound"] = not Prof.p.get("sound", true); Prof.save_prof(); _close_modal(); _open_settings(), Color(1, 1, 1, .12), Vector2(0, 42), 16, false)
	var vib := _button("Вибрация: " + ("вкл" if Prof.p.get("vibe", true) else "выкл"), func(): Prof.p["vibe"] = not Prof.p.get("vibe", true); Prof.save_prof(); _close_modal(); _open_settings(), Color(1, 1, 1, .12), Vector2(0, 42), 16, false)
	snd.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vib.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tr.add_child(snd)
	tr.add_child(vib)
	var how := _lbl("Левый палец — бег · правый — камера · ОГОНЬ — стрельба (камеру можно вести тем же пальцем) · ЦЕЛЬ — зум и точность (снайперка точна только через оптику) · Автоогонь стреляет, когда враг в центре прицела · СТЕНА — укрытие перед вами", 14, Color(1, 1, 1, .65))
	how.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	how.custom_minimum_size = Vector2(580, 0)
	v.add_child(how)
	var br := HBoxContainer.new()
	br.add_theme_constant_override("separation", 10)
	v.add_child(br)
	var rst := _ghost("Сбросить прогресс", func(): pass, Vector2(0, 46))
	rst.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var armed := [false]
	rst.pressed.connect(func():
		if not armed[0]:
			armed[0] = true
			rst.text = "Точно сбросить?"
		else:
			Prof.reset_profile()
			_close_modal()
			sel_id = Prof.p["eq"]
			render()
			toast_msg("Прогресс сброшен"))
	br.add_child(rst)
	var done := _button("Готово", _close_modal, GOLD, Vector2(0, 46))
	done.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	br.add_child(done)

func _set_gfx(q: String) -> void:
	Prof.p["gfx"] = q
	Prof.save_prof()
	_close_modal()
	_open_settings()

func _close_modal() -> void:
	if modal:
		modal.queue_free()
		modal = null

# ---------- 3D-витрина ----------
func _build_preview() -> void:
	pv = SubViewportContainer.new()
	pv.stretch = true
	pv.set_anchors_preset(Control.PRESET_FULL_RECT)
	pv.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(pv)
	move_child(pv, 0)
	pv_vp = SubViewport.new()
	pv_vp.own_world_3d = true
	pv_vp.msaa_3d = Viewport.MSAA_4X
	pv_vp.handle_input_locally = false
	pv.add_child(pv_vp)
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color("#06101c")
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("#6f8fc8")
	env.ambient_light_energy = .45
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	pv_vp.add_child(we)
	pv_cam = Camera3D.new()
	pv_cam.fov = 32
	pv_cam.position = Vector3(0, 30, 100)
	pv_vp.add_child(pv_cam)
	pv_cam.look_at(Vector3(0, 22, 0))
	var key := DirectionalLight3D.new()
	key.light_energy = 1.0
	key.rotation_degrees = Vector3(-35, 25, 0)
	key.shadow_enabled = true
	pv_vp.add_child(key)
	var rim := OmniLight3D.new()
	rim.light_color = Color("#4fc3ff")
	rim.omni_range = 300
	rim.light_energy = .8
	rim.position = Vector3(-70, 40, -40)
	pv_vp.add_child(rim)
	var warm := OmniLight3D.new()
	warm.light_color = Color("#ffb43a")
	warm.omni_range = 260
	warm.light_energy = .7
	warm.position = Vector3(60, 12, 50)
	pv_vp.add_child(warm)
	pv_group = Node3D.new()
	pv_vp.add_child(pv_group)
	var pod := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 24
	cm.bottom_radius = 27
	cm.height = 3
	cm.radial_segments = 64
	pod.mesh = cm
	pod.material_override = Mat.std(Color("#101a2a"), .5, .4)
	pod.position.y = -1.5
	pv_group.add_child(pod)
	pv_ring = MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 23.9
	tm.outer_radius = 25.1
	tm.rings = 96
	tm.ring_segments = 10
	pv_ring.mesh = tm
	pv_ring.material_override = Mat.unlit(GOLD)
	pv_ring.position.y = .1
	pv_group.add_child(pv_ring)
	pv_glow = MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(90, 90)
	qm.orientation = PlaneMesh.FACE_Y
	pv_glow.mesh = qm
	pv_glow.material_override = Mat.glow(GOLD, .32)
	pv_glow.position.y = .3
	pv_group.add_child(pv_glow)
	var flo := MeshInstance3D.new()
	var fm := CylinderMesh.new()
	fm.top_radius = 420
	fm.bottom_radius = 420
	fm.height = .5
	flo.mesh = fm
	flo.material_override = Mat.std(Color("#040a12"), .9)
	flo.position.y = -3.2
	# частицы
	var pm := MultiMesh.new()
	pm.transform_format = MultiMesh.TRANSFORM_3D
	var sm := SphereMesh.new()
	sm.radius = .5
	sm.height = 1.0
	sm.radial_segments = 6
	sm.rings = 3
	pm.mesh = sm
	pm.instance_count = 90
	pv_parts = MultiMeshInstance3D.new()
	pv_parts.multimesh = pm
	pv_parts.material_override = Mat.unlit(Color(1, 1, 1, .8), .8)
	pv_vp.add_child(pv_parts)
	for i in 90:
		var a := randf() * TAU
		var r := 15.0 + randf() * 60.0
		pv_seeds.append([Vector3(cos(a) * r, randf() * 80.0, sin(a) * r - 20.0), .6 + randf() * 1.6])

func set_preview_look(sk: Dictionary) -> void:
	if pv_view and pv_look == sk:
		return
	pv_look = sk
	if pv_view:
		pv_view.root.queue_free()
		pv_view = null
	var e := Ent.new()
	e.skin = Color(sk["tone"])
	e.name = ""
	var look := {}
	for k in sk:
		look[k] = sk[k]
	for k in ["top", "acc", "pants", "hair", "hatc", "glide", "tone"]:
		look[k] = Color(sk[k])
	pv_view = Models.make_char(e, look, false)
	pv_view.sh.visible = false
	for m in pv_view.detail:
		m.visibility_range_end = 0.0
	pv_view.chute.visible = false
	pv_view.armR.rotation.z = .16
	pv_view.armL.rotation.z = .16
	pv_group.add_child(pv_view.root)
	var rc: Color = Data.rar_col(Data.RAR_IDS.find(sk["r"]))
	pv_ring.material_override = Mat.unlit(rc)
	pv_glow.material_override = Mat.glow(rc, .32)

func _unhandled_input(ev: InputEvent) -> void:
	if not visible or modal:
		return
	if ev is InputEventScreenTouch or ev is InputEventMouseButton:
		var pos: Vector2 = ev.position
		if (ev is InputEventMouseButton and ev.button_index != MOUSE_BUTTON_LEFT) or ev is InputEventScreenTouch and false:
			return
		pv_drag = ev.pressed and pos.x > size.x * .3 and pos.x < size.x * .7 and tab in ["lobby", "locker", "shop"]
	elif ev is InputEventMouseMotion and pv_drag:
		pv_yaw += ev.relative.x * .012
	elif ev is InputEventScreenDrag and pv_drag:
		pv_yaw += ev.relative.x * .012

func _process(dt: float) -> void:
	if not visible:
		return
	pv_t += dt
	if toast_t > 0.0:
		toast_t -= dt
		if toast_t <= 0.0:
			toast.visible = false
	cd_t -= dt
	if cd_t <= 0.0:
		cd_t = 1.0
		_refresh_cd()
		top_cr.text = _num(Prof.p["cr"])
	var show := tab in ["lobby", "locker", "shop"]
	pv_group.visible = show
	var asp := size.x / maxf(1.0, size.y)
	pv_cam.fov = 32.0 if asp >= 1.0 else 50.0
	var hw := tan(deg_to_rad(pv_cam.fov) * .5) * 100.0 * asp
	var f := -.04 if tab == "lobby" else .64
	pv_x += (f * hw - pv_x) * minf(1.0, dt * 6.0)
	pv_group.position.x = pv_x
	var tsc := 1.0 if tab == "lobby" else .62
	pv_group.scale = pv_group.scale.lerp(Vector3.ONE * tsc, minf(1.0, dt * 8.0))
	if pv_view:
		var v := pv_view
		v.body.rotation.y = -PI / 2 + pv_yaw
		v.body.position.y = sin(pv_t * 2.0) * .25
		v.armR.rotation.z = .16 + sin(pv_t * 2.0) * .03
		v.armL.rotation.z = .16 - sin(pv_t * 2.0) * .03
		if v.fx_spin:
			v.fx_spin.rotation.y = pv_t * 1.6
	if not pv_drag:
		pv_yaw += (.5 - pv_yaw) * minf(1.0, dt * .8)
	var mm := pv_parts.multimesh
	for i in pv_seeds.size():
		var sd: Array = pv_seeds[i]
		var p: Vector3 = sd[0]
		p.y += sd[1] * dt * 6.0
		if p.y > 85.0:
			p.y = 0.0
		sd[0] = p
		mm.set_instance_transform(i, Transform3D(Basis.IDENTITY, p + Vector3(pv_x, 0, 0)))
