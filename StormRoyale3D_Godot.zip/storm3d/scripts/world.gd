class_name World
extends RefCounted
## Логика мира: форма острова, реки, горы, биомы, постройки, коллизии, рельеф.

const W := 7600.0
const H := 7600.0
const CX := 3800.0
const CY := 3800.0
const ISL_R := 3250.0
const RW0 := 26.0
const RG := 260
const RCELL := W / RG
const BG := 120
const CELL := 128.0
const TN := 384
const TMARGIN := 200.0
const TSZ := W + 400.0
const TCELL := TSZ / TN
const EMPTY: Array = []

var islP: Array = [0.0, 0.0, 0.0, 0.0, 0.0]
var TP: Array = [0.0, 0.0, 0.0, 0.0]
var rivGrid := PackedFloat32Array()
var mounts: Array = []
var towns: Array = []
var rects: Array = []
var trees: Array = []
var floors: Array = []
var chests: Array = []
var loot: Array = []
var cacti: Array = []
var bgId := PackedByteArray()
var bgHill := PackedFloat32Array()
var bgSnow := PackedFloat32Array()
var bgDesert := PackedFloat32Array()
var rgrid := {}
var tgrid := {}
var hgrid := PackedFloat32Array()
var crows: Array = []
var _hrows: Array = []
var _mtx := Mutex.new()
var _bc: Array = []

func _init() -> void:
	rivGrid.resize(RG * RG)
	rivGrid.fill(300.0)
	for b in Data.BIOMES:
		_bc.append([b["g1"], b["g2"], b["dk"]])
	_build_biome_grid()

# ---------- утилиты ----------
static func rnd(a: float, b: float) -> float:
	return randf_range(a, b)

static func irnd(a: int, b: int) -> int:
	return randi_range(a, b)

static func fr(f: float) -> float:
	return .5 + (f - .5) * .8

func biome_weights(x: float, y: float, out: PackedFloat32Array) -> void:
	var sum := 0.0
	for i in 5:
		var b: Dictionary = Data.BIOMES[i]
		var dx: float = x - fr(b["fx"]) * W
		var dy: float = y - fr(b["fy"]) * H
		var sg: float = b["s"] * W * .8
		var w := exp(-(dx * dx + dy * dy) / (2.0 * sg * sg))
		out[i] = w
		sum += w
	if sum == 0.0:
		sum = 1.0
	for i in 5:
		out[i] /= sum

func _build_biome_grid() -> void:
	bgId.resize(BG * BG)
	bgHill.resize(BG * BG)
	bgSnow.resize(BG * BG)
	bgDesert.resize(BG * BG)
	var w := PackedFloat32Array([0, 0, 0, 0, 0])
	for j in BG:
		for i in BG:
			biome_weights((i + .5) / BG * W, (j + .5) / BG * H, w)
			var best := 0
			var hm := 0.0
			for k in 5:
				if w[k] > w[best]:
					best = k
				hm += w[k] * float(Data.BIOMES[k]["hill"])
			var id := j * BG + i
			bgId[id] = best
			bgHill[id] = hm
			bgSnow[id] = w[2]
			bgDesert[id] = w[1]

func grid_at(arr: PackedFloat32Array, x: float, y: float) -> float:
	var gx := clampf(x / W * BG - .5, 0.0, BG - 1.001)
	var gy := clampf(y / W * BG - .5, 0.0, BG - 1.001)
	var i := int(gx)
	var j := int(gy)
	var fx := gx - i
	var fy := gy - j
	var a := arr[j * BG + i]
	var b := arr[j * BG + i + 1]
	var c := arr[(j + 1) * BG + i]
	var d := arr[(j + 1) * BG + i + 1]
	return (a + (b - a) * fx) * (1.0 - fy) + (c + (d - c) * fx) * fy

func biome_at(x: float, y: float) -> int:
	return bgId[clampi(int(y / H * BG), 0, BG - 1) * BG + clampi(int(x / W * BG), 0, BG - 1)]

# ---------- остров, реки ----------
func land_val(x: float, y: float) -> float:
	var dx := x - CX
	var dy := y - CY
	var d := sqrt(dx * dx + dy * dy)
	var a := atan2(dy, dx)
	var R: float = ISL_R * (1.0 + .09 * sin(a * 2.0 + islP[0]) + .07 * sin(a * 3.0 + islP[1]) + .05 * sin(a * 5.0 + islP[2]) + .035 * sin(a * 8.0 + islP[3]))
	return R - d + 60.0 * sin(x * .004 + islP[4]) * cos(y * .0037 + islP[0])

func river_d(x: float, y: float) -> float:
	var gx := clampf(x / RCELL - .5, 0.0, RG - 1.001)
	var gy := clampf(y / RCELL - .5, 0.0, RG - 1.001)
	var i := int(gx)
	var j := int(gy)
	var fx := gx - i
	var fy := gy - j
	var a := rivGrid[j * RG + i]
	var b := rivGrid[j * RG + i + 1]
	var c := rivGrid[(j + 1) * RG + i]
	var d := rivGrid[(j + 1) * RG + i + 1]
	return (a + (b - a) * fx) * (1.0 - fy) + (c + (d - c) * fx) * fy

func site_ok(x: float, y: float, m: float = 0.0) -> bool:
	return land_val(x, y) > 160.0 + m and river_d(x, y) > RW0 + 26.0 + m * .3

func riv_seg_add(x1: float, y1: float, x2: float, y2: float, hw: float) -> void:
	var pad := RW0 + 110.0 + hw
	var i0 := maxi(0, int(floor((minf(x1, x2) - pad) / RCELL)))
	var i1 := mini(RG - 1, int(ceil((maxf(x1, x2) + pad) / RCELL)))
	var j0 := maxi(0, int(floor((minf(y1, y2) - pad) / RCELL)))
	var j1 := mini(RG - 1, int(ceil((maxf(y1, y2) + pad) / RCELL)))
	var vx := x2 - x1
	var vy := y2 - y1
	var l2 := vx * vx + vy * vy
	if l2 == 0.0:
		l2 = 1.0
	for j in range(j0, j1 + 1):
		for i in range(i0, i1 + 1):
			var px := (i + .5) * RCELL
			var py := (j + .5) * RCELL
			var t := clampf(((px - x1) * vx + (py - y1) * vy) / l2, 0.0, 1.0)
			var d := Vector2(px - x1 - vx * t, py - y1 - vy * t).length() - (hw - RW0)
			if d < rivGrid[j * RG + i]:
				rivGrid[j * RG + i] = d

func _fits(x: float, y: float, m: float) -> bool:
	if land_val(x, y) <= 400.0:
		return false
	for t in towns:
		if Vector2(t.x - x, t.y - y).length() <= m:
			return false
	return true

func gen_world_shape() -> void:
	islP = [rnd(0, TAU), rnd(0, TAU), rnd(0, TAU), rnd(0, TAU), rnd(0, TAU)]
	TP = [rnd(0, TAU), rnd(0, TAU), rnd(0, TAU), rnd(0, TAU)]
	rivGrid.fill(300.0)
	mounts = []
	for t in towns:
		for k in 60:
			if land_val(t.x, t.y) >= 520.0:
				break
			t.x += (CX - t.x) * .04
			t.y += (CY - t.y) * .04
	var tries := 0
	while tries < 400 and mounts.size() < 8:
		tries += 1
		var x := rnd(500, W - 500)
		var y := rnd(500, H - 500)
		if not _fits(x, y, 700.0) or land_val(x, y) < 650.0:
			continue
		var close := false
		for m in mounts:
			if Vector2(m["x"] - x, m["y"] - y).length() < 1000.0:
				close = true
				break
		if close:
			continue
		mounts.append({"x": x, "y": y, "r": rnd(380, 640), "h": rnd(120, 230), "ph": rnd(0, TAU)})
	var made := 0
	var at := 0
	while at < 60 and made < 5:
		at += 1
		var m = mounts[made % maxi(1, mounts.size())] if mounts.size() > 0 else null
		var sx: float = m["x"] if m else CX
		var sy: float = m["y"] if m else CY
		var a0 := atan2(sy - CY, sx - CX) + rnd(-.8, .8)
		if m == null:
			a0 = rnd(0, TAU)
		var x: float = sx + cos(a0) * (m["r"] * .45 if m else 0.0)
		var y: float = sy + sin(a0) * (m["r"] * .45 if m else 0.0)
		var ph := rnd(0, TAU)
		var ph2 := rnd(0, TAU)
		var amp := rnd(.5, .9)
		var pts: Array = [Vector2(x, y)]
		for i in 140:
			var hd := a0 + sin(i * .17 + ph) * amp + sin(i * .06 + ph2) * .5
			x += cos(hd) * 70.0
			y += sin(hd) * 70.0
			pts.append(Vector2(x, y))
			if land_val(x, y) < -40.0:
				break
		if land_val(x, y) > -40.0 or pts.size() < 25:
			continue
		var bad := false
		for p in pts:
			for t in towns:
				if Vector2(t.x - p.x, t.y - p.y).length() < 230.0:
					bad = true
					break
			if bad:
				break
		if bad:
			continue
		for i in range(1, pts.size()):
			riv_seg_add(pts[i - 1].x, pts[i - 1].y, pts[i].x, pts[i].y, minf(44.0, RW0 - 4.0 + i * .22))
		if made < 3:
			var p0: Vector2 = pts[0]
			var lr := rnd(120, 190)
			for q in 14:
				var aa := q / 14.0 * TAU
				var bb := (q + 1) / 14.0 * TAU
				riv_seg_add(p0.x + cos(aa) * lr * .5, p0.y + sin(aa) * lr * .5, p0.x + cos(bb) * lr * .5, p0.y + sin(bb) * lr * .5, lr * .6 + RW0 * .4)
		made += 1

# ---------- пространственная сетка ----------
func _cells(x0: float, y0: float, x1: float, y1: float) -> Array:
	var out := []
	var i0 := clampi(int(floor(x0 / CELL)), 0, 59)
	var i1 := clampi(int(floor(x1 / CELL)), 0, 59)
	var j0 := clampi(int(floor(y0 / CELL)), 0, 59)
	var j1 := clampi(int(floor(y1 / CELL)), 0, 59)
	for j in range(j0, j1 + 1):
		for i in range(i0, i1 + 1):
			out.append(j * 64 + i)
	return out

func add_rect(rc: Types.Rc) -> void:
	rects.append(rc)
	for k in _cells(rc.x, rc.y, rc.x + rc.w, rc.y + rc.h):
		if not rgrid.has(k):
			rgrid[k] = []
		rgrid[k].append(rc)

func remove_rect(rc: Types.Rc) -> void:
	rc.gone = true
	rects.erase(rc)
	for k in _cells(rc.x, rc.y, rc.x + rc.w, rc.y + rc.h):
		if rgrid.has(k):
			rgrid[k].erase(rc)

func rects_at(x: float, y: float) -> Array:
	return rgrid.get(clampi(int(y / CELL), 0, 59) * 64 + clampi(int(x / CELL), 0, 59), EMPTY)

func rects_near(x: float, y: float, r: float) -> Array:
	var i0 := clampi(int(floor((x - r) / CELL)), 0, 59)
	var i1 := clampi(int(floor((x + r) / CELL)), 0, 59)
	var j0 := clampi(int(floor((y - r) / CELL)), 0, 59)
	var j1 := clampi(int(floor((y + r) / CELL)), 0, 59)
	if i0 == i1 and j0 == j1:
		return rgrid.get(j0 * 64 + i0, EMPTY)
	var out := []
	for j in range(j0, j1 + 1):
		for i in range(i0, i1 + 1):
			out.append_array(rgrid.get(j * 64 + i, EMPTY))
	return out

func trees_near(x: float, y: float, r: float) -> Array:
	var i0 := clampi(int(floor((x - r) / CELL)), 0, 59)
	var i1 := clampi(int(floor((x + r) / CELL)), 0, 59)
	var j0 := clampi(int(floor((y - r) / CELL)), 0, 59)
	var j1 := clampi(int(floor((y + r) / CELL)), 0, 59)
	if i0 == i1 and j0 == j1:
		return tgrid.get(j0 * 64 + i0, EMPTY)
	var out := []
	for j in range(j0, j1 + 1):
		for i in range(i0, i1 + 1):
			out.append_array(tgrid.get(j * 64 + i, EMPTY))
	return out

func _build_tree_grid() -> void:
	tgrid.clear()
	for t in trees:
		for k in _cells(t.x - 40, t.y - 40, t.x + 40, t.y + 40):
			if not tgrid.has(k):
				tgrid[k] = []
			tgrid[k].append(t)

static func circle_hits_rect(x: float, y: float, r: float, rc: Types.Rc) -> bool:
	var nx := clampf(x, rc.x, rc.x + rc.w)
	var ny := clampf(y, rc.y, rc.y + rc.h)
	var dx := x - nx
	var dy := y - ny
	return dx * dx + dy * dy < r * r

func overlaps_floor(x: float, y: float, w: float, h: float) -> bool:
	for f in floors:
		if x < f.x + f.w and x + w > f.x and y < f.y + f.h and y + h > f.y:
			return true
	return false

func is_free(x: float, y: float, r: float) -> bool:
	if x < r or y < r or x > W - r or y > H - r:
		return false
	if land_val(x, y) < 90.0 or river_d(x, y) < RW0 + 8.0:
		return false
	for rc in rects_near(x, y, r + 4.0):
		if circle_hits_rect(x, y, r, rc):
			return false
	for t in trees_near(x, y, r + 40.0):
		var rr: float = r + t.tr
		if (x - t.x) * (x - t.x) + (y - t.y) * (y - t.y) < rr * rr:
			return false
	return true

func free_pos(r: float) -> Vector2:
	for i in 160:
		var x := rnd(60, W - 60)
		var y := rnd(60, H - 60)
		if is_free(x, y, r):
			return Vector2(x, y)
	return Vector2(CX, CY)

func free_near(cx: float, cy: float, rad: float, r: float) -> Vector2:
	for i in 60:
		var x := cx + rnd(-rad, rad)
		var y := cy + rnd(-rad, rad)
		if is_free(x, y, r):
			return Vector2(x, y)
	return free_pos(r)

func collide(e: Ent) -> void:
	for rc in rects_near(e.x, e.y, e.r + 2.0):
		if e.x < rc.x - e.r - 2.0 or e.x > rc.x + rc.w + e.r + 2.0 or e.y < rc.y - e.r - 2.0 or e.y > rc.y + rc.h + e.r + 2.0:
			continue
		_push_out_rect(e, rc)
	for t in trees_near(e.x, e.y, e.r + 40.0):
		var dx: float = e.x - t.x
		var dy: float = e.y - t.y
		if dx > 40.0 or dx < -40.0 or dy > 40.0 or dy < -40.0:
			continue
		var rr: float = e.r + t.tr
		var d2 := dx * dx + dy * dy
		if d2 < rr * rr:
			var d := sqrt(d2)
			if d == 0.0:
				d = 1.0
			var p := rr - d
			e.x += dx / d * p
			e.y += dy / d * p
	e.x = clampf(e.x, e.r, W - e.r)
	e.y = clampf(e.y, e.r, H - e.r)
	for k in 4:
		var L := land_val(e.x, e.y)
		if L >= 30.0:
			break
		var dx2 := CX - e.x
		var dy2 := CY - e.y
		var d3 := maxf(0.0001, sqrt(dx2 * dx2 + dy2 * dy2))
		e.x += dx2 / d3 * (31.0 - L)
		e.y += dy2 / d3 * (31.0 - L)
	e.wet = river_d(e.x, e.y) < RW0 + 6.0

func _push_out_rect(e: Ent, rc: Types.Rc) -> bool:
	var nx := clampf(e.x, rc.x, rc.x + rc.w)
	var ny := clampf(e.y, rc.y, rc.y + rc.h)
	var dx := e.x - nx
	var dy := e.y - ny
	var d2 := dx * dx + dy * dy
	if d2 >= e.r * e.r:
		return false
	if d2 > 0.0001:
		var d := sqrt(d2)
		var p := e.r - d
		e.x += dx / d * p
		e.y += dy / d * p
	else:
		var l := e.x - rc.x
		var rr := rc.x + rc.w - e.x
		var t := e.y - rc.y
		var b := rc.y + rc.h - e.y
		var m := minf(minf(l, rr), minf(t, b))
		if m == l:
			e.x = rc.x - e.r
		elif m == rr:
			e.x = rc.x + rc.w + e.r
		elif m == t:
			e.y = rc.y - e.r
		else:
			e.y = rc.y + rc.h + e.r
	return true

func los(ax: float, ay: float, bx: float, by: float) -> bool:
	var dx := bx - ax
	var dy := by - ay
	var d := sqrt(dx * dx + dy * dy)
	var n := int(ceil(d / 14.0))
	for i in range(1, n):
		var x := ax + dx * i / n
		var y := ay + dy * i / n
		for rc in rects_at(x, y):
			if x >= rc.x and x <= rc.x + rc.w and y >= rc.y and y <= rc.y + rc.h:
				return false
	return true

# ---------- лут ----------
static func pick_weapon(boost: bool) -> String:
	var r := randf()
	if boost:
		return "sniper" if r < .16 else ("rifle" if r < .42 else ("shotgun" if r < .68 else ("smg" if r < .9 else "pistol")))
	return "sniper" if r < .04 else ("rifle" if r < .2 else ("shotgun" if r < .4 else ("smg" if r < .7 else "pistol")))

static func roll_rar(boost: bool) -> int:
	var r := randf() - (.12 if boost else 0.0)
	return 0 if r < .5 else (1 if r < .78 else (2 if r < .92 else (3 if r < .98 else 4)))

func roll_loot(x: float, y: float, boost: bool) -> void:
	var it := Types.Item.new()
	it.x = x
	it.y = y
	var r := randf()
	if r < .5:
		it.k = "w"
		it.w = pick_weapon(boost)
		it.rar = roll_rar(boost)
	elif r < .65:
		it.k = "med"
	elif r < .8:
		it.k = "pot"
	elif r < .9:
		it.k = "mats"
	else:
		it.k = "ammo"
	loot.append(it)

func add_building(x: float, y: float, w: float, h: float, bi: int) -> void:
	var bt := irnd(0, 3)
	var f := Types.Flr.new()
	f.x = x; f.y = y; f.w = w; f.h = h; f.bt = bt; f.bi = bi
	floors.append(f)
	var t := 12.0
	var g := 27.0
	var door := irnd(0, 3)
	var seg := func(x1: float, y1: float, x2: float, y2: float) -> void:
		var rc := Types.Rc.new()
		rc.x = x1; rc.y = y1; rc.w = x2 - x1; rc.h = y2 - y1; rc.type = "wall"; rc.bt = bt; rc.bi = bi
		add_rect(rc)
	if door == 0:
		seg.call(x, y, x + w / 2 - g, y + t)
		seg.call(x + w / 2 + g, y, x + w, y + t)
	else:
		seg.call(x, y, x + w, y + t)
	if door == 2:
		seg.call(x, y + h - t, x + w / 2 - g, y + h)
		seg.call(x + w / 2 + g, y + h - t, x + w, y + h)
	else:
		seg.call(x, y + h - t, x + w, y + h)
	if door == 3:
		seg.call(x, y + t, x + t, y + h / 2 - g)
		seg.call(x, y + h / 2 + g, x + t, y + h - t)
	else:
		seg.call(x, y + t, x + t, y + h - t)
	if door == 1:
		seg.call(x + w - t, y + t, x + w, y + h / 2 - g)
		seg.call(x + w - t, y + h / 2 + g, x + w, y + h - t)
	else:
		seg.call(x + w - t, y + t, x + w, y + h - t)
	var c := Types.Chest.new()
	c.x = x + rnd(34, w - 34)
	c.y = y + rnd(34, h - 34)
	chests.append(c)
	for i in irnd(1, 2):
		roll_loot(x + rnd(26, w - 26), y + rnd(26, h - 26), true)

func gen_map() -> void:
	rects = []; trees = []; floors = []; loot = []; towns = []; chests = []; cacti = []
	rgrid.clear(); tgrid.clear()
	for p in Data.POIS:
		var t := Types.Town.new()
		t.bi = Data.BIOME_IDX[p[1]]
		t.x = fr(p[2]) * W + rnd(-70, 70)
		t.y = fr(p[3]) * H + rnd(-70, 70)
		t.name = p[0]
		t.big = p[4] == 1
		towns.append(t)
	gen_world_shape()
	for t in towns:
		var n := irnd(9, 12) if t.big else irnd(4, 7)
		var sp := 1.5 if t.big else 1.0
		var k := 0
		var tr := 0
		while k < n and tr < 160:
			tr += 1
			var w := float(irnd(110, 190))
			var h := float(irnd(100, 150))
			var x: float = t.x + rnd(-230, 230) * sp - w / 2
			var y: float = t.y + rnd(-200, 200) * sp - h / 2
			if overlaps_floor(x - 36, y - 36, w + 72, h + 72):
				continue
			if not site_ok(x, y) or not site_ok(x + w, y + h) or not site_ok(x + w, y) or not site_ok(x, y + h):
				continue
			add_building(x, y, w, h, t.bi)
			k += 1
	var nr := 0
	var i := 0
	while i < 700 and nr < 120:
		i += 1
		var w := rnd(36, 80)
		var h := rnd(36, 80)
		var x := rnd(40, W - 120)
		var y := rnd(40, H - 120)
		if overlaps_floor(x - 24, y - 24, w + 48, h + 48) or not site_ok(x, y, 40) or not site_ok(x + w, y + h, 40):
			continue
		var rc := Types.Rc.new()
		rc.x = x; rc.y = y; rc.w = w; rc.h = h; rc.type = "rock"; rc.hh = rnd(24, 54); rc.bi = biome_at(x, y)
		add_rect(rc)
		nr += 1
	for q in 24:
		var cx := rnd(300, W - 300)
		var cy := rnd(300, H - 300)
		var dens := 22 if biome_at(cx, cy) == 3 else 10
		for j in dens:
			_add_tree(cx + rnd(-190, 190), cy + rnd(-190, 190))
	for q in 330:
		_add_tree(rnd(0, W), rnd(0, H))
	for q in 1100:
		var x := rnd(60, W - 60)
		var y := rnd(60, H - 60)
		if biome_at(x, y) == 1 and site_ok(x, y, 20) and not overlaps_floor(x - 20, y - 20, 40, 40):
			cacti.append(Vector3(x, y, rnd(.8, 1.5)))
	trees = trees.filter(func(t):
		for rc in rects:
			if circle_hits_rect(t.x, t.y, t.tr + 4.0, rc):
				return false
		return true)
	_build_tree_grid()
	for q in 230:
		var p := free_pos(14)
		roll_loot(p.x, p.y, false)

func _add_tree(x: float, y: float) -> void:
	if x < 30 or y < 30 or x > W - 30 or y > H - 30:
		return
	if not site_ok(x, y, 10) or overlaps_floor(x - 34, y - 34, 68, 68):
		return
	var b := biome_at(x, y)
	if b == 1 and randf() < .9:
		return
	var t := Types.Tr.new()
	t.x = x; t.y = y; t.r = rnd(20, 31); t.tr = 10.0; t.b = b
	trees.append(t)

# ---------- рельеф ----------
func hills_at(x: float, y: float) -> float:
	return 15.0 * sin(x * .0042 + TP[0]) * cos(y * .0036 + TP[1]) + 10.0 * sin((x + y) * .0068 + TP[2]) + 6.0 * cos(x * .0105 - y * .0092 + TP[3]) + 3.0 * sin(x * .021 + y * .017 + TP[0])

func terrain_h_raw(x: float, y: float) -> float:
	var e := land_val(x, y)
	var shore: float
	if e >= 0.0:
		shore = -1.0 + smoothstep(0.0, 140.0, e) * 1.2
	else:
		shore = maxf(-42.0, -1.0 + (e / 150.0) * 10.0)
	if e < -60.0:
		return shore
	var tm := 1.0
	for t in towns:
		var m := smoothstep(460.0, 720.0, sqrt((x - t.x) * (x - t.x) + (y - t.y) * (y - t.y)))
		if m < tm:
			tm = m
	var hm := grid_at(bgHill, x, y)
	var sn := grid_at(bgSnow, x, y)
	var de := grid_at(bgDesert, x, y)
	var h := maxf(0.0, hills_at(x, y) + 4.0) * .8 * hm
	h += 14.0 * maxf(0.0, sin(x * .0021 + TP[2]) * sin(y * .0019 + TP[0] * 3.0) + .1) * hm
	h += sn * 42.0 * maxf(0.0, sin(x * .0055 + TP[0] * 2.0) * cos(y * .0049 + TP[1]) + .15)
	h += de * (5.0 * sin((x * .8 + y * .6) * .016 + TP[2]) + 3.0 * sin(x * .03 - y * .021))
	for m in mounts:
		var dx: float = x - m["x"]
		var dy: float = y - m["y"]
		var dd: float = (dx * dx + dy * dy) / (m["r"] * m["r"])
		if dd > 6.0:
			continue
		var an := atan2(dy, dx)
		var rid: float = .72 + .28 * absf(sin(an * 3.0 + m["ph"])) + .12 * sin(an * 7.0 + m["ph"] * 2.0) * minf(1.0, dd)
		h += m["h"] * exp(-dd * 1.5) * rid * (.85 + .15 * sin(x * .02 + y * .017))
	var v := shore + h * smoothstep(40.0, 300.0, e) * tm
	var rd := river_d(x, y)
	if rd < RW0 + 56.0:
		var k := smoothstep(RW0 + 52.0, RW0 - 18.0, rd)
		v += (-10.0 - v) * k
	return v

func terrain_color(x: float, z: float, h: float, w: PackedFloat32Array) -> Color:
	var n := .5 + .5 * sin(x * .013 + TP[1]) * cos(z * .011 + TP[2])
	var n2 := .5 + .5 * sin(x * .05 + z * .041)
	var n3 := .5 + .5 * sin(x * .17 + TP[0]) * sin(z * .19 + TP[3])
	biome_weights(x, z, w)
	var r := 0.0
	var g := 0.0
	var b := 0.0
	var base_t := minf(1.0, smoothstep(0.0, 16.0, h) * .5 + n * .5)
	var dark_t := smoothstep(.6, .9, n2 * n) * .5
	for k in 5:
		var bc: Array = _bc[k]
		var c2: Color = (bc[0] as Color).lerp(bc[1], base_t).lerp(bc[2], dark_t)
		r += c2.r * w[k]; g += c2.g * w[k]; b += c2.b * w[k]
	var mul := .93 + n3 * .14
	var c := Color(r * mul, g * mul, b * mul)
	var cd := land_val(x, z)
	var rdv := river_d(x, z)
	var beach := smoothstep(110.0, 12.0, cd)
	c = c.lerp(Color("#ecdca6"), beach * (1.0 - w[1] * .6)).lerp(Color("#c9b78a"), smoothstep(-1.2, -4.0, h) * .9)
	c = c.lerp(Color("#9c8a62"), smoothstep(RW0 + 46.0, RW0 + 6.0, rdv) * .75).lerp(Color("#6e7f78"), smoothstep(RW0 + 6.0, RW0 - 14.0, rdv))
	if h > 14.0 and w[2] > .25:
		c = c.lerp(Color("#aab6c4"), smoothstep(14.0, 40.0, h) * .5 * w[2])
	elif h > 22.0:
		c = c.lerp(Color("#8d8f94"), smoothstep(22.0, 48.0, h) * .45)
	if h > 55.0:
		c = c.lerp(Color("#8d8f94"), smoothstep(55.0, 105.0, h) * .8)
	if h > 100.0:
		c = c.lerp(Color("#f4f8fc"), smoothstep(100.0, 140.0, h) * .95)
	for t in towns:
		var d := sqrt((x - t.x) * (x - t.x) + (z - t.y) * (z - t.y))
		if d < 230.0:
			c = c.lerp(Color("#9b8a6a"), smoothstep(230.0, 90.0, d) * .55)
	return c.srgb_to_linear()

func _fill_row(j: int) -> void:
	var hr := PackedFloat32Array()
	hr.resize(TN + 1)
	var cr := PackedColorArray()
	cr.resize(TN + 1)
	var w := PackedFloat32Array([0, 0, 0, 0, 0])
	var z := -TMARGIN + j * TCELL
	for i in TN + 1:
		var x := -TMARGIN + i * TCELL
		var h := terrain_h_raw(x, z)
		hr[i] = h
		if h > -9.0:
			cr[i] = terrain_color(x, z, h, w)
		else:
			cr[i] = Color(.05, .1, .12)
	_mtx.lock()
	_hrows[j] = hr
	crows[j] = cr
	_mtx.unlock()

func start_height_job() -> int:
	_hrows = []
	crows = []
	_hrows.resize(TN + 1)
	crows.resize(TN + 1)
	return WorkerThreadPool.add_group_task(_fill_row, TN + 1, -1, true, "terrain")

func finish_height_job(gid: int) -> void:
	WorkerThreadPool.wait_for_group_task_completion(gid)
	hgrid.resize((TN + 1) * (TN + 1))
	for j in TN + 1:
		var hr: PackedFloat32Array = _hrows[j]
		for i in TN + 1:
			hgrid[j * (TN + 1) + i] = hr[i]
	_hrows = []

func th(x: float, y: float) -> float:
	var gx := clampf((x + TMARGIN) / TCELL, 0.0, TN - 0.001)
	var gy := clampf((y + TMARGIN) / TCELL, 0.0, TN - 0.001)
	var i := int(gx)
	var j := int(gy)
	var fx := gx - i
	var fy := gy - j
	var k := j * (TN + 1) + i
	var a := hgrid[k]
	var b := hgrid[k + 1]
	var c := hgrid[k + TN + 1]
	var d := hgrid[k + TN + 2]
	return (a + (b - a) * fx) * (1.0 - fy) + (c + (d - c) * fx) * fy

func h_vertex(i: int, j: int) -> float:
	return hgrid[clampi(j, 0, TN) * (TN + 1) + clampi(i, 0, TN)]

func nearest_town_name(x: float, y: float) -> String:
	for t in towns:
		if Vector2(x - t.x, y - t.y).length() < 300.0:
			return t.name
	return ""

## Карта значения land_val для шейдера воды: диапазон [-1000, W+1000]
func land_image(n: int) -> Image:
	var img := Image.create(n, n, false, Image.FORMAT_RH)
	var span := W + 2000.0
	for j in n:
		for i in n:
			var x := -1000.0 + (i + .5) / n * span
			var y := -1000.0 + (j + .5) / n * span
			img.set_pixel(i, j, Color(clampf(land_val(x, y) / 1000.0, -1.5, 1.5), 0, 0))
	return img

## Мини-карта: цвет по биому, высоте и воде
func minimap_image(n: int) -> Image:
	var img := Image.create(n, n, false, Image.FORMAT_RGB8)
	var w := PackedFloat32Array([0, 0, 0, 0, 0])
	var rgb := []
	for b in Data.BIOMES:
		rgb.append(b["g1"])
	for j in n:
		for i in n:
			var x := (i + .5) / n * W
			var y := (j + .5) / n * H
			var h := th(x, y)
			var L := land_val(x, y)
			var r: float
			var g: float
			var b: float
			if h < -5.5:
				var dp := clampf(-L / 500.0, 0.0, 1.0)
				r = (40 - dp * 22) / 255.0; g = (130 - dp * 50) / 255.0; b = (190 - dp * 40) / 255.0
				if L > -150 and L <= 0:
					r += .16; g += .16; b += .08
			else:
				biome_weights(x, y, w)
				r = 0.0; g = 0.0; b = 0.0
				for k in 5:
					var c: Color = rgb[k]
					r += c.r * w[k]; g += c.g * w[k]; b += c.b * w[k]
				var sh := .86 + clampf((h - 6.0) / 160.0, -.1, .3)
				r *= sh; g *= sh; b *= sh
				if L < 90.0:
					var t := 1.0 - L / 90.0
					r += (.925 - r) * t * .8; g += (.863 - g) * t * .8; b += (.65 - b) * t * .8
				if h > 60.0:
					var t2 := minf(1.0, (h - 60.0) / 70.0)
					r += (.59 - r) * t2; g += (.59 - g) * t2; b += (.6 - b) * t2
				if h > 105.0:
					var t3 := minf(1.0, (h - 105.0) / 40.0)
					r += (.96 - r) * t3; g += (.97 - g) * t3; b += (.99 - b) * t3
			img.set_pixel(i, j, Color(clampf(r, 0, 1), clampf(g, 0, 1), clampf(b, 0, 1)))
	return img
