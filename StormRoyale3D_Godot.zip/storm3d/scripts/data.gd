extends Node
## Статические данные игры: оружие, сложности, биомы, точки интереса, скины.

class WDef:
	var n := ""
	var s := ""
	var c := Color.WHITE
	var dmg := 0.0
	var rate := 0.0
	var spd := 0.0
	var rng := 0.0
	var spr := 0.0
	var pel := 1
	var mag := 1
	var rld := 1.0
	var ammo := 0
	var cap := 0
	var ideal := 0.0
	var base := 1.0
	var bloom := 0.0
	var recov := 0.5
	var bloom_mul := 1.0
	var hip_mul := 1.0
	var ads_mul := 0.5
	var kick := 0.01
	var kick_x := 0.005
	var ads_zoom := 1.2
	var scope := false
	var assist_cone := 0.1
	var assist_pull := 0.3
	var lead := 0.5
	var slow := 0.8

static func _w(n: String, s: String, c: String, dmg: float, rate: float, spd: float, rng: float, spr: float, pel: int, mag: int, rld: float, ammo: int, cap: int, ideal: float, base: float, bloom: float, recov: float, bloom_mul: float, hip_mul: float, ads_mul: float, kick: float, kick_x: float, ads_zoom: float, scope: bool, assist_cone: float, assist_pull: float, lead: float, slow: float) -> WDef:
	var w := WDef.new()
	w.n = n; w.s = s; w.c = Color.html(c); w.dmg = dmg; w.rate = rate; w.spd = spd; w.rng = rng; w.spr = spr
	w.pel = pel; w.mag = mag; w.rld = rld; w.ammo = ammo; w.cap = cap; w.ideal = ideal; w.base = base
	w.bloom = bloom; w.recov = recov; w.bloom_mul = bloom_mul; w.hip_mul = hip_mul; w.ads_mul = ads_mul
	w.kick = kick; w.kick_x = kick_x; w.ads_zoom = ads_zoom; w.scope = scope
	w.assist_cone = assist_cone; w.assist_pull = assist_pull; w.lead = lead; w.slow = slow
	return w

var WPN := {}
const WORDER := ["pistol", "smg", "rifle", "shotgun", "sniper"]

const DIFFS := {
	"easy": {"bots": 22, "err": 0.17, "turn": 3.0, "spd": 148.0, "react": 0.5},
	"normal": {"bots": 32, "err": 0.10, "turn": 4.6, "spd": 164.0, "react": 0.35},
	"hard": {"bots": 42, "err": 0.055, "turn": 6.5, "spd": 182.0, "react": 0.22},
}
const DIFF_NAMES := {"easy": "Лёгкий", "normal": "Обычный", "hard": "Сложный"}
const PSPEED := 215.0
const NAMES := ["Рекс", "Тень", "Кактус", "Ниндзя", "Банан", "Вихрь", "Лис", "Громила", "Пиксель", "Ёжик", "Сова", "Барсик", "Топор", "Зевс", "Мышь", "Стрела", "Шторм", "Феникс", "Дракон", "Орёл", "Волк", "Мамонт", "Кроха", "Танкист", "Ворон", "Тигр", "Комета", "Булка", "Снайпер", "Малыш"]
const BOT_COLORS := ["#e8574a", "#e89a3c", "#d6c43a", "#6bd36b", "#3cc9b8", "#4a8fe8", "#8e6be8", "#d65bc0", "#c8c8d0", "#a8744a"]

# id, name, fx, fy, sigma, g1, g2, dk, hill
var BIOMES := [
	{"id": "plains", "n": "Равнины", "fx": .5, "fy": .5, "s": .27, "g1": "#62b34a", "g2": "#8fd35c", "dk": "#3f9142", "hill": 1.0},
	{"id": "desert", "n": "Пустыня", "fx": .82, "fy": .2, "s": .2, "g1": "#d9b673", "g2": "#ecd49a", "dk": "#bb8c4a", "hill": .8},
	{"id": "snow", "n": "Снега", "fx": .18, "fy": .2, "s": .2, "g1": "#e4eef6", "g2": "#ffffff", "dk": "#bccfe0", "hill": 2.0},
	{"id": "forest", "n": "Лес", "fx": .2, "fy": .82, "s": .21, "g1": "#2f7d3a", "g2": "#44a24c", "dk": "#1f5e2c", "hill": 1.3},
	{"id": "swamp", "n": "Болото", "fx": .82, "fy": .82, "s": .2, "g1": "#6b7b3c", "g2": "#8c9c4e", "dk": "#4b5829", "hill": .5},
]
const BIOME_IDX := {"plains": 0, "desert": 1, "snow": 2, "forest": 3, "swamp": 4}
const POIS := [
	["Лунный Город", "plains", .5, .5, 1], ["Красный Мост", "plains", .37, .63, 0], ["Дальняя Ферма", "plains", .65, .38, 0], ["Каменка", "plains", .5, .3, 0], ["Тихая Гавань", "plains", .52, .9, 0],
	["Пыльный Каньон", "desert", .84, .17, 0], ["Золотые Дюны", "desert", .7, .31, 0], ["Оазис", "desert", .91, .39, 0],
	["Ледяной Пик", "snow", .15, .15, 0], ["Снежная Деревня", "snow", .29, .31, 0], ["Северный Порт", "snow", .1, .35, 0],
	["Сосновый Бор", "forest", .18, .84, 0], ["Лесная Застава", "forest", .31, .7, 0], ["Зелёный Приют", "forest", .1, .66, 0],
	["Туманная Топь", "swamp", .84, .84, 0], ["Ржавый Порт", "swamp", .9, .62, 0], ["Тихое Болото", "swamp", .72, .9, 0],
]

var RARS := {
	"common": {"n": "Обычный", "c": Color.html("#9aa7ba")},
	"uncommon": {"n": "Необычный", "c": Color.html("#5fd35f")},
	"rare": {"n": "Редкий", "c": Color.html("#3fa9ff")},
	"epic": {"n": "Эпический", "c": Color.html("#b45cff")},
	"legendary": {"n": "Легендарный", "c": Color.html("#ffa63a")},
}
const RAR_IDS := ["common", "uncommon", "rare", "epic", "legendary"]
const RAR_TIER := {"common": 0, "uncommon": 1, "rare": 2, "epic": 3, "legendary": 4}

var SKINS := [
	{"id": "ranger", "n": "Рейнджер", "r": "common", "top": "#ff8a1f", "acc": "#ffffff", "pants": "#25327e", "hair": "#222222", "hat": 0, "hatc": "#ffffff", "tone": "#d9a47a", "glide": "#ff8a1f", "src": "free"},
	{"id": "scout", "n": "Скаут", "r": "uncommon", "top": "#4f8a3b", "acc": "#d9c77a", "pants": "#5a4a32", "hair": "#5a3a1e", "hat": 3, "hatc": "#3d6b2e", "tone": "#f1c9a0", "glide": "#4f8a3b", "src": "pass"},
	{"id": "sentinel", "n": "Страж", "r": "rare", "top": "#3a4a6b", "acc": "#9fc7ff", "pants": "#1d2640", "hair": "#111111", "hat": 0, "hatc": "#9fc7ff", "tone": "#b97c55", "glide": "#3fa9ff", "src": "pass"},
	{"id": "neon", "n": "Неон-бегун", "r": "rare", "top": "#ff2fa8", "acc": "#38f5ff", "pants": "#2a1b55", "hair": "#38f5ff", "hat": 2, "hatc": "#ff2fa8", "tone": "#f1c9a0", "glide": "#ff2fa8", "src": "pass"},
	{"id": "shadow", "n": "Тень", "r": "epic", "top": "#1c1c28", "acc": "#b45cff", "pants": "#12121a", "hair": "#0a0a0a", "hat": 1, "hatc": "#1c1c28", "tone": "#d9a47a", "glide": "#7a3fd0", "src": "pass"},
	{"id": "knight", "n": "Рыцарь бури", "r": "epic", "top": "#8d98ad", "acc": "#ffd23c", "pants": "#5b6578", "hair": "#2a2a33", "hat": 3, "hatc": "#aab4c8", "tone": "#f1c9a0", "glide": "#8d98ad", "src": "pass"},
	{"id": "pilot", "n": "Лётчик", "r": "rare", "top": "#a8742f", "acc": "#f0e2c4", "pants": "#4a3a24", "hair": "#3b2412", "hat": 3, "hatc": "#6b4a1f", "tone": "#d9a47a", "glide": "#c8913f", "src": "pass"},
	{"id": "stormlord", "n": "Повелитель бури", "r": "legendary", "top": "#6a2fd0", "acc": "#ffe14d", "pants": "#2b1560", "hair": "#ffe14d", "hat": 2, "hatc": "#6a2fd0", "tone": "#b97c55", "glide": "#b45cff", "src": "pass"},
	{"id": "frost", "n": "Ледяной", "r": "rare", "top": "#7fd6ff", "acc": "#ffffff", "pants": "#2f5f8f", "hair": "#e8f8ff", "hat": 1, "hatc": "#bfe9ff", "tone": "#f1c9a0", "glide": "#7fd6ff", "src": "shop", "p": 5000},
	{"id": "pirate", "n": "Пират", "r": "uncommon", "top": "#a23b2a", "acc": "#f0d98a", "pants": "#2b2b3a", "hair": "#1a1a1a", "hat": 3, "hatc": "#1a1a1a", "tone": "#b97c55", "glide": "#a23b2a", "src": "shop", "p": 3000},
	{"id": "samurai", "n": "Самурай", "r": "epic", "top": "#c0392b", "acc": "#1a1a1a", "pants": "#2a2a35", "hair": "#101010", "hat": 3, "hatc": "#c0392b", "tone": "#f1c9a0", "glide": "#c0392b", "src": "shop", "p": 9000},
	{"id": "astro", "n": "Астронавт", "r": "rare", "top": "#f2f4f8", "acc": "#ff8a1f", "pants": "#d5d9e2", "hair": "#222222", "hat": 1, "hatc": "#f2f4f8", "tone": "#d9a47a", "glide": "#f2f4f8", "src": "shop", "p": 5500},
	{"id": "jungle", "n": "Следопыт", "r": "common", "top": "#6b8f3a", "acc": "#e0c070", "pants": "#6a5a3a", "hair": "#3b2412", "hat": 0, "hatc": "#6b8f3a", "tone": "#8a5a3a", "glide": "#6b8f3a", "src": "shop", "p": 1800},
	{"id": "cyber", "n": "Кибер", "r": "epic", "top": "#16213a", "acc": "#37ffb0", "pants": "#0e1526", "hair": "#37ffb0", "hat": 2, "hatc": "#16213a", "tone": "#d9a47a", "glide": "#37ffb0", "src": "shop", "p": 9500},
	{"id": "flame", "n": "Огненный", "r": "legendary", "top": "#ff4a1c", "acc": "#ffd23c", "pants": "#401010", "hair": "#ffb000", "hat": 2, "hatc": "#ff4a1c", "tone": "#b97c55", "glide": "#ff6a1c", "src": "shop", "p": 16000},
	{"id": "goldace", "n": "Золотой ас", "r": "legendary", "top": "#e0b02a", "acc": "#ffffff", "pants": "#3a2f18", "hair": "#2a1a08", "hat": 3, "hatc": "#ffd23c", "tone": "#f1c9a0", "glide": "#ffd23c", "src": "shop", "p": 18000},
	{"id": "arctic", "n": "Полярник", "r": "uncommon", "top": "#d6e4f0", "acc": "#ff7a3d", "pants": "#3a4a60", "hair": "#3b2412", "hat": 1, "hatc": "#ff7a3d", "tone": "#f1c9a0", "glide": "#d6e4f0", "src": "shop", "p": 3200},
	{"id": "cowboy", "n": "Ковбой", "r": "common", "top": "#b0763a", "acc": "#e8d3a0", "pants": "#3a4a7a", "hair": "#4a2f16", "hat": 3, "hatc": "#7a4a1f", "tone": "#d9a47a", "glide": "#b0763a", "src": "shop", "p": 2000},
	{"id": "royal", "n": "Королевский", "r": "epic", "top": "#7a1f3a", "acc": "#ffd23c", "pants": "#2b1020", "hair": "#1a1a1a", "hat": 1, "hatc": "#ffd23c", "tone": "#f1c9a0", "glide": "#c0305a", "src": "shop", "p": 10000},
	{"id": "punk", "n": "Панк", "r": "rare", "top": "#2a2a2a", "acc": "#ff3b3b", "pants": "#3a1f4a", "hair": "#ff3b3b", "hat": 2, "hatc": "#2a2a2a", "tone": "#d9a47a", "glide": "#ff3b3b", "src": "shop", "p": 5200},
]
var SKIN := {}

const PASS_TIERS := 50
const PASS_PRICE := 950
const PASS_SKINS := {1: "neon", 12: "shadow", 25: "knight", 38: "pilot", 50: "stormlord"}
const FREE_SKINS := {8: "scout", 30: "sentinel"}

const CH_DAILY := [
	{"id": "d_kill", "t": "Устраните 3 противников", "g": 3, "s": "kills", "xp": 600},
	{"id": "d_chest", "t": "Откройте 3 сундука", "g": 3, "s": "chests", "xp": 500},
	{"id": "d_dmg", "t": "Нанесите 400 урона", "g": 400, "s": "dmg", "xp": 600},
	{"id": "d_time", "t": "Проживите 6 минут суммарно", "g": 6, "s": "mins", "xp": 500},
	{"id": "d_wall", "t": "Постройте 12 стен", "g": 12, "s": "builds", "xp": 400},
	{"id": "d_heal", "t": "Используйте лечение 3 раза", "g": 3, "s": "heals", "xp": 400},
	{"id": "d_play", "t": "Сыграйте 3 матча", "g": 3, "s": "matches", "xp": 500},
	{"id": "d_top", "t": "Войдите в топ-10", "g": 1, "s": "top10", "xp": 700},
]
const CH_WEEKLY := [
	{"id": "w_kill", "t": "Устраните 15 противников", "g": 15, "s": "kills", "xp": 2500},
	{"id": "w_chest", "t": "Откройте 12 сундуков", "g": 12, "s": "chests", "xp": 2000},
	{"id": "w_dmg", "t": "Нанесите 3000 урона", "g": 3000, "s": "dmg", "xp": 2500},
	{"id": "w_play", "t": "Сыграйте 10 матчей", "g": 10, "s": "matches", "xp": 2000},
	{"id": "w_win", "t": "Одержите победу", "g": 1, "s": "wins", "xp": 3000},
	{"id": "w_wall", "t": "Постройте 60 стен", "g": 60, "s": "builds", "xp": 2000},
	{"id": "w_top", "t": "Войдите в топ-10 три раза", "g": 3, "s": "top10", "xp": 2500},
]
const BONUS := [200, 300, 400, 500, 600, 800, 1200]

func _init() -> void:
	WPN["pistol"] = _w("Пистолет", "ПИС", "#aab4c2", 16, .32, 760, 520, .04, 1, 12, 1.2, 30, 90, 240, 1.0, .28, .55, 1.6, 1, .5, .012, .004, 1.15, false, .15, .4, .5, .85)
	WPN["smg"] = _w("ПП", "ПП", "#4ec3ff", 9, .085, 800, 430, .11, 1, 30, 1.6, 50, 200, 200, 1.8, .09, .45, 3.2, 1, .55, .006, .012, 1.25, false, .2, .45, .6, .7)
	WPN["rifle"] = _w("Автомат", "АВТ", "#b46bff", 19, .15, 950, 720, .035, 1, 30, 1.9, 40, 160, 330, 2.2, .18, .5, 2.4, 1, .45, .015, .007, 1.6, false, .14, .32, .75, .6)
	WPN["shotgun"] = _w("Дробовик", "ДРБ", "#ff9a3c", 10, .85, 700, 280, .26, 6, 6, 2.2, 12, 36, 130, 1.6, 0, 1, 0, 1, .7, .07, .02, 1.12, false, .28, .55, .2, .8)
	WPN["sniper"] = _w("Снайперка", "СНП", "#ffd23c", 80, 1.25, 1600, 1300, .006, 1, 5, 2.4, 8, 24, 600, 1.5, .6, .35, 1.5, 10, .3, .085, .01, 3.4, true, .045, 0, .9, .45)
	for b in BIOMES:
		for k in ["g1", "g2", "dk"]:
			b[k] = Color.html(b[k])
	for s in SKINS:
		for k in ["top", "acc", "pants", "hair", "hatc", "tone", "glide"]:
			s[k] = Color.html(s[k])
		SKIN[s["id"]] = s

func rar_col(i: int) -> Color:
	return RARS[RAR_IDS[clampi(i, 0, 4)]]["c"]

func rar_name(i: int) -> String:
	return RARS[RAR_IDS[clampi(i, 0, 4)]]["n"]
