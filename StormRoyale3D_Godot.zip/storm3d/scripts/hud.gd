class_name Hud
extends Control
## Игровой интерфейс: мульти-тач управление, прицел, миникарта, панели.

signal pause_pressed

var game: Game
var active := false
var is_touch := false
var font: Font
var touches := {}
var banner_txt := ""
var banner_t := 0.0
var emote_open := false
var minimap_tex: ImageTexture = null
var vig_tex: ImageTexture = null
var use_total := 1.8
var mouse_fire := false
var touch_fire := false
var pulse := 0.0
var key_ads := false
const GREEN := Color("#5fd97a")
const BLUE := Color("#4fb3ff")
const UI_BG := Color(.04, .06, .12, .55)

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	font = ThemeDB.fallback_font
	is_touch = DisplayServer.is_touchscreen_available() or OS.has_feature("mobile")
	_make_vignette()

func _make_vignette() -> void:
	var w := 128
	var h := 72
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	for j in h:
		for i in w:
			var dx := (i + .5) / w * 2.0 - 1.0
			var dy := (j + .5) / h * 2.0 - 1.0
			var d := sqrt(dx * dx * .75 + dy * dy)
			var a := clampf((d - .45) / .75, 0.0, 1.0)
			img.set_pixel(i, j, Color(1, 1, 1, a * a))
	vig_tex = ImageTexture.create_from_image(img)

func start(g: Game, mini_img: Image) -> void:
	game = g
	minimap_tex = ImageTexture.create_from_image(mini_img)
	touches.clear()
	emote_open = false
	banner_t = 0.0
	if not game.banner_msg.is_connected(show_banner):
		game.banner_msg.connect(show_banner)
	set_active(true)

func set_active(a: bool) -> void:
	active = a
	if not a:
		_release_all()
		if not is_touch:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	elif not is_touch:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _release_all() -> void:
	touches.clear()
	mouse_fire = false
	touch_fire = false
	emote_open = false
	if game:
		game.inp_mx = 0.0
		game.inp_my = 0.0
		game.inp_fire = false
		game.inp_build = false

func show_banner(m: String) -> void:
	banner_txt = m
	banner_t = 3.0

# ---------- раскладка ----------
func _sz() -> Vector2:
	return get_viewport_rect().size

func _buttons() -> Dictionary:
	var s := _sz()
	var W := s.x
	var H := s.y
	var p := game.player
	var air := p.air > 0
	var b := {}
	if air:
		b["jump"] = {"c": Vector2(W - 150, H - 150), "r": 74.0}
	else:
		b["fire"] = {"c": Vector2(W - 135, H - 135), "r": 62.0}
		b["ads"] = {"c": Vector2(W - 110, H - 265), "r": 34.0}
		b["reload"] = {"c": Vector2(W - 250, H - 85), "r": 34.0}
		b["build"] = {"c": Vector2(W - 250, H - 175), "r": 34.0}
		b["heal"] = {"c": Vector2(W - 250, H - 265), "r": 32.0}
		b["emote"] = {"c": Vector2(W - 350, H - 120), "r": 28.0}
		b["shoulder"] = {"c": Vector2(W - 350, H - 190), "r": 24.0}
	b["pause"] = {"c": Vector2(W - 96 - 90 - 40, 40.0), "r": 24.0}
	if emote_open and not air:
		for i in 4:
			b["em%d" % (i + 1)] = {"c": Vector2(W - 350, H - 120 - 64 * (i + 1)), "r": 28.0}
	if not air:
		for i in Data.WORDER.size():
			var rc := _slot_rect(i)
			b["slot%d" % i] = {"rect": rc}
	return b

func _slot_rect(i: int) -> Rect2:
	var s := _sz()
	var w := 84.0
	var g := 6.0
	var tot := w * 5.0 + g * 4.0
	return Rect2(s.x * .5 - tot * .5 + i * (w + g), s.y - 64.0, w, 54.0)

func _hit(b: Dictionary, pos: Vector2) -> String:
	var best := ""
	var bd := 1e9
	for k in b:
		var o: Dictionary = b[k]
		if o.has("rect"):
			if (o["rect"] as Rect2).grow(4.0).has_point(pos):
				return k
		else:
			var d: float = pos.distance_to(o["c"])
			if d <= o["r"] + 10.0 and d < bd:
				bd = d
				best = k
	return best

# ---------- ввод ----------
func _input(ev: InputEvent) -> void:
	if not active or game == null or not game.running or game.paused:
		return
	if ev is InputEventScreenTouch:
		if ev.pressed:
			_press(ev.index, ev.position)
		else:
			_release(ev.index)
	elif ev is InputEventScreenDrag:
		_drag(ev.index, ev.position, ev.relative)
	elif not is_touch:
		if ev is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			_look(ev.relative * .6)
		elif ev is InputEventMouseButton:
			if ev.button_index == MOUSE_BUTTON_LEFT:
				if game.player.air > 0:
					if ev.pressed:
						game.player_jump()
				else:
					mouse_fire = ev.pressed
			elif ev.button_index == MOUSE_BUTTON_RIGHT and ev.pressed:
				game.ads_on = not game.ads_on
		elif ev is InputEventKey and ev.pressed and not ev.echo:
			_key(ev.keycode)

func _key(k: int) -> void:
	var p := game.player
	match k:
		KEY_ESCAPE, KEY_P:
			pause_pressed.emit()
		KEY_R:
			game.start_reload(p)
		KEY_F:
			game.start_use(p)
		KEY_SPACE:
			game.player_jump()
		KEY_G:
			emote_open = not emote_open
		KEY_TAB:
			game.shoulder = -game.shoulder
		KEY_1, KEY_2, KEY_3, KEY_4, KEY_5:
			_select(k - KEY_1)

func _select(i: int) -> void:
	var p := game.player
	var key: String = Data.WORDER[i]
	if p.inv.has(key) and p.cur != key and p.using <= 0.0:
		p.cur = key
		p.rl = 0.0
		game.tone(380, .05, "square", .04)

func _press(idx: int, pos: Vector2) -> void:
	var s := _sz()
	var b := _buttons()
	var h := _hit(b, pos)
	if h != "":
		touches[idx] = {"role": "btn", "name": h, "pos": pos}
		_btn_down(h, idx)
		return
	if emote_open:
		emote_open = false
	if pos.x < s.x * .42 and not _role_taken("move"):
		touches[idx] = {"role": "move", "o": pos, "pos": pos}
	else:
		touches[idx] = {"role": "look", "pos": pos}

func _role_taken(r: String) -> bool:
	for k in touches:
		if touches[k]["role"] == r:
			return true
	return false

func _btn_down(h: String, idx: int) -> void:
	var p := game.player
	if h.begins_with("slot"):
		_select(int(h.substr(4)))
		return
	if h.begins_with("em") and h != "emote":
		game.start_emote(int(h.substr(2)))
		emote_open = false
		return
	match h:
		"fire":
			touches[idx]["role"] = "fire"
			touch_fire = true
		"jump":
			game.player_jump()
		"ads":
			if game.has_gun(p):
				game.ads_on = not game.ads_on
		"reload":
			game.start_reload(p)
		"build":
			touches[idx]["role"] = "build"
			game.inp_build = true
		"heal":
			if game.start_use(p):
				use_total = 1.8 if p.use_kind == "med" else 1.4
		"emote":
			emote_open = not emote_open
		"shoulder":
			game.shoulder = -game.shoulder
		"pause":
			pause_pressed.emit()

func _release(idx: int) -> void:
	if not touches.has(idx):
		return
	var t: Dictionary = touches[idx]
	match t["role"]:
		"move":
			game.inp_mx = 0.0
			game.inp_my = 0.0
		"fire":
			touch_fire = false
		"build":
			game.inp_build = false
	touches.erase(idx)

func _drag(idx: int, pos: Vector2, rel: Vector2) -> void:
	if not touches.has(idx):
		return
	var t: Dictionary = touches[idx]
	t["pos"] = pos
	match t["role"]:
		"move":
			var d: Vector2 = pos - t["o"]
			var R := 70.0
			if d.length() > R * 1.6:
				t["o"] = pos - d.normalized() * R * 1.6
				d = pos - t["o"]
			var v := d / R
			if v.length() > 1.0:
				v = v.normalized()
			if v.length() < .12:
				v = Vector2.ZERO
			game.inp_mx = v.x
			game.inp_my = v.y
		"look", "fire":
			_look(rel)

func _look(rel: Vector2) -> void:
	var sens: float = Prof.p.get("sens", 1.0)
	var zoom_k := 1.0 / maxf(1.0, game.cur_zoom * .8)
	game.cam_yaw += rel.x * .0050 * sens * zoom_k
	game.cam_pitch = clampf(game.cam_pitch + rel.y * .0038 * sens * zoom_k, -.55, .95)

func _process(dt: float) -> void:
	if banner_t > 0.0:
		banner_t -= dt
	pulse += dt
	if active and game and game.running:
		if not is_touch:
			var mx := 0.0
			var my := 0.0
			if Input.is_key_pressed(KEY_A): mx -= 1.0
			if Input.is_key_pressed(KEY_D): mx += 1.0
			if Input.is_key_pressed(KEY_W): my -= 1.0
			if Input.is_key_pressed(KEY_S): my += 1.0
			var v := Vector2(mx, my)
			if v.length() > 1.0:
				v = v.normalized()
			game.inp_mx = v.x
			game.inp_my = v.y
			game.inp_build = Input.is_key_pressed(KEY_Q)
		game.inp_fire = touch_fire or mouse_fire
	queue_redraw()

# ---------- рисование ----------
func _txt(t: String, pos: Vector2, size: int, col: Color, align := HORIZONTAL_ALIGNMENT_LEFT, w := -1.0) -> void:
	draw_string(font, pos + Vector2(1.5, 1.5), t, align, w, size, Color(0, 0, 0, .65 * col.a))
	draw_string(font, pos, t, align, w, size, col)

func _fmt_t(sec: float) -> String:
	var s := maxi(0, ceili(sec))
	return "%d:%02d" % [s / 60, s % 60]

func _chip(rc: Rect2, text: String, col := Color.WHITE) -> void:
	draw_rect(rc, UI_BG)
	draw_rect(rc, Color(1, 1, 1, .12), false, 1.5)
	_txt(text, rc.position + Vector2(0, rc.size.y * .5 + 6), 17, col, HORIZONTAL_ALIGNMENT_CENTER, rc.size.x)

func _btn(o: Dictionary, label: String, col := Color.WHITE, on := false, fs := 15) -> void:
	var c: Vector2 = o["c"]
	var r: float = o["r"]
	draw_circle(c, r, Color(col.r, col.g, col.b, .38 if on else .2))
	draw_arc(c, r, 0, TAU, 40, Color(col.r, col.g, col.b, .8 if on else .5), 2.5, true)
	_txt(label, c + Vector2(-r, 5), fs, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0)

func _draw() -> void:
	if game == null or game.player == null or not game.running:
		return
	var s := _sz()
	var p := game.player
	var W := s.x
	var H := s.y
	# виньетки
	var out_storm: bool = Vector2(p.x - game.storm["cx"], p.y - game.storm["cy"]).length() > game.storm["r"] and p.air == 0
	if out_storm:
		draw_texture_rect(vig_tex, Rect2(Vector2.ZERO, s), false, Color(.6, .15, 1.0, .55 + sin(pulse * 4.0) * .1))
	if game.dmg_flash > 0.0:
		draw_texture_rect(vig_tex, Rect2(Vector2.ZERO, s), false, Color(1, .05, .05, clampf(game.dmg_flash * 3.0, 0.0, .9)))
	elif p.alive and p.hp < 30.0:
		draw_texture_rect(vig_tex, Rect2(Vector2.ZERO, s), false, Color(.9, 0, 0, .25 + sin(pulse * 5.0) * .08))
	if game.scoped_now:
		_draw_scope(s)
	# указатели урона
	var cc := s * .5
	for d: Types.DmgDir in game.dmg_dirs:
		var a := atan2(d.y - p.y, d.x - p.x) - game.cam_yaw
		var sa := atan2(-cos(a), sin(a))
		draw_arc(cc, 150.0, sa - .3, sa + .3, 12, Color(1, .1, .1, clampf(d.t * 1.2, 0.0, .9)), 12.0, true)
	# прицел
	if p.alive and p.air == 0 and not game.scoped_now:
		_draw_cross(cc, p)
	if game.hit_mark > 0.0:
		var a2 := clampf(game.hit_mark * 6.0, 0.0, 1.0)
		for sg in [Vector2(1, 1), Vector2(-1, 1), Vector2(1, -1), Vector2(-1, -1)]:
			draw_line(cc + sg * 8.0, cc + sg * 17.0, Color(1, 1, 1, a2), 3.0)
	# перезарядка / лечение
	if p.rl > 0.0:
		_bar_h(Vector2(cc.x - 55, cc.y + 70), 110.0, 1.0 - p.rl / maxf(.01, p.rl_max), Color("#ffd23c"), "Перезарядка")
	if p.using > 0.0:
		_bar_h(Vector2(cc.x - 55, cc.y + 70), 110.0, 1.0 - p.using / maxf(.01, use_total), GREEN if p.use_kind == "med" else BLUE, "Лечение" if p.use_kind == "med" else "Щит")
	# верхняя панель
	_chip(Rect2(14, 12, 112, 34), "Живых: %d" % game.alive_n)
	_chip(Rect2(132, 12, 100, 34), "Убито: %d" % p.kills, Color("#ffd23c"))
	_draw_storm_chip(s)
	# лента убийств
	var fy := 62.0
	for f in game.feed:
		var al := clampf(f["t"], 0.0, 1.0)
		var tw := font.get_string_size(f["msg"], HORIZONTAL_ALIGNMENT_LEFT, -1, 15).x + 16.0
		draw_rect(Rect2(14, fy, tw, 24), Color(0, 0, 0, .45 * al))
		_txt(f["msg"], Vector2(22, fy + 17), 15, Color(1, 1, 1, al))
		fy += 28.0
	# баннер
	if banner_t > 0.0:
		var ba := clampf(banner_t * 2.0, 0.0, 1.0)
		var tw2 := font.get_string_size(banner_txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 22).x + 40.0
		draw_rect(Rect2(W * .5 - tw2 * .5, 112, tw2, 40), Color(.05, .05, .15, .7 * ba))
		draw_rect(Rect2(W * .5 - tw2 * .5, 112, tw2, 40), Color(1, .8, .2, .6 * ba), false, 2.0)
		_txt(banner_txt, Vector2(W * .5 - tw2 * .5, 140), 22, Color(1, .95, .8, ba), HORIZONTAL_ALIGNMENT_CENTER, tw2)
	_draw_minimap(s)
	_draw_air(s, p)
	if p.air == 0:
		_draw_status(s, p)
	_draw_controls(s, p)

func _draw_cross(cc: Vector2, p: Ent) -> void:
	var w: Data.WDef = Data.WPN[p.cur]
	var spr := game.eff_spread(p, w) if game.has_gun(p) else .02
	var fov := deg_to_rad(game.cam_fov)
	var gap := clampf(spr * (_sz().y * .5) / tan(fov * .5) * 1.1 + 5.0, 6.0, 90.0)
	var col := Color(1, 1, 1, .95)
	if game.aim_lock["on"] and game.aim_lock["tight"]:
		col = Color("#ff6a5a")
	for d in [Vector2(1, 0), Vector2(-1, 0), Vector2(0, 1), Vector2(0, -1)]:
		draw_line(cc + d * gap, cc + d * (gap + 10.0), Color(0, 0, 0, .5), 4.0)
		draw_line(cc + d * gap, cc + d * (gap + 10.0), col, 2.0)
	draw_circle(cc, 1.8, col)

func _draw_scope(s: Vector2) -> void:
	var cc := s * .5
	var R := s.y * .44
	var big := s.length()
	draw_arc(cc, R + big * .5, 0, TAU, 96, Color.BLACK, big, true)
	draw_arc(cc, R, 0, TAU, 96, Color(0, 0, 0, .9), 3.0, true)
	draw_line(Vector2(cc.x - R, cc.y), Vector2(cc.x + R, cc.y), Color(0, 0, 0, .75), 1.5)
	draw_line(Vector2(cc.x, cc.y - R), Vector2(cc.x, cc.y + R), Color(0, 0, 0, .75), 1.5)
	draw_circle(cc, 2.0, Color(1, .2, .2))
	for i in range(1, 6):
		draw_line(Vector2(cc.x - 8, cc.y + i * 28), Vector2(cc.x + 8, cc.y + i * 28), Color(0, 0, 0, .7), 1.5)

func _bar_h(pos: Vector2, w: float, k: float, col: Color, label: String) -> void:
	draw_rect(Rect2(pos, Vector2(w, 10)), Color(0, 0, 0, .55))
	draw_rect(Rect2(pos + Vector2(1, 1), Vector2((w - 2) * clampf(k, 0, 1), 8)), col)
	_txt(label, pos + Vector2(0, -4), 14, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, w)

func _draw_storm_chip(s: Vector2) -> void:
	var st := game.storm
	var txt := ""
	var col := Color.WHITE
	if st["mode"] == "wait":
		txt = "Буря сужается через %s" % _fmt_t(st["t"])
	elif st["mode"] == "shrink":
		txt = "Буря сужается: %s" % _fmt_t(st["t"])
		col = Color("#c58bff")
	else:
		txt = "Финальная зона"
		col = Color("#c58bff")
	if game.player.air > 0:
		txt = "Автобус над островом" if game.player.air == 1 else "Падение"
	var w := 230.0
	_chip(Rect2(s.x * .5 - w * .5, 12, w, 34), txt, col)

func _draw_minimap(s: Vector2) -> void:
	var sz := 176.0
	var rc := Rect2(s.x - 14 - sz, 12, sz, sz)
	draw_rect(rc.grow(4), Color(0, 0, 0, .55))
	if minimap_tex:
		draw_texture_rect(minimap_tex, rc, false, Color(1, 1, 1, .95))
	var k := sz / World.W
	var st := game.storm
	var f := func(x: float, y: float) -> Vector2:
		return rc.position + Vector2(clampf(x, 0, World.W), clampf(y, 0, World.H)) * k
	# буря
	var c: Vector2 = f.call(st["cx"], st["cy"])
	var rr: float = st["r"] * k
	draw_arc(c, rr, 0, TAU, 72, Color("#b05cff"), 2.5, true)
	if st["mode"] != "done" and st["phase"] >= 0:
		var ct: Vector2 = f.call(st["tcx"], st["tcy"])
		draw_arc(ct, st["tr"] * k, 0, TAU, 56, Color(1, 1, 1, .95), 1.8, true)
	# автобус
	var b := game.bus
	if b["on"]:
		var a: Vector2 = f.call(b["x0"], b["y0"])
		var e2: Vector2 = f.call(b["x0"] + b["dx"] * b["len"], b["y0"] + b["dy"] * b["len"])
		draw_line(a, e2, Color(1, 1, 1, .35), 1.5)
		draw_circle(f.call(b["x"], b["y"]), 4.0, Color("#ffd23c"))
	for ch: Types.Chest in game.world.chests:
		if ch.drop and not ch.open:
			var q: Vector2 = f.call(ch.x, ch.y)
			draw_rect(Rect2(q - Vector2(4, 4), Vector2(8, 8)), Color("#ffd23c"))
			draw_rect(Rect2(q - Vector2(4, 4), Vector2(8, 8)), Color.BLACK, false, 1.0)
	var p := game.player
	if p.alive:
		var pp: Vector2 = f.call(p.x, p.y) if p.air != 1 else f.call(b["x"], b["y"])
		var ang := game.cam_yaw
		var d := Vector2(cos(ang), sin(ang))
		var n := Vector2(-d.y, d.x)
		draw_colored_polygon(PackedVector2Array([pp + d * 8.0, pp - d * 5.0 + n * 5.0, pp - d * 5.0 - n * 5.0]), Color("#ff4a4a"))
	draw_rect(rc, Color(1, 1, 1, .5), false, 2.0)

func _draw_air(s: Vector2, p: Ent) -> void:
	if p.air == 0:
		return
	var msg := ""
	if p.air == 1:
		msg = "Нажмите ПРЫЖОК, чтобы покинуть автобус"
	elif p.air == 2:
		msg = "Высота: %d м" % roundi(p.alt * .1)
		if p.alt < Game.BUS_ALT - 100.0:
			msg += "  ·  Нажмите ПЛАНЕР"
	else:
		msg = "Планёр · Высота: %d м" % roundi(p.alt * .1)
	_txt(msg, Vector2(0, s.y * .72), 20, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, s.x)

func _draw_status(s: Vector2, p: Ent) -> void:
	var bw := 300.0
	var x := s.x * .5 - bw * .5
	var y := s.y - 108.0
	draw_rect(Rect2(x, y, bw, 15), Color(0, 0, 0, .55))
	draw_rect(Rect2(x + 1, y + 1, (bw - 2) * clampf(p.sh / 100.0, 0, 1), 13), BLUE)
	_txt("%d" % roundi(p.sh), Vector2(x, y + 12), 12, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, bw)
	draw_rect(Rect2(x, y + 18, bw, 20), Color(0, 0, 0, .55))
	var hk := clampf(p.hp / 100.0, 0, 1)
	draw_rect(Rect2(x + 1, y + 19, (bw - 2) * hk, 18), GREEN.lerp(Color("#ff5a4a"), 1.0 - hk if hk < .4 else 0.0))
	_txt("%d" % ceili(p.hp), Vector2(x, y + 34), 15, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, bw)
	# ресурсы
	var items := [["Аптечки", p.meds, GREEN], ["Щиты", p.pots, BLUE], ["Дерево", p.mats, Color("#d9ad74")]]
	for i in 3:
		var rc := Rect2(14, s.y * .42 + i * 40, 110, 32)
		draw_rect(rc, UI_BG)
		draw_rect(Rect2(rc.position, Vector2(4, rc.size.y)), items[i][2])
		_txt("%s %d" % [items[i][0], items[i][1]], rc.position + Vector2(10, 22), 15, Color.WHITE)

func _draw_controls(s: Vector2, p: Ent) -> void:
	var b := _buttons()
	# левый стик
	var mv = null
	for k in touches:
		if touches[k]["role"] == "move":
			mv = touches[k]
	if mv:
		var o: Vector2 = mv["o"]
		draw_circle(o, 70.0, Color(1, 1, 1, .10))
		draw_arc(o, 70.0, 0, TAU, 40, Color(1, 1, 1, .35), 3.0, true)
		var d: Vector2 = (mv["pos"] - o).limit_length(70.0)
		draw_circle(o + d, 30.0, Color(1, 1, 1, .35))
	else:
		var o2 := Vector2(150, s.y - 150)
		draw_arc(o2, 70.0, 0, TAU, 40, Color(1, 1, 1, .16), 3.0, true)
		draw_circle(o2, 28.0, Color(1, 1, 1, .09))
	if b.has("fire"):
		var fb: Dictionary = b["fire"]
		_btn(fb, "ОГОНЬ", Color("#ff5a4a"), touch_fire or mouse_fire, 18)
		_btn(b["ads"], "ЦЕЛЬ", Color("#ffd23c"), game.ads_on)
		var rl_txt := "ЗАРЯД"
		_btn(b["reload"], rl_txt, Color("#ffffff"), p.rl > 0.0, 13)
		_btn(b["build"], "СТЕНА", Color("#d9ad74"), game.inp_build, 13)
		_btn(b["heal"], "ЛЕЧИТЬ", GREEN, p.using > 0.0, 12)
		_btn(b["emote"], "ЭМОЦ", Color("#c58bff"), emote_open, 12)
		_btn(b["shoulder"], "<>", Color("#9ad0ff"), false, 14)
	if b.has("jump"):
		_btn(b["jump"], "ПРЫЖОК" if p.air == 1 else ("ПЛАНЕР" if p.alt < Game.BUS_ALT - 100.0 else "ПАДЕНИЕ"), Color("#ffd23c"), p.air == 1 or p.alt < Game.BUS_ALT - 100.0, 18)
	_btn(b["pause"], "II", Color.WHITE, false, 18)
	for i in 4:
		var kk := "em%d" % (i + 1)
		if b.has(kk):
			_btn(b[kk], Views.EMOTES[i].substr(0, 6), Color("#c58bff"), false, 11)
	for i in Data.WORDER.size():
		var kk2 := "slot%d" % i
		if not b.has(kk2):
			continue
		var key: String = Data.WORDER[i]
		var w: Data.WDef = Data.WPN[key]
		var rc: Rect2 = b[kk2]["rect"]
		var has := p.inv.has(key)
		var sel := p.cur == key
		draw_rect(rc, Color(.04, .06, .12, .7 if has else .35))
		var rc_col: Color = Data.rar_col(p.rar.get(key, 0)) if (has and p.rar.get(key, 0) > 0) else w.c
		if has:
			draw_rect(Rect2(rc.position, Vector2(rc.size.x, 4)), rc_col)
		draw_rect(rc, Color(1, .9, .4, 1.0) if sel else Color(1, 1, 1, .16), false, 3.0 if sel else 1.5)
		_txt(w.n, rc.position + Vector2(0, 22), 14, Color(1, 1, 1, 1.0 if has else .4), HORIZONTAL_ALIGNMENT_CENTER, rc.size.x)
		if has:
			var cl := game.clip_of(p, key)
			var tot: int = p.inv[key]
			_txt("%d / %d" % [cl, tot - cl], rc.position + Vector2(0, 44), 14, Color("#ffd23c") if sel else Color(1, 1, 1, .8), HORIZONTAL_ALIGNMENT_CENTER, rc.size.x)
		else:
			_txt("%d" % (i + 1), rc.position + Vector2(0, 44), 13, Color(1, 1, 1, .3), HORIZONTAL_ALIGNMENT_CENTER, rc.size.x)
